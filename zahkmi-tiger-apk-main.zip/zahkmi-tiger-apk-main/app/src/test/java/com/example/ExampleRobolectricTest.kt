package com.example

import android.content.Context
import androidx.test.core.app.ApplicationProvider
import com.example.model.Currency
import org.junit.Assert.assertEquals
import org.junit.Test
import org.junit.runner.RunWith
import org.robolectric.RobolectricTestRunner
import org.robolectric.annotation.Config

@RunWith(RobolectricTestRunner::class)
@Config(sdk = [36])
class ExampleRobolectricTest {

  @Test
  fun `read string from context`() {
    val context = ApplicationProvider.getApplicationContext<Context>()
    val appName = context.getString(R.string.app_name)
    assertEquals("zahkmi♤♤♤tiger", appName)
  }

  @Test
  fun `currency conversion works correctly`() {
    val usdPrice = 10.0
    val inrPrice = usdPrice * Currency.INR.rateFromUsd
    assertEquals(835.0, inrPrice, 0.01)
  }
}
