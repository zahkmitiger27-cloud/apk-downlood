package com.example.ui.screens

import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material.icons.outlined.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.R
import com.example.model.Currency
import com.example.model.PurchaseRecord
import com.example.model.StoreApp
import com.example.model.UserAccount
import com.example.ui.theme.*

@Composable
fun ProfileScreen(
    currentUser: UserAccount?,
    purchases: List<PurchaseRecord>,
    userApps: List<StoreApp>,
    currency: Currency,
    onLoginClick: () -> Unit,
    onLogoutClick: () -> Unit,
    onEditProfile: (String, String) -> Unit,
    onOpenAdmin: () -> Unit,
    onOpenSupabaseConfig: () -> Unit,
    onOpenPolicy: (String) -> Unit,
    modifier: Modifier = Modifier
) {
    var showEditProfileDialog by remember { mutableStateOf(false) }
    var editName by remember { mutableStateOf(currentUser?.displayName ?: "") }
    var editBio by remember { mutableStateOf(currentUser?.bio ?: "") }

    LazyColumn(
        modifier = modifier
            .fillMaxSize()
            .testTag("profile_screen"),
        contentPadding = PaddingValues(16.dp)
    ) {
        if (currentUser == null) {
            // Guest state
            item {
                Card(
                    modifier = Modifier.fillMaxWidth(),
                    colors = CardDefaults.cardColors(containerColor = TigerCarbonSurface),
                    shape = RoundedCornerShape(16.dp)
                ) {
                    Column(
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(24.dp),
                        horizontalAlignment = Alignment.CenterHorizontally
                    ) {
                        Icon(
                            imageVector = Icons.Default.AccountCircle,
                            contentDescription = "Guest",
                            tint = TigerOrange,
                            modifier = Modifier.size(64.dp)
                        )
                        Spacer(modifier = Modifier.height(12.dp))
                        Text(
                            text = "Welcome to Jakhmi Tiger Store",
                            color = TigerTextPrimary,
                            fontSize = 18.sp,
                            fontWeight = FontWeight.Bold
                        )
                        Text(
                            text = "Sign in to manage downloads, publish APKs, and sell digital kits",
                            color = TigerTextSecondary,
                            fontSize = 13.sp
                        )
                        Spacer(modifier = Modifier.height(16.dp))
                        Button(
                            onClick = onLoginClick,
                            shape = RoundedCornerShape(14.dp),
                            colors = ButtonDefaults.buttonColors(
                                containerColor = TigerOrange,
                                contentColor = Color.Black
                            ),
                            modifier = Modifier.fillMaxWidth().testTag("profile_signin_button")
                        ) {
                            Text("Sign In or Register", fontWeight = FontWeight.Bold)
                        }
                    }
                }
            }
        } else {
            // Authenticated user header
            item {
                Card(
                    modifier = Modifier.fillMaxWidth(),
                    colors = CardDefaults.cardColors(containerColor = TigerCarbonSurface),
                    shape = RoundedCornerShape(20.dp),
                    border = androidx.compose.foundation.BorderStroke(1.dp, TigerCarbonSurfaceBorder)
                ) {
                    Column(
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(18.dp)
                    ) {
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Box(
                                modifier = Modifier
                                    .size(64.dp)
                                    .clip(CircleShape)
                                    .border(2.dp, TigerOrange, CircleShape)
                            ) {
                                Image(
                                    painter = painterResource(id = R.drawable.img_tiger_logo),
                                    contentDescription = "Avatar",
                                    modifier = Modifier.fillMaxSize()
                                )
                            }
                            Spacer(modifier = Modifier.width(14.dp))
                            Column(modifier = Modifier.weight(1f)) {
                                Row(verticalAlignment = Alignment.CenterVertically) {
                                    Text(
                                        text = currentUser.displayName,
                                        color = TigerTextPrimary,
                                        fontSize = 18.sp,
                                        fontWeight = FontWeight.Bold
                                    )
                                    if (currentUser.isVerified) {
                                        Spacer(modifier = Modifier.width(6.dp))
                                        Icon(
                                            imageVector = Icons.Default.Verified,
                                            contentDescription = "Verified Creator",
                                            tint = TigerOrange,
                                            modifier = Modifier.size(16.dp)
                                        )
                                    }
                                }
                                Text(
                                    text = "@${currentUser.username} • ${currentUser.email}",
                                    color = TigerTextSecondary,
                                    fontSize = 12.sp
                                )
                                if (currentUser.isAdmin) {
                                    Spacer(modifier = Modifier.height(4.dp))
                                    Surface(
                                        shape = RoundedCornerShape(4.dp),
                                        color = TigerOrangeDark
                                    ) {
                                        Text(
                                            text = "ADMINISTRATOR",
                                            color = TigerYellow,
                                            fontSize = 9.sp,
                                            fontWeight = FontWeight.Bold,
                                            modifier = Modifier.padding(horizontal = 6.dp, vertical = 2.dp)
                                        )
                                    }
                                }
                            }

                            IconButton(onClick = {
                                editName = currentUser.displayName
                                editBio = currentUser.bio
                                showEditProfileDialog = true
                            }) {
                                Icon(
                                    imageVector = Icons.Default.Edit,
                                    contentDescription = "Edit Profile",
                                    tint = TigerTextSecondary
                                )
                            }
                        }

                        Spacer(modifier = Modifier.height(12.dp))
                        Text(
                            text = currentUser.bio,
                            color = TigerTextPrimary,
                            fontSize = 13.sp
                        )

                        Spacer(modifier = Modifier.height(14.dp))
                        // Wallet / Balance row
                        Surface(
                            modifier = Modifier.fillMaxWidth(),
                            shape = RoundedCornerShape(12.dp),
                            color = TigerCarbonSurfaceElevated
                        ) {
                            Row(
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .padding(horizontal = 14.dp, vertical = 10.dp),
                                horizontalArrangement = Arrangement.SpaceBetween,
                                verticalAlignment = Alignment.CenterVertically
                            ) {
                                Column {
                                    Text("Creator Wallet Balance", color = TigerTextMuted, fontSize = 11.sp)
                                    Text(
                                        "${currency.symbol}${String.format("%.2f", currentUser.balance * currency.rateFromUsd)}",
                                        color = TigerOrangeLight,
                                        fontSize = 18.sp,
                                        fontWeight = FontWeight.Bold
                                    )
                                }
                                Text("Earnings & Sales", color = TigerSuccess, fontSize = 11.sp, fontWeight = FontWeight.Bold)
                            }
                        }
                    }
                }
            }

            // Admin Portal Card (if admin)
            if (currentUser.isAdmin) {
                item {
                    Spacer(modifier = Modifier.height(12.dp))
                    Card(
                        modifier = Modifier
                            .fillMaxWidth()
                            .clickable { onOpenAdmin() }
                            .testTag("admin_portal_button"),
                        colors = CardDefaults.cardColors(containerColor = TigerOrangeDark.copy(alpha = 0.3f)),
                        shape = RoundedCornerShape(14.dp),
                        border = androidx.compose.foundation.BorderStroke(1.dp, TigerOrangeDark)
                    ) {
                        Row(
                            modifier = Modifier
                                .fillMaxWidth()
                                .padding(14.dp),
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Icon(
                                imageVector = Icons.Default.AdminPanelSettings,
                                contentDescription = "Admin",
                                tint = TigerYellow,
                                modifier = Modifier.size(28.dp)
                            )
                            Spacer(modifier = Modifier.width(12.dp))
                            Column(modifier = Modifier.weight(1f)) {
                                Text(
                                    text = "Administrator Moderation Dashboard",
                                    color = TigerYellow,
                                    fontWeight = FontWeight.Bold,
                                    fontSize = 14.sp
                                )
                                Text(
                                    text = "Moderate apps, reels, content reports & platform security",
                                    color = TigerTextSecondary,
                                    fontSize = 11.sp
                                )
                            }
                            Icon(
                                imageVector = Icons.Default.ChevronRight,
                                contentDescription = "Open",
                                tint = TigerYellow
                            )
                        }
                    }
                }
            }

            // Purchased Downloads Section
            item {
                Spacer(modifier = Modifier.height(20.dp))
                Text(
                    text = "My Order History & Downloads (${purchases.size})",
                    color = TigerTextPrimary,
                    fontSize = 16.sp,
                    fontWeight = FontWeight.Bold
                )
                Spacer(modifier = Modifier.height(8.dp))
            }

            if (purchases.isEmpty()) {
                item {
                    Text(
                        text = "No purchased items yet. Visit Marketplace or Apps to download.",
                        color = TigerTextMuted,
                        fontSize = 13.sp
                    )
                }
            } else {
                items(purchases) { purchase ->
                    Card(
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(vertical = 4.dp),
                        colors = CardDefaults.cardColors(containerColor = TigerCarbonSurface),
                        shape = RoundedCornerShape(12.dp)
                    ) {
                        Row(
                            modifier = Modifier
                                .fillMaxWidth()
                                .padding(12.dp),
                            verticalAlignment = Alignment.CenterVertically,
                            horizontalArrangement = Arrangement.SpaceBetween
                        ) {
                            Column(modifier = Modifier.weight(1f)) {
                                Text(
                                    text = purchase.itemTitle,
                                    color = TigerTextPrimary,
                                    fontSize = 13.sp,
                                    fontWeight = FontWeight.Bold
                                )
                                Text(
                                    text = "${purchase.currency} ${String.format("%.2f", purchase.amount)} • Ref: ${purchase.transactionRef}",
                                    color = TigerTextSecondary,
                                    fontSize = 11.sp
                                )
                                Text(
                                    text = purchase.timestamp,
                                    color = TigerTextMuted,
                                    fontSize = 10.sp
                                )
                            }
                            Button(
                                onClick = { /* Instant download action */ },
                                colors = ButtonDefaults.buttonColors(containerColor = TigerOrange, contentColor = Color.Black),
                                shape = RoundedCornerShape(8.dp),
                                contentPadding = PaddingValues(horizontal = 10.dp, vertical = 4.dp)
                            ) {
                                Text("Download", fontSize = 11.sp, fontWeight = FontWeight.Bold)
                            }
                        }
                    }
                }
            }

            // Supabase Configuration Button
            item {
                Spacer(modifier = Modifier.height(20.dp))
                Card(
                    modifier = Modifier
                        .fillMaxWidth()
                        .clickable { onOpenSupabaseConfig() }
                        .testTag("supabase_config_button"),
                    colors = CardDefaults.cardColors(containerColor = TigerCarbonSurfaceElevated),
                    shape = RoundedCornerShape(14.dp),
                    border = androidx.compose.foundation.BorderStroke(1.dp, TigerCarbonSurfaceBorder)
                ) {
                    Row(
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(14.dp),
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Icon(
                            imageVector = Icons.Default.CloudSync,
                            contentDescription = "Supabase",
                            tint = TigerSuccess,
                            modifier = Modifier.size(26.dp)
                        )
                        Spacer(modifier = Modifier.width(12.dp))
                        Column(modifier = Modifier.weight(1f)) {
                            Text(
                                text = "Supabase Cloud Backend Settings",
                                color = TigerTextPrimary,
                                fontWeight = FontWeight.Bold,
                                fontSize = 13.sp
                            )
                            Text(
                                text = "Configure PostgreSQL, Auth, and Storage connection",
                                color = TigerTextSecondary,
                                fontSize = 11.sp
                            )
                        }
                        Icon(
                            imageVector = Icons.Default.ChevronRight,
                            contentDescription = "Open",
                            tint = TigerTextSecondary
                        )
                    }
                }
            }

            // Legal & Policies
            item {
                Spacer(modifier = Modifier.height(16.dp))
                Text(
                    text = "Help, Safety & Policies",
                    color = TigerTextPrimary,
                    fontSize = 16.sp,
                    fontWeight = FontWeight.Bold
                )
                Spacer(modifier = Modifier.height(8.dp))

                val policies = listOf(
                    "PRIVACY" to "Privacy Policy",
                    "TERMS" to "Terms of Service",
                    "COMMUNITY" to "Community Guidelines",
                    "REFUND" to "Refund Policy",
                    "COPYRIGHT" to "Copyright & DMCA Reporting"
                )

                policies.forEach { (key, label) ->
                    Surface(
                        modifier = Modifier
                            .fillMaxWidth()
                            .clip(RoundedCornerShape(8.dp))
                            .clickable { onOpenPolicy(key) }
                            .padding(vertical = 8.dp),
                        color = Color.Transparent
                    ) {
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.SpaceBetween,
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Text(text = label, color = TigerTextSecondary, fontSize = 13.sp)
                            Icon(
                                imageVector = Icons.Default.ChevronRight,
                                contentDescription = label,
                                tint = TigerTextMuted,
                                modifier = Modifier.size(18.dp)
                            )
                        }
                    }
                }
            }

            // Log Out button
            item {
                Spacer(modifier = Modifier.height(20.dp))
                OutlinedButton(
                    onClick = onLogoutClick,
                    shape = RoundedCornerShape(12.dp),
                    colors = ButtonDefaults.outlinedButtonColors(contentColor = TigerError),
                    border = androidx.compose.foundation.BorderStroke(1.dp, TigerError),
                    modifier = Modifier.fillMaxWidth().testTag("logout_button")
                ) {
                    Text("Log Out")
                }
            }
        }
    }

    // Edit Profile Dialog
    if (showEditProfileDialog) {
        AlertDialog(
            onDismissRequest = { showEditProfileDialog = false },
            title = { Text("Edit Profile", color = TigerTextPrimary) },
            text = {
                Column {
                    OutlinedTextField(
                        value = editName,
                        onValueChange = { editName = it },
                        label = { Text("Display Name") },
                        modifier = Modifier.fillMaxWidth()
                    )
                    Spacer(modifier = Modifier.height(10.dp))
                    OutlinedTextField(
                        value = editBio,
                        onValueChange = { editBio = it },
                        label = { Text("Bio") },
                        modifier = Modifier.fillMaxWidth()
                    )
                }
            },
            confirmButton = {
                Button(
                    onClick = {
                        onEditProfile(editName, editBio)
                        showEditProfileDialog = false
                    },
                    colors = ButtonDefaults.buttonColors(containerColor = TigerOrange, contentColor = Color.Black)
                ) {
                    Text("Save Changes")
                }
            },
            dismissButton = {
                TextButton(onClick = { showEditProfileDialog = false }) {
                    Text("Cancel", color = TigerTextSecondary)
                }
            },
            containerColor = TigerCarbonSurfaceElevated
        )
    }
}
