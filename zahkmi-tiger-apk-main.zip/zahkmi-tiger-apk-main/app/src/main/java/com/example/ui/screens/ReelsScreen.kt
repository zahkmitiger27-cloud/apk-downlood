package com.example.ui.screens

import androidx.compose.animation.AnimatedVisibility
import androidx.compose.animation.core.*
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.pager.VerticalPager
import androidx.compose.foundation.pager.rememberPagerState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material.icons.outlined.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.rotate
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.R
import com.example.model.ReelComment
import com.example.model.ReelVideo
import com.example.ui.theme.*
import kotlinx.coroutines.flow.Flow
import kotlin.math.sin

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun ReelsScreen(
    reels: List<ReelVideo>,
    onLikeClick: (ReelVideo) -> Unit,
    onFollowClick: (ReelVideo) -> Unit,
    onCommentSubmit: (String, String) -> Unit,
    getCommentsFlow: (String) -> Flow<List<ReelComment>>,
    onReportReel: (ReelVideo, String) -> Unit,
    modifier: Modifier = Modifier
) {
    if (reels.isEmpty()) {
        Box(
            modifier = modifier.fillMaxSize(),
            contentAlignment = Alignment.Center
        ) {
            Text("No reels available yet. Upload the first reel!", color = TigerTextSecondary)
        }
        return
    }

    val pagerState = rememberPagerState(pageCount = { reels.size })
    var activeCommentsReel by remember { mutableStateOf<ReelVideo?>(null) }
    var reportReelTarget by remember { mutableStateOf<ReelVideo?>(null) }

    Box(modifier = modifier.fillMaxSize().testTag("reels_screen")) {
        VerticalPager(
            state = pagerState,
            modifier = Modifier.fillMaxSize()
        ) { page ->
            val reel = reels[page]
            ReelItemPage(
                reel = reel,
                onLike = { onLikeClick(reel) },
                onFollow = { onFollowClick(reel) },
                onOpenComments = { activeCommentsReel = reel },
                onReport = { reportReelTarget = reel }
            )
        }

        // Comments Bottom Sheet
        if (activeCommentsReel != null) {
            val reel = activeCommentsReel!!
            val comments by getCommentsFlow(reel.id).collectAsState(initial = emptyList())
            var newCommentText by remember { mutableStateOf("") }

            ModalBottomSheet(
                onDismissRequest = { activeCommentsReel = null },
                containerColor = TigerCarbonSurfaceElevated
            ) {
                Column(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(16.dp)
                        .navigationBarsPadding()
                ) {
                    Text(
                        text = "Comments (${comments.size})",
                        color = TigerTextPrimary,
                        fontSize = 16.sp,
                        fontWeight = FontWeight.Bold
                    )
                    Spacer(modifier = Modifier.height(12.dp))

                    LazyColumn(
                        modifier = Modifier
                            .fillMaxWidth()
                            .weight(1f, fill = false)
                            .heightIn(max = 280.dp)
                    ) {
                        items(comments) { comment ->
                            Row(
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .padding(vertical = 6.dp),
                                verticalAlignment = Alignment.Top
                            ) {
                                Box(
                                    modifier = Modifier
                                        .size(32.dp)
                                        .clip(CircleShape)
                                        .background(TigerOrangeDark),
                                    contentAlignment = Alignment.Center
                                ) {
                                    Text(
                                        text = comment.userName.take(1).uppercase(),
                                        color = Color.White,
                                        fontWeight = FontWeight.Bold,
                                        fontSize = 12.sp
                                    )
                                }
                                Spacer(modifier = Modifier.width(10.dp))
                                Column {
                                    Text(
                                        text = comment.userName,
                                        color = TigerOrangeLight,
                                        fontSize = 12.sp,
                                        fontWeight = FontWeight.Bold
                                    )
                                    Text(
                                        text = comment.content,
                                        color = TigerTextPrimary,
                                        fontSize = 13.sp
                                    )
                                    Text(
                                        text = comment.timestamp,
                                        color = TigerTextMuted,
                                        fontSize = 10.sp
                                    )
                                }
                            }
                        }
                    }

                    Spacer(modifier = Modifier.height(12.dp))

                    // Comment input
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        OutlinedTextField(
                            value = newCommentText,
                            onValueChange = { newCommentText = it },
                            placeholder = { Text("Add a comment...", color = TigerTextMuted) },
                            modifier = Modifier.weight(1f),
                            shape = RoundedCornerShape(20.dp),
                            colors = OutlinedTextFieldDefaults.colors(
                                focusedBorderColor = TigerOrange,
                                unfocusedBorderColor = TigerCarbonSurfaceBorder,
                                focusedTextColor = TigerTextPrimary,
                                unfocusedTextColor = TigerTextPrimary
                            )
                        )
                        Spacer(modifier = Modifier.width(8.dp))
                        IconButton(
                            onClick = {
                                if (newCommentText.isNotBlank()) {
                                    onCommentSubmit(reel.id, newCommentText)
                                    newCommentText = ""
                                }
                            },
                            modifier = Modifier
                                .size(44.dp)
                                .clip(CircleShape)
                                .background(TigerOrange)
                        ) {
                            Icon(
                                imageVector = Icons.Default.Send,
                                contentDescription = "Send",
                                tint = Color.Black
                            )
                        }
                    }
                }
            }
        }

        // Report Dialog
        if (reportReelTarget != null) {
            val target = reportReelTarget!!
            var reason by remember { mutableStateOf("") }
            AlertDialog(
                onDismissRequest = { reportReelTarget = null },
                title = { Text("Report Reel", color = TigerTextPrimary) },
                text = {
                    Column {
                        Text(
                            "Why are you reporting this reel by @${target.creatorName}?",
                            color = TigerTextSecondary,
                            fontSize = 13.sp
                        )
                        Spacer(modifier = Modifier.height(8.dp))
                        OutlinedTextField(
                            value = reason,
                            onValueChange = { reason = it },
                            placeholder = { Text("e.g. Inappropriate content, spam, copyright...") },
                            modifier = Modifier.fillMaxWidth()
                        )
                    }
                },
                confirmButton = {
                    Button(
                        onClick = {
                            onReportReel(target, reason)
                            reportReelTarget = null
                        },
                        colors = ButtonDefaults.buttonColors(containerColor = TigerAccent)
                    ) {
                        Text("Submit Report")
                    }
                },
                dismissButton = {
                    TextButton(onClick = { reportReelTarget = null }) {
                        Text("Cancel", color = TigerTextSecondary)
                    }
                },
                containerColor = TigerCarbonSurfaceElevated
            )
        }
    }
}

@Composable
fun ReelItemPage(
    reel: ReelVideo,
    onLike: () -> Unit,
    onFollow: () -> Unit,
    onOpenComments: () -> Unit,
    onReport: () -> Unit
) {
    var isPlaying by remember { mutableStateOf(true) }

    // Dynamic wave animation for simulated short video canvas
    val infiniteTransition = rememberInfiniteTransition(label = "reel_animation")
    val animProgress by infiniteTransition.animateFloat(
        initialValue = 0f,
        targetValue = 1f,
        animationSpec = infiniteRepeatable(
            animation = tween(durationMillis = 3500, easing = LinearEasing),
            repeatMode = RepeatMode.Restart
        ),
        label = "anim_progress"
    )

    val rotationDisc by infiniteTransition.animateFloat(
        initialValue = 0f,
        targetValue = 360f,
        animationSpec = infiniteRepeatable(
            animation = tween(durationMillis = 4000, easing = LinearEasing),
            repeatMode = RepeatMode.Restart
        ),
        label = "disc_rotation"
    )

    Box(
        modifier = Modifier
            .fillMaxSize()
            .background(TigerCarbonBackground)
            .clickable { isPlaying = !isPlaying }
    ) {
        // Simulated Video Visualizer Canvas
        Canvas(modifier = Modifier.fillMaxSize()) {
            val width = size.width
            val height = size.height

            // Gradient deep backdrop
            drawRect(
                brush = Brush.verticalGradient(
                    listOf(
                        Color(0xFF1E1005),
                        Color(0xFF0C0D12),
                        Color(0xFF1F0F02)
                    )
                )
            )

            // Animated rhythmic soundwave bars simulating video audio stream
            val barCount = 28
            val spacing = width / barCount
            for (i in 0 until barCount) {
                val phase = animProgress * 6.28f + (i * 0.4f)
                val barHeight = (height * 0.18f) * (0.3f + 0.7f * (sin(phase.toDouble()).toFloat() + 1f) / 2f)
                drawRect(
                    brush = Brush.verticalGradient(
                        listOf(TigerOrangeLight, TigerOrangeDark)
                    ),
                    topLeft = Offset(i * spacing + 4f, height * 0.55f - barHeight / 2f),
                    size = androidx.compose.ui.geometry.Size(spacing - 8f, barHeight),
                    alpha = if (isPlaying) 0.65f else 0.25f
                )
            }
        }

        // Center Pause Indicator
        AnimatedVisibility(
            visible = !isPlaying,
            modifier = Modifier.align(Alignment.Center)
        ) {
            Box(
                modifier = Modifier
                    .size(68.dp)
                    .clip(CircleShape)
                    .background(Color.Black.copy(alpha = 0.6f)),
                contentAlignment = Alignment.Center
            ) {
                Icon(
                    imageVector = Icons.Default.Pause,
                    contentDescription = "Paused",
                    tint = Color.White,
                    modifier = Modifier.size(38.dp)
                )
            }
        }

        // Right-Side Interaction Column (Like, Comments, Share, Report, Sound)
        Column(
            modifier = Modifier
                .align(Alignment.BottomEnd)
                .padding(end = 16.dp, bottom = 48.dp),
            horizontalAlignment = Alignment.CenterHorizontally,
            verticalArrangement = Arrangement.spacedBy(18.dp)
        ) {
            // Creator Avatar with Follow plus badge
            Box(contentAlignment = Alignment.BottomCenter) {
                Box(
                    modifier = Modifier
                        .size(48.dp)
                        .clip(CircleShape)
                        .border(2.dp, TigerOrange, CircleShape)
                        .background(TigerCarbonSurfaceElevated),
                    contentAlignment = Alignment.Center
                ) {
                    Image(
                        painter = painterResource(id = R.drawable.img_tiger_logo),
                        contentDescription = reel.creatorName,
                        modifier = Modifier.fillMaxSize()
                    )
                }

                if (!reel.isFollowing) {
                    Box(
                        modifier = Modifier
                            .offset(y = 8.dp)
                            .size(20.dp)
                            .clip(CircleShape)
                            .background(TigerOrange)
                            .clickable { onFollow() },
                        contentAlignment = Alignment.Center
                    ) {
                        Icon(
                            imageVector = Icons.Default.Add,
                            contentDescription = "Follow",
                            tint = Color.Black,
                            modifier = Modifier.size(14.dp)
                        )
                    }
                }
            }

            // Like Button with count
            Column(horizontalAlignment = Alignment.CenterHorizontally) {
                IconButton(
                    onClick = onLike,
                    modifier = Modifier.size(44.dp)
                ) {
                    Icon(
                        imageVector = if (reel.isLiked) Icons.Filled.Favorite else Icons.Outlined.FavoriteBorder,
                        contentDescription = "Like",
                        tint = if (reel.isLiked) TigerAccent else Color.White,
                        modifier = Modifier.size(32.dp)
                    )
                }
                Text(
                    text = "${reel.likesCount}",
                    color = Color.White,
                    fontSize = 12.sp,
                    fontWeight = FontWeight.Bold
                )
            }

            // Comment Button with count
            Column(horizontalAlignment = Alignment.CenterHorizontally) {
                IconButton(
                    onClick = onOpenComments,
                    modifier = Modifier.size(44.dp)
                ) {
                    Icon(
                        imageVector = Icons.Default.ChatBubbleOutline,
                        contentDescription = "Comments",
                        tint = Color.White,
                        modifier = Modifier.size(30.dp)
                    )
                }
                Text(
                    text = "${reel.commentsCount}",
                    color = Color.White,
                    fontSize = 12.sp,
                    fontWeight = FontWeight.Bold
                )
            }

            // Share Button
            IconButton(
                onClick = {},
                modifier = Modifier.size(44.dp)
            ) {
                Icon(
                    imageVector = Icons.Default.Share,
                    contentDescription = "Share",
                    tint = Color.White,
                    modifier = Modifier.size(28.dp)
                )
            }

            // Report Reel
            IconButton(
                onClick = onReport,
                modifier = Modifier.size(40.dp)
            ) {
                Icon(
                    imageVector = Icons.Default.MoreVert,
                    contentDescription = "Options",
                    tint = TigerTextSecondary,
                    modifier = Modifier.size(24.dp)
                )
            }

            // Spinning Audio Vinyl Disc
            Box(
                modifier = Modifier
                    .size(42.dp)
                    .clip(CircleShape)
                    .background(Color.Black)
                    .border(2.dp, TigerCarbonSurfaceBorder, CircleShape)
                    .rotate(if (isPlaying) rotationDisc else 0f),
                contentAlignment = Alignment.Center
            ) {
                Box(
                    modifier = Modifier
                        .size(16.dp)
                        .clip(CircleShape)
                        .background(TigerOrange)
                )
            }
        }

        // Bottom Left Creator & Caption Overlay
        Column(
            modifier = Modifier
                .align(Alignment.BottomStart)
                .fillMaxWidth(0.78f)
                .padding(start = 16.dp, bottom = 48.dp)
        ) {
            Row(verticalAlignment = Alignment.CenterVertically) {
                Text(
                    text = "@${reel.creatorName}",
                    color = Color.White,
                    fontSize = 16.sp,
                    fontWeight = FontWeight.Bold
                )
                Spacer(modifier = Modifier.width(6.dp))
                Icon(
                    imageVector = Icons.Default.Verified,
                    contentDescription = "Verified Creator",
                    tint = TigerOrange,
                    modifier = Modifier.size(16.dp)
                )
            }

            Spacer(modifier = Modifier.height(6.dp))

            Text(
                text = reel.caption,
                color = Color.White.copy(alpha = 0.95f),
                fontSize = 13.sp,
                lineHeight = 18.sp
            )

            Spacer(modifier = Modifier.height(8.dp))

            // Sound Bar
            Row(
                verticalAlignment = Alignment.CenterVertically,
                modifier = Modifier
                    .clip(RoundedCornerShape(12.dp))
                    .background(Color.Black.copy(alpha = 0.4f))
                    .padding(horizontal = 8.dp, vertical = 4.dp)
            ) {
                Icon(
                    imageVector = Icons.Default.MusicNote,
                    contentDescription = "Music",
                    tint = TigerOrangeLight,
                    modifier = Modifier.size(14.dp)
                )
                Spacer(modifier = Modifier.width(4.dp))
                Text(
                    text = reel.audioTitle,
                    color = Color.White,
                    fontSize = 11.sp,
                    maxLines = 1
                )
            }
        }

        // Bottom Video Progress Bar
        LinearProgressIndicator(
            progress = { animProgress },
            modifier = Modifier
                .align(Alignment.BottomCenter)
                .fillMaxWidth()
                .height(3.dp),
            color = TigerOrange,
            trackColor = Color.Transparent
        )
    }
}
