package com.example.ui.theme

import androidx.compose.ui.graphics.Color

// Dark Green Hacker Brand Palette (Matrix / Hacker Theme)
val HackerGreenPrimary = Color(0xFF00FF66)
val HackerGreenLight = Color(0xFF69F0AE)
val HackerGreenDark = Color(0xFF00C853)
val HackerGreenAccent = Color(0xFF00E676)
val HackerNeonGold = Color(0xFFFFEA00)

val HackerBackground = Color(0xFF040D07)
val HackerSurface = Color(0xFF081C10)
val HackerSurfaceElevated = Color(0xFF0F2B1A)
val HackerSurfaceBorder = Color(0xFF1B4D2E)

val HackerTextPrimary = Color(0xFFE0F2F1)
val HackerTextSecondary = Color(0xFF80CBC4)
val HackerTextMuted = Color(0xFF4DB6AC)
val HackerSuccess = Color(0xFF00E676)
val HackerError = Color(0xFFFF5252)
val HackerWarning = Color(0xFFFFAB00)

// Backward-compatible Aliases mapping to Dark Green Hacker theme
val TigerOrange = HackerGreenPrimary
val TigerOrangeLight = HackerGreenLight
val TigerOrangeDark = HackerGreenDark
val TigerGold = HackerNeonGold
val TigerYellow = HackerNeonGold
val TigerAccent = HackerGreenAccent

val TigerCarbonBackground = HackerBackground
val TigerCarbonSurface = HackerSurface
val TigerCarbonSurfaceElevated = HackerSurfaceElevated
val TigerCarbonSurfaceBorder = HackerSurfaceBorder

val TigerTextPrimary = HackerTextPrimary
val TigerTextSecondary = HackerTextSecondary
val TigerTextMuted = HackerTextMuted
val TigerSuccess = HackerSuccess
val TigerError = HackerError
val TigerWarning = HackerWarning
val TigerInfo = Color(0xFF00B0FF)
