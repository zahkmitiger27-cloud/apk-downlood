package com.example.data

import android.content.Context
import com.example.data.local.*
import com.example.data.remote.SupabaseService
import com.example.model.*
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.first
import kotlinx.coroutines.flow.map
import kotlinx.coroutines.launch
import java.text.SimpleDateFormat
import java.util.*

class StoreRepository(
    private val storeDao: StoreDao,
    private val supabaseService: SupabaseService = SupabaseService()
) {

    fun getApps(): Flow<List<StoreApp>> = storeDao.getAllApps().map { entities ->
        entities.map { it.toDomain() }
    }

    suspend fun getAppById(id: String): StoreApp? {
        return storeDao.getAppById(id)?.toDomain()
    }

    fun getReels(): Flow<List<ReelVideo>> = storeDao.getAllReels().map { entities ->
        entities.map { it.toDomain() }
    }

    fun getProducts(): Flow<List<MarketplaceProduct>> = storeDao.getAllProducts().map { entities ->
        entities.map { it.toDomain() }
    }

    fun getReviews(appId: String): Flow<List<AppReview>> = storeDao.getReviewsForApp(appId).map { entities ->
        entities.map { it.toDomain() }
    }

    fun getComments(reelId: String): Flow<List<ReelComment>> = storeDao.getCommentsForReel(reelId).map { entities ->
        entities.map { it.toDomain() }
    }

    fun getPurchases(): Flow<List<PurchaseRecord>> = storeDao.getAllPurchases().map { entities ->
        entities.map { it.toDomain() }
    }

    fun getNotifications(): Flow<List<StoreNotification>> = storeDao.getAllNotifications().map { entities ->
        entities.map { it.toDomain() }
    }

    fun getReports(): Flow<List<ContentReport>> = storeDao.getAllReports().map { entities ->
        entities.map { it.toDomain() }
    }

    suspend fun addApp(app: StoreApp) {
        storeDao.insertApp(app.toEntity())
    }

    suspend fun updateApp(app: StoreApp) {
        storeDao.updateApp(app.toEntity())
    }

    suspend fun deleteApp(appId: String) {
        storeDao.deleteApp(appId)
    }

    suspend fun addReel(reel: ReelVideo) {
        storeDao.insertReel(reel.toEntity())
    }

    suspend fun toggleLikeReel(reelId: String, currentLiked: Boolean, currentCount: Int) {
        val newLiked = !currentLiked
        val newCount = if (newLiked) currentCount + 1 else maxOf(0, currentCount - 1)
        val reels = storeDao.getAllReels().first()
        val found = reels.find { it.id == reelId }
        if (found != null) {
            storeDao.updateReel(found.copy(isLiked = newLiked, likesCount = newCount))
        }
    }

    suspend fun toggleFollowCreator(reelId: String, currentFollowing: Boolean) {
        val reels = storeDao.getAllReels().first()
        val found = reels.find { it.id == reelId }
        if (found != null) {
            storeDao.updateReel(found.copy(isFollowing = !currentFollowing))
        }
    }

    suspend fun addReelComment(reelId: String, userName: String, content: String) {
        val comment = CommentEntity(
            id = UUID.randomUUID().toString(),
            reelId = reelId,
            userName = userName,
            userAvatar = "",
            content = content,
            timestamp = "Just now",
            likesCount = 0
        )
        storeDao.insertComment(comment)
    }

    suspend fun addProduct(product: MarketplaceProduct) {
        storeDao.insertProduct(product.toEntity())
    }

    suspend fun deleteProduct(productId: String) {
        storeDao.deleteProduct(productId)
    }

    suspend fun addReview(appId: String, userName: String, rating: Int, comment: String) {
        val review = ReviewEntity(
            id = UUID.randomUUID().toString(),
            appId = appId,
            userName = userName,
            userAvatar = "",
            rating = rating,
            comment = comment,
            date = SimpleDateFormat("MMM dd, yyyy", Locale.US).format(Date()),
            helpfulCount = 0
        )
        storeDao.insertReview(review)
    }

    suspend fun recordPurchase(
        userId: String,
        itemId: String,
        itemTitle: String,
        itemType: ItemType,
        amount: Double,
        currency: String,
        paymentMethod: String,
        downloadUrl: String
    ): PurchaseRecord {
        val ref = "JT-" + UUID.randomUUID().toString().take(8).uppercase()
        val dateStr = SimpleDateFormat("yyyy-MM-dd HH:mm", Locale.US).format(Date())
        val entity = PurchaseEntity(
            id = UUID.randomUUID().toString(),
            userId = userId,
            itemId = itemId,
            itemTitle = itemTitle,
            itemType = itemType.name,
            amount = amount,
            currency = currency,
            timestamp = dateStr,
            paymentMethod = paymentMethod,
            transactionRef = ref,
            downloadUrl = downloadUrl
        )
        storeDao.insertPurchase(entity)

        // Also add purchase notification
        storeDao.insertNotification(
            NotificationEntity(
                id = UUID.randomUUID().toString(),
                title = "Order Confirmed: $itemTitle",
                message = "Your purchase for $currency ${String.format("%.2f", amount)} was verified and is ready for download. Ref: $ref",
                type = "PURCHASE",
                timestamp = "Just now",
                isRead = false
            )
        )

        return entity.toDomain()
    }

    suspend fun reportContent(
        reporterId: String,
        contentId: String,
        contentType: String,
        contentTitle: String,
        reason: String
    ) {
        val report = ReportEntity(
            id = UUID.randomUUID().toString(),
            reporterId = reporterId,
            contentId = contentId,
            contentType = contentType,
            contentTitle = contentTitle,
            reason = reason,
            timestamp = SimpleDateFormat("yyyy-MM-dd HH:mm", Locale.US).format(Date()),
            status = "PENDING"
        )
        storeDao.insertReport(report)
    }

    suspend fun updateReportStatus(reportId: String, status: String) {
        val reports = storeDao.getAllReports().first()
        val found = reports.find { it.id == reportId }
        if (found != null) {
            storeDao.updateReport(found.copy(status = status))
        }
    }

    suspend fun setAppApproval(appId: String, approved: Boolean) {
        val app = storeDao.getAppById(appId)
        if (app != null) {
            storeDao.updateApp(app.copy(isApproved = approved))
        }
    }

    suspend fun incrementDownloadCount(appId: String) {
        val app = storeDao.getAppById(appId)
        if (app != null) {
            storeDao.updateApp(app.copy(downloadCount = app.downloadCount + 1))
        }
    }

    suspend fun markNotificationAsRead(id: String) {
        storeDao.markNotificationAsRead(id)
    }

    suspend fun testSupabase(url: String, anonKey: String): Result<String> {
        return supabaseService.testConnection(url, anonKey)
    }

    suspend fun supabaseSignUp(url: String, key: String, email: String, pass: String): Result<String> {
        return supabaseService.signUpWithEmail(url, key, email, pass)
    }

    suspend fun supabaseSignIn(url: String, key: String, email: String, pass: String): Result<String> {
        return supabaseService.signInWithEmail(url, key, email, pass)
    }

    suspend fun seedInitialDataIfEmpty() {
        val existingApps = storeDao.getAllApps().first()
        if (existingApps.isEmpty()) {
            val apps = createInitialApps()
            storeDao.insertApps(apps.map { it.toEntity() })

            val reels = createInitialReels()
            storeDao.insertReels(reels.map { it.toEntity() })

            val products = createInitialProducts()
            storeDao.insertProducts(products.map { it.toEntity() })

            val reviews = createInitialReviews()
            storeDao.insertReviews(reviews.map { it.toEntity() })

            val notifications = createInitialNotifications()
            for (notif in notifications) {
                storeDao.insertNotification(notif.toEntity())
            }
        }
    }

    // Domain Mapping extensions
    private fun AppEntity.toDomain() = StoreApp(
        id = id,
        title = title,
        packageName = packageName,
        developerName = developerName,
        developerId = developerId,
        category = category,
        rating = rating,
        ratingCount = ratingCount,
        downloadCount = downloadCount,
        sizeMb = sizeMb,
        version = version,
        price = price,
        iconUrl = iconUrl,
        bannerUrl = bannerUrl,
        screenshots = screenshots,
        description = description,
        apkFileName = apkFileName,
        apkUrl = apkUrl,
        releaseDate = releaseDate,
        isApproved = isApproved,
        isEditorChoice = isEditorChoice,
        isTrending = isTrending
    )

    private fun StoreApp.toEntity() = AppEntity(
        id = id,
        title = title,
        packageName = packageName,
        developerName = developerName,
        developerId = developerId,
        category = category,
        rating = rating,
        ratingCount = ratingCount,
        downloadCount = downloadCount,
        sizeMb = sizeMb,
        version = version,
        price = price,
        iconUrl = iconUrl,
        bannerUrl = bannerUrl,
        screenshots = screenshots,
        description = description,
        apkFileName = apkFileName,
        apkUrl = apkUrl,
        releaseDate = releaseDate,
        isApproved = isApproved,
        isEditorChoice = isEditorChoice,
        isTrending = isTrending
    )

    private fun ReelEntity.toDomain() = ReelVideo(
        id = id,
        title = title,
        caption = caption,
        creatorName = creatorName,
        creatorAvatar = creatorAvatar,
        creatorId = creatorId,
        videoUrl = videoUrl,
        thumbnailUrl = thumbnailUrl,
        audioTitle = audioTitle,
        likesCount = likesCount,
        commentsCount = commentsCount,
        sharesCount = sharesCount,
        isLiked = isLiked,
        isFollowing = isFollowing,
        tags = tags,
        createdAt = createdAt,
        isApproved = isApproved
    )

    private fun ReelVideo.toEntity() = ReelEntity(
        id = id,
        title = title,
        caption = caption,
        creatorName = creatorName,
        creatorAvatar = creatorAvatar,
        creatorId = creatorId,
        videoUrl = videoUrl,
        thumbnailUrl = thumbnailUrl,
        audioTitle = audioTitle,
        likesCount = likesCount,
        commentsCount = commentsCount,
        sharesCount = sharesCount,
        isLiked = isLiked,
        isFollowing = isFollowing,
        tags = tags,
        createdAt = createdAt,
        isApproved = isApproved
    )

    private fun ProductEntity.toDomain() = MarketplaceProduct(
        id = id,
        title = title,
        description = description,
        category = category,
        price = price,
        sellerName = sellerName,
        sellerId = sellerId,
        rating = rating,
        salesCount = salesCount,
        previewImages = previewImages,
        downloadUrl = downloadUrl,
        fileType = fileType,
        fileSizeMb = fileSizeMb,
        isApproved = isApproved
    )

    private fun MarketplaceProduct.toEntity() = ProductEntity(
        id = id,
        title = title,
        description = description,
        category = category,
        price = price,
        sellerName = sellerName,
        sellerId = sellerId,
        rating = rating,
        salesCount = salesCount,
        previewImages = previewImages,
        downloadUrl = downloadUrl,
        fileType = fileType,
        fileSizeMb = fileSizeMb,
        isApproved = isApproved
    )

    private fun ReviewEntity.toDomain() = AppReview(
        id = id,
        appId = appId,
        userName = userName,
        userAvatar = userAvatar,
        rating = rating,
        comment = comment,
        date = date,
        helpfulCount = helpfulCount
    )

    private fun AppReview.toEntity() = ReviewEntity(
        id = id,
        appId = appId,
        userName = userName,
        userAvatar = userAvatar,
        rating = rating,
        comment = comment,
        date = date,
        helpfulCount = helpfulCount
    )

    private fun CommentEntity.toDomain() = ReelComment(
        id = id,
        reelId = reelId,
        userName = userName,
        userAvatar = userAvatar,
        content = content,
        timestamp = timestamp,
        likesCount = likesCount
    )

    private fun PurchaseEntity.toDomain() = PurchaseRecord(
        id = id,
        userId = userId,
        itemId = itemId,
        itemTitle = itemTitle,
        itemType = if (itemType == "APP") ItemType.APP else ItemType.MARKETPLACE_PRODUCT,
        amount = amount,
        currency = currency,
        timestamp = timestamp,
        paymentMethod = paymentMethod,
        transactionRef = transactionRef,
        downloadUrl = downloadUrl
    )

    private fun NotificationEntity.toDomain() = StoreNotification(
        id = id,
        title = title,
        message = message,
        type = type,
        timestamp = timestamp,
        isRead = isRead
    )

    private fun StoreNotification.toEntity() = NotificationEntity(
        id = id,
        title = title,
        message = message,
        type = type,
        timestamp = timestamp,
        isRead = isRead
    )

    private fun ReportEntity.toDomain() = ContentReport(
        id = id,
        reporterId = reporterId,
        contentId = contentId,
        contentType = contentType,
        contentTitle = contentTitle,
        reason = reason,
        timestamp = timestamp,
        status = status
    )

    // Seed Data Generators
    private fun createInitialApps(): List<StoreApp> = listOf(
        StoreApp(
            id = "app_1",
            title = "Tiger VPN Turbo Ultra",
            packageName = "com.jakhmitiger.vpn.turbo",
            developerName = "Tiger Global Security",
            developerId = "dev_1",
            category = "Tools",
            rating = 4.9f,
            ratingCount = 14200,
            downloadCount = 850000,
            sizeMb = 24.5,
            version = "3.2.4",
            price = 0.0,
            description = "High-speed encrypted VPN tunnel engineered for low latency gaming, streaming, and unbreakable online privacy. Features WireGuard & tiger-shield protocol.",
            apkFileName = "tigervpn-v3.2.4-release.apk",
            apkUrl = "https://releases.jakhmitiger.com/apps/tigervpn.apk",
            releaseDate = "2026-03-20",
            isApproved = true,
            isEditorChoice = true,
            isTrending = true
        ),
        StoreApp(
            id = "app_2",
            title = "Apex Predator: Tiger RPG",
            packageName = "com.jakhmi.apexpredator.game",
            developerName = "IronClaw Studios",
            developerId = "dev_2",
            category = "Games",
            rating = 4.8f,
            ratingCount = 28500,
            downloadCount = 1200000,
            sizeMb = 485.0,
            version = "1.8.0",
            price = 0.0,
            description = "Unleash primal fury in an open world cyberpunk jungle. Real-time multiplayer raids, savage combat, customizable claws, and Unreal Engine 5 mobile graphics.",
            apkFileName = "apex-predator-v1.8.0.apk",
            apkUrl = "https://releases.jakhmitiger.com/apps/apex-predator.apk",
            releaseDate = "2026-04-01",
            isApproved = true,
            isEditorChoice = true,
            isTrending = true
        ),
        StoreApp(
            id = "app_3",
            title = "DevForge Kotlin IDE",
            packageName = "com.jakhmitiger.devforge.ide",
            developerName = "ByteCraft Labs",
            developerId = "dev_3",
            category = "Productivity",
            rating = 4.7f,
            ratingCount = 6800,
            downloadCount = 195000,
            sizeMb = 68.2,
            version = "2.1.0",
            price = 4.99,
            description = "Full-featured on-device Kotlin, Python, and Android code compiler with Git synchronization, real-time syntax linting, and offline code runner.",
            apkFileName = "devforge-ide-pro.apk",
            apkUrl = "https://releases.jakhmitiger.com/apps/devforge.apk",
            releaseDate = "2026-02-14",
            isApproved = true,
            isEditorChoice = false,
            isTrending = true
        ),
        StoreApp(
            id = "app_4",
            title = "SoundWave Studio Pro",
            packageName = "com.jakhmitiger.soundwave.music",
            developerName = "VibeAudio Corp",
            developerId = "dev_4",
            category = "Entertainment",
            rating = 4.6f,
            ratingCount = 9200,
            downloadCount = 420000,
            sizeMb = 34.0,
            version = "4.0.2",
            price = 0.0,
            description = "Pro-grade audio workstation with 32-track beatmaker, 808 sub bass synthesizer, auto-tune vocal processor, and lossless FLAC exporter.",
            apkFileName = "soundwave-studio.apk",
            apkUrl = "https://releases.jakhmitiger.com/apps/soundwave.apk",
            releaseDate = "2026-01-10",
            isApproved = true,
            isEditorChoice = true,
            isTrending = false
        ),
        StoreApp(
            id = "app_5",
            title = "TigerChat End-to-End",
            packageName = "com.jakhmitiger.chat.secure",
            developerName = "Tiger Global Security",
            developerId = "dev_1",
            category = "Social",
            rating = 4.9f,
            ratingCount = 15300,
            downloadCount = 980000,
            sizeMb = 18.5,
            version = "5.1.0",
            price = 0.0,
            description = "Quantum-resistant encrypted messaging, 4K video calls, disappearing messages, secret vault mode, and cross-platform desktop sync.",
            apkFileName = "tigerchat-e2e.apk",
            apkUrl = "https://releases.jakhmitiger.com/apps/tigerchat.apk",
            releaseDate = "2026-03-25",
            isApproved = true,
            isEditorChoice = true,
            isTrending = true
        ),
        StoreApp(
            id = "app_6",
            title = "PixelForge 3D Modeler",
            packageName = "com.jakhmitiger.pixelforge.graphics",
            developerName = "VoxelWorks",
            developerId = "dev_5",
            category = "Productivity",
            rating = 4.5f,
            ratingCount = 3400,
            downloadCount = 125000,
            sizeMb = 112.0,
            version = "1.4.2",
            price = 2.99,
            description = "Intuitive touch voxel sculpting, OBJ/GLTF export for Unity and Unreal Engine, PBR materials, and real-time ray-traced preview.",
            apkFileName = "pixelforge-3d.apk",
            apkUrl = "https://releases.jakhmitiger.com/apps/pixelforge.apk",
            releaseDate = "2026-02-28",
            isApproved = true,
            isEditorChoice = false,
            isTrending = false
        ),
        StoreApp(
            id = "app_7",
            title = "CryptoTiger Wallet & DEX",
            packageName = "com.jakhmitiger.wallet.defi",
            developerName = "Tiger Blockchain DAO",
            developerId = "dev_6",
            category = "Finance",
            rating = 4.8f,
            ratingCount = 8900,
            downloadCount = 310000,
            sizeMb = 29.8,
            version = "2.5.1",
            price = 0.0,
            description = "Non-custodial multi-chain crypto wallet with instant token swaps, hardware key backup, NFT gallery, and zero-fee gas optimization.",
            apkFileName = "cryptotiger-dex.apk",
            apkUrl = "https://releases.jakhmitiger.com/apps/cryptotiger.apk",
            releaseDate = "2026-03-12",
            isApproved = true,
            isEditorChoice = false,
            isTrending = false
        ),
        StoreApp(
            id = "app_8",
            title = "Shadow Claws: Cyber Ninja",
            packageName = "com.jakhmitiger.shadowclaws",
            developerName = "NeonStrike Studios",
            developerId = "dev_7",
            category = "Games",
            rating = 4.9f,
            ratingCount = 41000,
            downloadCount = 1800000,
            sizeMb = 320.0,
            version = "3.0.0",
            price = 0.0,
            description = "Lightning-fast action slasher with fluid parkour, cybernetic katanas, boss battles, and a pulse-pounding synthwave soundtrack.",
            apkFileName = "shadowclaws-ninja.apk",
            apkUrl = "https://releases.jakhmitiger.com/apps/shadowclaws.apk",
            releaseDate = "2026-04-05",
            isApproved = true,
            isEditorChoice = true,
            isTrending = true
        )
    )

    private fun createInitialReels(): List<ReelVideo> = listOf(
        ReelVideo(
            id = "reel_1",
            title = "Apex Predator Boss Battle Gameplay",
            caption = "Took down the Cyber Behemoth on level 89 using dual tiger blades! 🔥 What weapon are you running in the new update?",
            creatorName = "TigerGamer_Pro",
            creatorId = "user_tiger1",
            audioTitle = "Tiger Bassline - Cyber Heavy Hit",
            likesCount = 14200,
            commentsCount = 384,
            sharesCount = 1920,
            tags = listOf("ApexPredator", "Gaming", "AndroidRPG", "JakhmiTiger"),
            createdAt = "2h ago",
            isApproved = true
        ),
        ReelVideo(
            id = "reel_2",
            title = "Top 5 Secret Android APKs you must install",
            caption = "Hidden productivity gems in Jakhmi Tiger Store that change your workflow completely! Save this reel for later! 📱⚡",
            creatorName = "TechPulse_Android",
            creatorId = "user_techpulse",
            audioTitle = "Lofi Vibes - Future Pulse",
            likesCount = 28900,
            commentsCount = 612,
            sharesCount = 5400,
            tags = listOf("TechTips", "AndroidAPKs", "Apps", "Productivity"),
            createdAt = "5h ago",
            isApproved = true
        ),
        ReelVideo(
            id = "reel_3",
            title = "SoundWave Studio Beat Making Demo",
            caption = "Made this insane drill beat in under 3 minutes straight on my Android tablet using SoundWave Studio! 🎹🥁",
            creatorName = "BeatMaster_Rao",
            creatorId = "user_beatmaster",
            audioTitle = "Original Beat - 808 Drill Fire",
            likesCount = 9800,
            commentsCount = 145,
            sharesCount = 890,
            tags = listOf("BeatMaker", "MusicProduction", "SoundWave", "MobileStudio"),
            createdAt = "1d ago",
            isApproved = true
        ),
        ReelVideo(
            id = "reel_4",
            title = "PixelForge 3D character sculpt speedrun",
            caption = "Sculpting a tiger cyber-warrior in 60 seconds with touch controls. Exported straight to Blender! 🎨🐯",
            creatorName = "3D_VoxelArtisan",
            creatorId = "user_voxel",
            audioTitle = "Synthwave Run - Retrowave Beats",
            likesCount = 16500,
            commentsCount = 230,
            sharesCount = 1400,
            tags = listOf("3DArt", "PixelForge", "DigitalArt", "Design"),
            createdAt = "1d ago",
            isApproved = true
        ),
        ReelVideo(
            id = "reel_5",
            title = "Shadow Claws No-Hit Boss Speedrun",
            caption = "Defeated the Neon Shogun with ZERO damage on Nightmare difficulty! Who can beat my time of 42 seconds? ⚔️",
            creatorName = "SpeedrunLord",
            creatorId = "user_speedrun",
            audioTitle = "HyperDrive - Metal Core Beat",
            likesCount = 34100,
            commentsCount = 870,
            sharesCount = 6200,
            tags = listOf("ShadowClaws", "Speedrun", "MobileGamer", "Flawless"),
            createdAt = "2d ago",
            isApproved = true
        )
    )

    private fun createInitialProducts(): List<MarketplaceProduct> = listOf(
        ReelProduct(
            id = "prod_1",
            title = "Cyber Tiger UI Kit & Flutter / Compose Source",
            description = "Complete commercial app template featuring 45+ screens, dark theme, smooth motion graphics, and clean architecture.",
            category = "UI & Graphics",
            price = 19.99,
            sellerName = "PixelTiger Studio",
            sellerId = "seller_1",
            rating = 4.9f,
            salesCount = 312,
            downloadUrl = "https://downloads.jakhmitiger.com/marketplace/cybertiger-ui-kit.zip",
            fileType = "ZIP (Figma + Kotlin)",
            fileSizeMb = 185.0
        ),
        ReelProduct(
            id = "prod_2",
            title = "808 Primal Bass & Cinematic Drum Pack",
            description = "Over 450+ royalty-free wav samples, 808 sub basses, aggressive synth plucks, and impact risers for trap & phonk producers.",
            category = "Music & SFX",
            price = 9.99,
            sellerName = "VibeAudio Corp",
            sellerId = "dev_4",
            rating = 4.8f,
            salesCount = 540,
            downloadUrl = "https://downloads.jakhmitiger.com/marketplace/primal-bass-pack.zip",
            fileType = "WAV Pack (24-bit)",
            fileSizeMb = 320.0
        ),
        ReelProduct(
            id = "prod_3",
            title = "Game-Ready Mech Tiger 3D Model (Rigged)",
            description = "PBR textured, fully rigged with 14 animations (run, attack, roar, death). Ready for Unity, Unreal Engine & Godot.",
            category = "3D Assets",
            price = 24.50,
            sellerName = "VoxelWorks",
            sellerId = "dev_5",
            rating = 5.0f,
            salesCount = 189,
            downloadUrl = "https://downloads.jakhmitiger.com/marketplace/mech-tiger-rigged.zip",
            fileType = "FBX + GLTF",
            fileSizeMb = 94.0
        ),
        ReelProduct(
            id = "prod_4",
            title = "Full Stack Supabase + Android E-Commerce Backend",
            description = "Complete backend edge functions, database migration scripts, payment webhooks, and push notification triggers.",
            category = "Code & Scripts",
            price = 29.00,
            sellerName = "ByteCraft Labs",
            sellerId = "dev_3",
            rating = 4.9f,
            salesCount = 205,
            downloadUrl = "https://downloads.jakhmitiger.com/marketplace/supabase-ecommerce-backend.zip",
            fileType = "TypeScript + SQL",
            fileSizeMb = 12.0
        ),
        ReelProduct(
            id = "prod_5",
            title = "TikTok & Reels Motion Graphics Video Preset Pack",
            description = "30 high-energy viral video templates, dynamic subtitle presets, split-screen layouts, and sound effect transitions for creators.",
            category = "Video Templates",
            price = 14.99,
            sellerName = "ViralEdits Team",
            sellerId = "seller_2",
            rating = 4.7f,
            salesCount = 478,
            downloadUrl = "https://downloads.jakhmitiger.com/marketplace/viral-reels-pack.zip",
            fileType = "MOGRT + CapCut XML",
            fileSizeMb = 210.0
        )
    )

    private fun createInitialReviews(): List<AppReview> = listOf(
        AppReview(
            id = "rev_1",
            appId = "app_1",
            userName = "Alex M.",
            rating = 5,
            comment = "Best VPN I've ever tested on Android! Ping dropped by 25ms in Apex Predator. Zero ads and blazing fast servers.",
            date = "Apr 02, 2026",
            helpfulCount = 89
        ),
        AppReview(
            id = "rev_2",
            appId = "app_1",
            userName = "Priya S.",
            rating = 5,
            comment = "Super clean interface and connects in 1 second. Love the tiger theme branding too!",
            date = "Apr 04, 2026",
            helpfulCount = 34
        ),
        AppReview(
            id = "rev_3",
            appId = "app_2",
            userName = "Rohan K.",
            rating = 5,
            comment = "Graphics are phenomenal on Snapdragon! The boss fight in chapter 3 is intense. Worth every megabyte.",
            date = "Apr 07, 2026",
            helpfulCount = 112
        )
    )

    private fun createInitialNotifications(): List<StoreNotification> = listOf(
        StoreNotification(
            id = "notif_1",
            title = "Welcome to Jakhmi Tiger Store!",
            message = "Explore top verified APKs, viral creator reels, and digital marketplace creator kits.",
            type = "SYSTEM",
            timestamp = "Just now",
            isRead = false
        ),
        StoreNotification(
            id = "notif_2",
            title = "New Update: Apex Predator v1.8.0",
            message = "IronClaw Studios released the Cyber Jungle expansion pack with new weapons.",
            type = "UPLOAD",
            timestamp = "2h ago",
            isRead = false
        )
    )

    private fun ReelProduct(
        id: String,
        title: String,
        description: String,
        category: String,
        price: Double,
        sellerName: String,
        sellerId: String,
        rating: Float,
        salesCount: Int,
        downloadUrl: String,
        fileType: String,
        fileSizeMb: Double
    ) = MarketplaceProduct(
        id = id,
        title = title,
        description = description,
        category = category,
        price = price,
        sellerName = sellerName,
        sellerId = sellerId,
        rating = rating,
        salesCount = salesCount,
        previewImages = emptyList(),
        downloadUrl = downloadUrl,
        fileType = fileType,
        fileSizeMb = fileSizeMb,
        isApproved = true
    )
}
