package com.example.data.remote

import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import okhttp3.MediaType.Companion.toMediaType
import okhttp3.OkHttpClient
import okhttp3.Request
import okhttp3.RequestBody.Companion.toRequestBody
import org.json.JSONObject
import java.util.concurrent.TimeUnit

class SupabaseService {
    private val client = OkHttpClient.Builder()
        .connectTimeout(10, TimeUnit.SECONDS)
        .readTimeout(10, TimeUnit.SECONDS)
        .build()

    suspend fun testConnection(url: String, anonKey: String): Result<String> = withContext(Dispatchers.IO) {
        try {
            if (url.isBlank() || anonKey.isBlank()) {
                return@withContext Result.failure(Exception("URL and Anon Key must not be empty"))
            }
            val cleanUrl = url.trim().removeSuffix("/")
            val request = Request.Builder()
                .url("$cleanUrl/rest/v1/")
                .addHeader("apikey", anonKey.trim())
                .addHeader("Authorization", "Bearer ${anonKey.trim()}")
                .get()
                .build()

            val response = client.newCall(request).execute()
            if (response.isSuccessful || response.code == 404 || response.code == 200) {
                Result.success("Connected successfully to Supabase! Status code: ${response.code}")
            } else {
                Result.failure(Exception("Connection failed with code ${response.code}: ${response.message}"))
            }
        } catch (e: Exception) {
            Result.failure(e)
        }
    }

    suspend fun signUpWithEmail(url: String, anonKey: String, email: String, password: String): Result<String> = withContext(Dispatchers.IO) {
        try {
            val cleanUrl = url.trim().removeSuffix("/")
            val json = JSONObject().apply {
                put("email", email)
                put("password", password)
            }
            val body = json.toString().toRequestBody("application/json".toMediaType())
            val request = Request.Builder()
                .url("$cleanUrl/auth/v1/signup")
                .addHeader("apikey", anonKey.trim())
                .post(body)
                .build()

            val response = client.newCall(request).execute()
            val responseBody = response.body?.string().orEmpty()
            if (response.isSuccessful) {
                Result.success("Registration successful! Email verification link sent.")
            } else {
                val errorMsg = try {
                    JSONObject(responseBody).optString("msg", responseBody)
                } catch (_: Exception) { responseBody }
                Result.failure(Exception(errorMsg.ifBlank { "Sign up failed (${response.code})" }))
            }
        } catch (e: Exception) {
            Result.failure(e)
        }
    }

    suspend fun signInWithEmail(url: String, anonKey: String, email: String, password: String): Result<String> = withContext(Dispatchers.IO) {
        try {
            val cleanUrl = url.trim().removeSuffix("/")
            val json = JSONObject().apply {
                put("email", email)
                put("password", password)
            }
            val body = json.toString().toRequestBody("application/json".toMediaType())
            val request = Request.Builder()
                .url("$cleanUrl/auth/v1/token?grant_type=password")
                .addHeader("apikey", anonKey.trim())
                .post(body)
                .build()

            val response = client.newCall(request).execute()
            val responseBody = response.body?.string().orEmpty()
            if (response.isSuccessful) {
                Result.success("Signed in successfully via Supabase!")
            } else {
                val errorMsg = try {
                    JSONObject(responseBody).optString("error_description", responseBody)
                } catch (_: Exception) { responseBody }
                Result.failure(Exception(errorMsg.ifBlank { "Invalid credentials (${response.code})" }))
            }
        } catch (e: Exception) {
            Result.failure(e)
        }
    }

    companion object {
        const val SQL_MIGRATION_SCRIPT = """
-- Jakhmi Tiger Store Supabase Schema & Security Setup
-- Execute this script in your Supabase project's SQL Editor

-- 1. Profiles Table
CREATE TABLE IF NOT EXISTS public.profiles (
    id UUID REFERENCES auth.users ON DELETE CASCADE PRIMARY KEY,
    username TEXT UNIQUE NOT NULL,
    display_name TEXT,
    avatar_url TEXT,
    bio TEXT,
    is_verified BOOLEAN DEFAULT false,
    is_admin BOOLEAN DEFAULT false,
    balance NUMERIC(10, 2) DEFAULT 0.00,
    created_at TIMESTAMP WITH TIME ZONE DEFAULT timezone('utc'::text, now()) NOT NULL
);

-- 2. Apps Table
CREATE TABLE IF NOT EXISTS public.apps (
    id UUID DEFAULT gen_random_uuid() PRIMARY KEY,
    title TEXT NOT NULL,
    package_name TEXT UNIQUE NOT NULL,
    developer_name TEXT NOT NULL,
    developer_id UUID REFERENCES public.profiles(id),
    category TEXT NOT NULL,
    rating NUMERIC(3, 2) DEFAULT 5.0,
    rating_count INT DEFAULT 1,
    download_count INT DEFAULT 0,
    size_mb NUMERIC(6, 2) NOT NULL,
    version TEXT NOT NULL,
    price NUMERIC(10, 2) DEFAULT 0.0,
    icon_url TEXT,
    description TEXT,
    apk_url TEXT,
    is_approved BOOLEAN DEFAULT false,
    created_at TIMESTAMP WITH TIME ZONE DEFAULT timezone('utc'::text, now()) NOT NULL
);

-- 3. Reels Table
CREATE TABLE IF NOT EXISTS public.reels (
    id UUID DEFAULT gen_random_uuid() PRIMARY KEY,
    title TEXT NOT NULL,
    caption TEXT,
    creator_id UUID REFERENCES public.profiles(id),
    video_url TEXT NOT NULL,
    thumbnail_url TEXT,
    audio_title TEXT,
    likes_count INT DEFAULT 0,
    comments_count INT DEFAULT 0,
    shares_count INT DEFAULT 0,
    is_approved BOOLEAN DEFAULT true,
    created_at TIMESTAMP WITH TIME ZONE DEFAULT timezone('utc'::text, now()) NOT NULL
);

-- 4. Marketplace Products
CREATE TABLE IF NOT EXISTS public.marketplace_products (
    id UUID DEFAULT gen_random_uuid() PRIMARY KEY,
    title TEXT NOT NULL,
    description TEXT,
    category TEXT NOT NULL,
    price NUMERIC(10, 2) NOT NULL,
    seller_id UUID REFERENCES public.profiles(id),
    rating NUMERIC(3, 2) DEFAULT 5.0,
    sales_count INT DEFAULT 0,
    download_url TEXT,
    file_type TEXT,
    file_size_mb NUMERIC(6, 2),
    is_approved BOOLEAN DEFAULT true,
    created_at TIMESTAMP WITH TIME ZONE DEFAULT timezone('utc'::text, now()) NOT NULL
);

-- 5. Enable Row Level Security (RLS)
ALTER TABLE public.profiles ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.apps ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.reels ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.marketplace_products ENABLE ROW LEVEL SECURITY;

-- 6. Storage Buckets
INSERT INTO storage.buckets (id, name, public) VALUES 
('app-icons', 'app-icons', true),
('app-apks', 'app-apks', false),
('reel-videos', 'reel-videos', true),
('marketplace-files', 'marketplace-files', false)
ON CONFLICT (id) DO NOTHING;
"""
    }
}
