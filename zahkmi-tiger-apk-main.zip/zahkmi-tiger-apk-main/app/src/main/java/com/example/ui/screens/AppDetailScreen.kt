package com.example.ui.screens

import androidx.activity.compose.BackHandler
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.R
import com.example.model.AppReview
import com.example.model.Currency
import com.example.model.StoreApp
import com.example.ui.components.InteractiveStarRating
import com.example.ui.components.SecurityShieldBadge
import com.example.ui.theme.*
import com.example.ui.viewmodel.DownloadStatus
import kotlinx.coroutines.flow.Flow

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun AppDetailScreen(
    app: StoreApp,
    currency: Currency,
    downloadStatus: DownloadStatus,
    downloadProgress: Float,
    reviewsFlow: Flow<List<AppReview>>,
    onBack: () -> Unit,
    onDownload: () -> Unit,
    onSubmitReview: (Int, String) -> Unit,
    onReportApp: (String) -> Unit,
    modifier: Modifier = Modifier
) {
    BackHandler { onBack() }

    val reviews by reviewsFlow.collectAsState(initial = emptyList())
    var userRating by remember { mutableStateOf(5) }
    var userComment by remember { mutableStateOf("") }
    var showReportDialog by remember { mutableStateOf(false) }
    var reportReason by remember { mutableStateOf("") }

    Scaffold(
        topBar = {
            TopAppBar(
                title = { Text(app.title, maxLines = 1, color = TigerTextPrimary) },
                navigationIcon = {
                    IconButton(onClick = onBack) {
                        Icon(
                            imageVector = Icons.AutoMirrored.Filled.ArrowBack,
                            contentDescription = "Back",
                            tint = TigerTextPrimary
                        )
                    }
                },
                actions = {
                    IconButton(onClick = { showReportDialog = true }) {
                        Icon(
                            imageVector = Icons.Default.Flag,
                            contentDescription = "Report",
                            tint = TigerTextSecondary
                        )
                    }
                },
                colors = TopAppBarDefaults.topAppBarColors(containerColor = TigerCarbonBackground)
            )
        },
        containerColor = TigerCarbonBackground,
        modifier = modifier.fillMaxSize().testTag("app_detail_screen")
    ) { padding ->
        LazyColumn(
            modifier = Modifier
                .fillMaxSize()
                .padding(padding),
            contentPadding = PaddingValues(16.dp)
        ) {
            // App Header Row: Icon, Title, Developer, Category
            item {
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Box(
                        modifier = Modifier
                            .size(80.dp)
                            .clip(RoundedCornerShape(18.dp))
                            .background(
                                Brush.linearGradient(
                                    listOf(TigerOrangeDark, TigerOrange)
                                )
                            ),
                        contentAlignment = Alignment.Center
                    ) {
                        if (app.id == "app_1" || app.id == "app_5") {
                            Image(
                                painter = painterResource(id = R.drawable.img_tiger_logo),
                                contentDescription = app.title,
                                modifier = Modifier.fillMaxSize().clip(RoundedCornerShape(18.dp))
                            )
                        } else {
                            Icon(
                                imageVector = Icons.Default.Apps,
                                contentDescription = app.title,
                                tint = Color.White,
                                modifier = Modifier.size(40.dp)
                            )
                        }
                    }

                    Spacer(modifier = Modifier.width(16.dp))

                    Column(modifier = Modifier.weight(1f)) {
                        Text(
                            text = app.title,
                            color = TigerTextPrimary,
                            fontSize = 19.sp,
                            fontWeight = FontWeight.Bold
                        )
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Text(
                                text = app.developerName,
                                color = TigerOrangeLight,
                                fontSize = 13.sp,
                                fontWeight = FontWeight.SemiBold
                            )
                            Spacer(modifier = Modifier.width(4.dp))
                            Icon(
                                imageVector = Icons.Default.CheckCircle,
                                contentDescription = "Verified Developer",
                                tint = TigerOrange,
                                modifier = Modifier.size(14.dp)
                            )
                        }
                        Text(
                            text = "${app.category} • Contains APK",
                            color = TigerTextMuted,
                            fontSize = 12.sp
                        )
                    }
                }
            }

            // Quick Stats Pill: Rating, Downloads, Size
            item {
                Spacer(modifier = Modifier.height(18.dp))
                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .clip(RoundedCornerShape(14.dp))
                        .background(TigerCarbonSurface)
                        .padding(vertical = 12.dp),
                    horizontalArrangement = Arrangement.SpaceEvenly,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Column(horizontalAlignment = Alignment.CenterHorizontally) {
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Text(
                                text = "${app.rating}",
                                color = TigerTextPrimary,
                                fontSize = 15.sp,
                                fontWeight = FontWeight.Bold
                            )
                            Spacer(modifier = Modifier.width(2.dp))
                            Icon(
                                imageVector = Icons.Default.Star,
                                contentDescription = "Star",
                                tint = TigerGold,
                                modifier = Modifier.size(16.dp)
                            )
                        }
                        Text(
                            text = "${app.ratingCount} reviews",
                            color = TigerTextMuted,
                            fontSize = 11.sp
                        )
                    }

                    Divider(
                        modifier = Modifier
                            .height(30.dp)
                            .width(1.dp),
                        color = TigerCarbonSurfaceBorder
                    )

                    Column(horizontalAlignment = Alignment.CenterHorizontally) {
                        Text(
                            text = "${app.downloadCount / 1000}K+",
                            color = TigerTextPrimary,
                            fontSize = 15.sp,
                            fontWeight = FontWeight.Bold
                        )
                        Text(
                            text = "Downloads",
                            color = TigerTextMuted,
                            fontSize = 11.sp
                        )
                    }

                    Divider(
                        modifier = Modifier
                            .height(30.dp)
                            .width(1.dp),
                        color = TigerCarbonSurfaceBorder
                    )

                    Column(horizontalAlignment = Alignment.CenterHorizontally) {
                        Text(
                            text = "${app.sizeMb} MB",
                            color = TigerTextPrimary,
                            fontSize = 15.sp,
                            fontWeight = FontWeight.Bold
                        )
                        Text(
                            text = "Package Size",
                            color = TigerTextMuted,
                            fontSize = 11.sp
                        )
                    }
                }
            }

            // Primary Download Button with status indicators
            item {
                Spacer(modifier = Modifier.height(16.dp))
                when (downloadStatus) {
                    DownloadStatus.DOWNLOADING -> {
                        Column(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalAlignment = Alignment.CenterHorizontally
                        ) {
                            LinearProgressIndicator(
                                progress = { downloadProgress },
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .height(10.dp)
                                    .clip(RoundedCornerShape(5.dp)),
                                color = TigerOrange,
                                trackColor = TigerCarbonSurfaceElevated
                            )
                            Spacer(modifier = Modifier.height(6.dp))
                            Text(
                                text = "Downloading APK (${(downloadProgress * 100).toInt()}%)...",
                                color = TigerOrangeLight,
                                fontSize = 12.sp,
                                fontWeight = FontWeight.Bold
                            )
                        }
                    }
                    DownloadStatus.SCANNING -> {
                        Surface(
                            shape = RoundedCornerShape(24.dp),
                            color = TigerInfo.copy(alpha = 0.2f),
                            border = androidx.compose.foundation.BorderStroke(1.dp, TigerInfo),
                            modifier = Modifier.fillMaxWidth().height(48.dp)
                        ) {
                            Row(
                                modifier = Modifier.fillMaxSize(),
                                verticalAlignment = Alignment.CenterVertically,
                                horizontalArrangement = Arrangement.Center
                            ) {
                                CircularProgressIndicator(
                                    modifier = Modifier.size(20.dp),
                                    color = TigerInfo,
                                    strokeWidth = 2.dp
                                )
                                Spacer(modifier = Modifier.width(10.dp))
                                Text(
                                    text = "Scanning APK for malware...",
                                    color = TigerInfo,
                                    fontSize = 14.sp,
                                    fontWeight = FontWeight.Bold
                                )
                            }
                        }
                    }
                    DownloadStatus.VERIFYING -> {
                        Surface(
                            shape = RoundedCornerShape(24.dp),
                            color = TigerWarning.copy(alpha = 0.2f),
                            border = androidx.compose.foundation.BorderStroke(1.dp, TigerWarning),
                            modifier = Modifier.fillMaxWidth().height(48.dp)
                        ) {
                            Box(
                                modifier = Modifier.fillMaxSize(),
                                contentAlignment = Alignment.Center
                            ) {
                                Text(
                                    text = "Verifying Android signature...",
                                    color = TigerWarning,
                                    fontSize = 14.sp,
                                    fontWeight = FontWeight.Bold
                                )
                            }
                        }
                    }
                    DownloadStatus.COMPLETED -> {
                        Surface(
                            shape = RoundedCornerShape(24.dp),
                            color = TigerSuccess.copy(alpha = 0.2f),
                            border = androidx.compose.foundation.BorderStroke(1.dp, TigerSuccess),
                            modifier = Modifier.fillMaxWidth().height(48.dp)
                        ) {
                            Row(
                                modifier = Modifier.fillMaxSize(),
                                verticalAlignment = Alignment.CenterVertically,
                                horizontalArrangement = Arrangement.Center
                            ) {
                                Icon(
                                    imageVector = Icons.Default.CheckCircle,
                                    contentDescription = "Installed",
                                    tint = TigerSuccess,
                                    modifier = Modifier.size(22.dp)
                                )
                                Spacer(modifier = Modifier.width(8.dp))
                                Text(
                                    text = "Downloaded & Ready to Install",
                                    color = TigerSuccess,
                                    fontSize = 14.sp,
                                    fontWeight = FontWeight.Bold
                                )
                            }
                        }
                    }
                    else -> {
                        Button(
                            onClick = onDownload,
                            shape = RoundedCornerShape(24.dp),
                            colors = ButtonDefaults.buttonColors(
                                containerColor = TigerOrange,
                                contentColor = Color.Black
                            ),
                            modifier = Modifier
                                .fillMaxWidth()
                                .height(48.dp)
                                .testTag("detail_download_button")
                        ) {
                            Row(verticalAlignment = Alignment.CenterVertically) {
                                Icon(
                                    imageVector = Icons.Default.Download,
                                    contentDescription = "Download APK",
                                    modifier = Modifier.size(20.dp)
                                )
                                Spacer(modifier = Modifier.width(8.dp))
                                Text(
                                    text = if (app.price == 0.0) "Download APK (Free)" else "Buy & Download (${currency.symbol}${String.format("%.2f", app.price * currency.rateFromUsd)})",
                                    fontWeight = FontWeight.Bold,
                                    fontSize = 15.sp
                                )
                            }
                        }
                    }
                }
            }

            // Security Badge
            item {
                Spacer(modifier = Modifier.height(14.dp))
                SecurityShieldBadge()
            }

            // Screenshots Gallery
            item {
                Spacer(modifier = Modifier.height(20.dp))
                Text(
                    text = "App Previews",
                    color = TigerTextPrimary,
                    fontSize = 16.sp,
                    fontWeight = FontWeight.Bold
                )
                Spacer(modifier = Modifier.height(10.dp))
                LazyRow(
                    horizontalArrangement = Arrangement.spacedBy(10.dp)
                ) {
                    items(3) { index ->
                        Card(
                            modifier = Modifier
                                .width(150.dp)
                                .height(260.dp),
                            colors = CardDefaults.cardColors(containerColor = TigerCarbonSurfaceElevated),
                            shape = RoundedCornerShape(14.dp),
                            border = androidx.compose.foundation.BorderStroke(1.dp, TigerCarbonSurfaceBorder)
                        ) {
                            Box(
                                modifier = Modifier
                                    .fillMaxSize()
                                    .background(
                                        Brush.verticalGradient(
                                            listOf(
                                                TigerCarbonSurfaceElevated,
                                                TigerOrangeDark.copy(alpha = 0.3f)
                                            )
                                        )
                                    ),
                                contentAlignment = Alignment.Center
                            ) {
                                Column(horizontalAlignment = Alignment.CenterHorizontally) {
                                    Icon(
                                        imageVector = Icons.Default.Smartphone,
                                        contentDescription = "Screenshot preview",
                                        tint = TigerOrangeLight,
                                        modifier = Modifier.size(36.dp)
                                    )
                                    Spacer(modifier = Modifier.height(8.dp))
                                    Text(
                                        text = "${app.title} UI ${index + 1}",
                                        color = TigerTextSecondary,
                                        fontSize = 11.sp
                                    )
                                }
                            }
                        }
                    }
                }
            }

            // Description
            item {
                Spacer(modifier = Modifier.height(20.dp))
                Text(
                    text = "About this app",
                    color = TigerTextPrimary,
                    fontSize = 16.sp,
                    fontWeight = FontWeight.Bold
                )
                Spacer(modifier = Modifier.height(8.dp))
                Text(
                    text = app.description,
                    color = TigerTextSecondary,
                    fontSize = 14.sp,
                    lineHeight = 20.sp
                )
            }

            // Technical Specs
            item {
                Spacer(modifier = Modifier.height(16.dp))
                Card(
                    modifier = Modifier.fillMaxWidth(),
                    colors = CardDefaults.cardColors(containerColor = TigerCarbonSurface),
                    shape = RoundedCornerShape(14.dp)
                ) {
                    Column(modifier = Modifier.padding(14.dp)) {
                        Text(
                            text = "Technical Details",
                            color = TigerOrangeLight,
                            fontWeight = FontWeight.Bold,
                            fontSize = 13.sp
                        )
                        Spacer(modifier = Modifier.height(8.dp))
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.SpaceBetween
                        ) {
                            Text("Version", color = TigerTextMuted, fontSize = 12.sp)
                            Text(app.version, color = TigerTextPrimary, fontSize = 12.sp)
                        }
                        Spacer(modifier = Modifier.height(4.dp))
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.SpaceBetween
                        ) {
                            Text("Package", color = TigerTextMuted, fontSize = 12.sp)
                            Text(app.packageName, color = TigerTextPrimary, fontSize = 12.sp)
                        }
                        Spacer(modifier = Modifier.height(4.dp))
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.SpaceBetween
                        ) {
                            Text("Updated on", color = TigerTextMuted, fontSize = 12.sp)
                            Text(app.releaseDate, color = TigerTextPrimary, fontSize = 12.sp)
                        }
                    }
                }
            }

            // Interactive Review Section
            item {
                Spacer(modifier = Modifier.height(24.dp))
                Text(
                    text = "Rate this app",
                    color = TigerTextPrimary,
                    fontSize = 16.sp,
                    fontWeight = FontWeight.Bold
                )
                Spacer(modifier = Modifier.height(8.dp))
                Card(
                    modifier = Modifier.fillMaxWidth(),
                    colors = CardDefaults.cardColors(containerColor = TigerCarbonSurface),
                    shape = RoundedCornerShape(14.dp)
                ) {
                    Column(
                        modifier = Modifier.padding(14.dp),
                        horizontalAlignment = Alignment.CenterHorizontally
                    ) {
                        InteractiveStarRating(
                            rating = userRating,
                            onRatingChanged = { userRating = it }
                        )
                        Spacer(modifier = Modifier.height(8.dp))
                        OutlinedTextField(
                            value = userComment,
                            onValueChange = { userComment = it },
                            placeholder = { Text("Write your review or feedback...", color = TigerTextMuted) },
                            modifier = Modifier.fillMaxWidth(),
                            colors = OutlinedTextFieldDefaults.colors(
                                focusedBorderColor = TigerOrange,
                                unfocusedBorderColor = TigerCarbonSurfaceBorder,
                                focusedTextColor = TigerTextPrimary,
                                unfocusedTextColor = TigerTextPrimary
                            )
                        )
                        Spacer(modifier = Modifier.height(10.dp))
                        Button(
                            onClick = {
                                onSubmitReview(userRating, userComment)
                                userComment = ""
                            },
                            colors = ButtonDefaults.buttonColors(
                                containerColor = TigerOrange,
                                contentColor = Color.Black
                            ),
                            shape = RoundedCornerShape(12.dp),
                            modifier = Modifier.fillMaxWidth()
                        ) {
                            Text("Submit Review", fontWeight = FontWeight.Bold)
                        }
                    }
                }
            }

            // Reviews List
            item {
                Spacer(modifier = Modifier.height(20.dp))
                Text(
                    text = "User Reviews (${reviews.size})",
                    color = TigerTextPrimary,
                    fontSize = 16.sp,
                    fontWeight = FontWeight.Bold
                )
            }

            items(reviews) { rev ->
                Card(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(vertical = 4.dp),
                    colors = CardDefaults.cardColors(containerColor = TigerCarbonSurface),
                    shape = RoundedCornerShape(12.dp)
                ) {
                    Column(modifier = Modifier.padding(12.dp)) {
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.SpaceBetween,
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Text(
                                text = rev.userName,
                                color = TigerTextPrimary,
                                fontWeight = FontWeight.Bold,
                                fontSize = 13.sp
                            )
                            Row {
                                repeat(rev.rating) {
                                    Icon(
                                        imageVector = Icons.Default.Star,
                                        contentDescription = "Star",
                                        tint = TigerGold,
                                        modifier = Modifier.size(14.dp)
                                    )
                                }
                            }
                        }
                        Text(
                            text = rev.date,
                            color = TigerTextMuted,
                            fontSize = 11.sp
                        )
                        Spacer(modifier = Modifier.height(6.dp))
                        Text(
                            text = rev.comment,
                            color = TigerTextSecondary,
                            fontSize = 13.sp
                        )
                    }
                }
            }
        }
    }

    // Report Dialog
    if (showReportDialog) {
        AlertDialog(
            onDismissRequest = { showReportDialog = false },
            title = { Text("Report App: ${app.title}", color = TigerTextPrimary) },
            text = {
                Column {
                    Text(
                        "Help us keep Jakhmi Tiger Store safe. Please state the reason for reporting this application:",
                        color = TigerTextSecondary,
                        fontSize = 13.sp
                    )
                    Spacer(modifier = Modifier.height(8.dp))
                    OutlinedTextField(
                        value = reportReason,
                        onValueChange = { reportReason = it },
                        placeholder = { Text("e.g. Malware, Fake app, Copyright infringement...") },
                        modifier = Modifier.fillMaxWidth()
                    )
                }
            },
            confirmButton = {
                Button(
                    onClick = {
                        onReportApp(reportReason)
                        showReportDialog = false
                        reportReason = ""
                    },
                    colors = ButtonDefaults.buttonColors(containerColor = TigerAccent)
                ) {
                    Text("Submit Report")
                }
            },
            dismissButton = {
                TextButton(onClick = { showReportDialog = false }) {
                    Text("Cancel", color = TigerTextSecondary)
                }
            },
            containerColor = TigerCarbonSurfaceElevated
        )
    }
}
