package com.example.ui.screens

import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.items
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.model.AppCategory
import com.example.model.Currency
import com.example.model.StoreApp
import com.example.ui.components.SecurityShieldBadge
import com.example.ui.components.TigerAppCard
import com.example.ui.theme.*
import com.example.ui.viewmodel.DownloadStatus

@Composable
fun AppsScreen(
    apps: List<StoreApp>,
    searchQuery: String,
    selectedCategory: String,
    onCategorySelected: (String) -> Unit,
    currency: Currency,
    downloadStatusMap: Map<String, DownloadStatus>,
    downloadProgressMap: Map<String, Float>,
    onAppClick: (StoreApp) -> Unit,
    onDownloadApp: (StoreApp) -> Unit,
    modifier: Modifier = Modifier
) {
    var sortOption by remember { mutableStateOf("DOWNLOADS") } // DOWNLOADS, RATING, PAID

    val filteredApps = remember(apps, searchQuery, selectedCategory, sortOption) {
        var list = apps.filter { it.isApproved }
        if (selectedCategory != "All") {
            list = list.filter { it.category.equals(selectedCategory, ignoreCase = true) }
        }
        if (searchQuery.isNotBlank()) {
            list = list.filter {
                it.title.contains(searchQuery, ignoreCase = true) ||
                it.description.contains(searchQuery, ignoreCase = true) ||
                it.category.contains(searchQuery, ignoreCase = true) ||
                it.developerName.contains(searchQuery, ignoreCase = true)
            }
        }
        when (sortOption) {
            "RATING" -> list.sortedByDescending { it.rating }
            "PAID" -> list.sortedByDescending { it.price }
            else -> list.sortedByDescending { it.downloadCount }
        }
    }

    LazyColumn(
        modifier = modifier
            .fillMaxSize()
            .testTag("apps_screen_lazy_column"),
        contentPadding = PaddingValues(bottom = 24.dp)
    ) {
        // Category Chips Row
        item {
            LazyRow(
                modifier = Modifier.fillMaxWidth(),
                contentPadding = PaddingValues(horizontal = 16.dp, vertical = 8.dp),
                horizontalArrangement = Arrangement.spacedBy(8.dp)
            ) {
                items(AppCategory.values()) { cat ->
                    val isSelected = selectedCategory.equals(cat.displayName, ignoreCase = true)
                    FilterChip(
                        selected = isSelected,
                        onClick = { onCategorySelected(cat.displayName) },
                        label = {
                            Text(
                                text = cat.displayName,
                                fontSize = 12.sp,
                                fontWeight = if (isSelected) FontWeight.Bold else FontWeight.Medium
                            )
                        },
                        colors = FilterChipDefaults.filterChipColors(
                            selectedContainerColor = TigerOrange,
                            selectedLabelColor = Color.Black,
                            containerColor = TigerCarbonSurfaceElevated,
                            labelColor = TigerTextPrimary
                        ),
                        border = FilterChipDefaults.filterChipBorder(
                            enabled = true,
                            selected = isSelected,
                            borderColor = if (isSelected) TigerOrange else TigerCarbonSurfaceBorder
                        )
                    )
                }
            }
        }

        // Sort Tabs: Top Free, Top Rated, Top Grossing
        item {
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(horizontal = 16.dp, vertical = 6.dp),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Row(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                    listOf("DOWNLOADS" to "Top Charts", "RATING" to "Top Rated", "PAID" to "Premium").forEach { (key, label) ->
                        val active = sortOption == key
                        Surface(
                            shape = androidx.compose.foundation.shape.RoundedCornerShape(8.dp),
                            color = if (active) TigerOrange.copy(alpha = 0.2f) else TigerCarbonSurfaceElevated,
                            border = androidx.compose.foundation.BorderStroke(
                                1.dp,
                                if (active) TigerOrange else TigerCarbonSurfaceBorder
                            ),
                            modifier = androidx.compose.ui.Modifier.clickable { sortOption = key }
                        ) {
                            Text(
                                text = label,
                                color = if (active) TigerOrangeLight else TigerTextSecondary,
                                fontSize = 11.sp,
                                fontWeight = if (active) FontWeight.Bold else FontWeight.Normal,
                                modifier = Modifier.padding(horizontal = 10.dp, vertical = 6.dp)
                            )
                        }
                    }
                }

                Text(
                    text = "${filteredApps.size} apps",
                    color = TigerTextMuted,
                    fontSize = 12.sp
                )
            }
        }

        // Security Banner
        item {
            Box(modifier = Modifier.padding(horizontal = 16.dp, vertical = 6.dp)) {
                SecurityShieldBadge()
            }
        }

        // Apps List
        if (filteredApps.isEmpty()) {
            item {
                Box(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(48.dp),
                    contentAlignment = Alignment.Center
                ) {
                    Column(horizontalAlignment = Alignment.CenterHorizontally) {
                        Icon(
                            imageVector = Icons.Default.SearchOff,
                            contentDescription = "No results",
                            tint = TigerTextMuted,
                            modifier = Modifier.size(48.dp)
                        )
                        Spacer(modifier = Modifier.height(12.dp))
                        Text(
                            text = "No apps found matching your query",
                            color = TigerTextSecondary,
                            fontSize = 14.sp
                        )
                    }
                }
            }
        } else {
            items(filteredApps) { app ->
                Box(modifier = Modifier.padding(horizontal = 16.dp, vertical = 4.dp)) {
                    TigerAppCard(
                        app = app,
                        currency = currency,
                        downloadStatus = downloadStatusMap[app.id] ?: DownloadStatus.IDLE,
                        downloadProgress = downloadProgressMap[app.id] ?: 0f,
                        onClick = { onAppClick(app) },
                        onDownloadClick = { onDownloadApp(app) }
                    )
                }
            }
        }
    }
}
