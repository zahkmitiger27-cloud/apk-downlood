package com.example.ui.components

import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.navigationBarsPadding
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material.icons.outlined.*
import androidx.compose.material3.*
import androidx.compose.runtime.Composable
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.ui.theme.*
import com.example.ui.viewmodel.NavigationTab

@Composable
fun StoreBottomNav(
    currentTab: NavigationTab,
    onTabSelected: (NavigationTab) -> Unit,
    modifier: Modifier = Modifier
) {
    NavigationBar(
        modifier = modifier
            .fillMaxWidth()
            .navigationBarsPadding()
            .testTag("store_bottom_navigation"),
        containerColor = TigerCarbonBackground,
        tonalElevation = 8.dp
    ) {
        val items = listOf(
            NavigationTab.HOME to (Icons.Filled.Home to Icons.Outlined.Home),
            NavigationTab.APPS to (Icons.Filled.Apps to Icons.Outlined.Apps),
            NavigationTab.REELS to (Icons.Filled.PlayCircle to Icons.Outlined.PlayCircleOutline),
            NavigationTab.UPLOAD to (Icons.Filled.CloudUpload to Icons.Outlined.CloudUpload),
            NavigationTab.PROFILE to (Icons.Filled.Person to Icons.Outlined.PersonOutline)
        )

        items.forEach { (tab, icons) ->
            val isSelected = currentTab == tab
            NavigationBarItem(
                selected = isSelected,
                onClick = { onTabSelected(tab) },
                icon = {
                    Icon(
                        imageVector = if (isSelected) icons.first else icons.second,
                        contentDescription = tab.label
                    )
                },
                label = {
                    Text(
                        text = tab.label,
                        fontSize = 11.sp,
                        fontWeight = if (isSelected) FontWeight.Bold else FontWeight.Normal
                    )
                },
                colors = NavigationBarItemDefaults.colors(
                    selectedIconColor = TigerCarbonBackground,
                    selectedTextColor = TigerOrangeLight,
                    indicatorColor = TigerOrange,
                    unselectedIconColor = TigerTextSecondary,
                    unselectedTextColor = TigerTextMuted
                ),
                modifier = Modifier.testTag("nav_tab_${tab.name.lowercase()}")
            )
        }
    }
}
