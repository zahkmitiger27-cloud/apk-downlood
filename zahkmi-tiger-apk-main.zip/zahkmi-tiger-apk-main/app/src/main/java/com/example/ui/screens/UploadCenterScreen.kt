package com.example.ui.screens

import androidx.compose.animation.AnimatedVisibility
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.model.AppCategory
import com.example.model.ProductCategory
import com.example.model.UserAccount
import com.example.ui.theme.*
import kotlinx.coroutines.delay
import kotlinx.coroutines.launch

enum class UploadType(val label: String, val subtitle: String) {
    APK("APK / App", "Publish Android Application Package"),
    REEL("Short Reel", "Upload TikTok-style creator video"),
    PRODUCT("Digital Product", "Sell kits, code, 3D models & sound")
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun UploadCenterScreen(
    currentUser: UserAccount?,
    onUploadApp: (String, String, String, String, Double, Double, String, () -> Unit) -> Unit,
    onUploadReel: (String, String, String, List<String>, () -> Unit) -> Unit,
    onUploadProduct: (String, String, String, Double, String, Double, () -> Unit) -> Unit,
    onNeedAuth: () -> Unit,
    modifier: Modifier = Modifier
) {
    var selectedType by remember { mutableStateOf(UploadType.APK) }

    // Common fields
    var title by remember { mutableStateOf("") }
    var description by remember { mutableStateOf("") }
    var category by remember { mutableStateOf("Tools") }
    var priceText by remember { mutableStateOf("0.0") }

    // APK specific
    var packageName by remember { mutableStateOf("com.example.myapp") }
    var version by remember { mutableStateOf("1.0.0") }
    var sizeText by remember { mutableStateOf("25.0") }

    // Reel specific
    var audioTitle by remember { mutableStateOf("") }
    var tagsText by remember { mutableStateOf("Android, JakhmiTiger, Gaming") }

    // Product specific
    var fileType by remember { mutableStateOf("ZIP Package") }

    // Upload state simulation
    var isUploading by remember { mutableStateOf(false) }
    var uploadProgress by remember { mutableStateOf(0f) }
    var validationError by remember { mutableStateOf<String?>(null) }
    val coroutineScope = rememberCoroutineScope()

    LazyColumn(
        modifier = modifier
            .fillMaxSize()
            .testTag("upload_center_screen"),
        contentPadding = PaddingValues(16.dp)
    ) {
        // Header
        item {
            Text(
                text = "Creator Upload Center",
                color = TigerTextPrimary,
                fontSize = 22.sp,
                fontWeight = FontWeight.Bold
            )
            Text(
                text = "Distribute APKs, upload viral reels, or sell digital assets",
                color = TigerTextSecondary,
                fontSize = 13.sp
            )
            Spacer(modifier = Modifier.height(16.dp))
        }

        // Upload Type Selector Tabs
        item {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.spacedBy(8.dp)
            ) {
                UploadType.values().forEach { type ->
                    val isSelected = selectedType == type
                    Surface(
                        modifier = Modifier
                            .weight(1f)
                            .clip(RoundedCornerShape(12.dp))
                            .clickable {
                                selectedType = type
                                validationError = null
                            },
                        color = if (isSelected) TigerOrange else TigerCarbonSurface,
                        border = androidx.compose.foundation.BorderStroke(
                            1.dp,
                            if (isSelected) TigerOrange else TigerCarbonSurfaceBorder
                        )
                    ) {
                        Column(
                            modifier = Modifier.padding(10.dp),
                            horizontalAlignment = Alignment.CenterHorizontally
                        ) {
                            Text(
                                text = type.label,
                                color = if (isSelected) Color.Black else TigerTextPrimary,
                                fontSize = 12.sp,
                                fontWeight = FontWeight.Bold
                            )
                        }
                    }
                }
            }
            Spacer(modifier = Modifier.height(16.dp))
        }

        // Upload File Card Picker Simulator
        item {
            Card(
                modifier = Modifier
                    .fillMaxWidth()
                    .clickable { /* Simulates file picker */ },
                colors = CardDefaults.cardColors(containerColor = TigerCarbonSurface),
                shape = RoundedCornerShape(16.dp),
                border = androidx.compose.foundation.BorderStroke(1.dp, TigerCarbonSurfaceBorder)
            ) {
                Column(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(20.dp),
                    horizontalAlignment = Alignment.CenterHorizontally
                ) {
                    Icon(
                        imageVector = when (selectedType) {
                            UploadType.APK -> Icons.Default.Android
                            UploadType.REEL -> Icons.Default.VideoLibrary
                            UploadType.PRODUCT -> Icons.Default.AttachFile
                        },
                        contentDescription = "Upload Icon",
                        tint = TigerOrange,
                        modifier = Modifier.size(44.dp)
                    )
                    Spacer(modifier = Modifier.height(8.dp))
                    Text(
                        text = "Selected Package: ${title.ifBlank { "Untitled" }}.${if (selectedType == UploadType.APK) "apk" else if (selectedType == UploadType.REEL) "mp4" else "zip"}",
                        color = TigerTextPrimary,
                        fontWeight = FontWeight.Bold,
                        fontSize = 13.sp
                    )
                    Text(
                        text = "File validated • Ready for Jakhmi Tiger Cloud Storage",
                        color = TigerTextSecondary,
                        fontSize = 11.sp
                    )
                }
            }
            Spacer(modifier = Modifier.height(16.dp))
        }

        // Form Fields
        item {
            Text(
                text = "Item Details",
                color = TigerOrangeLight,
                fontWeight = FontWeight.Bold,
                fontSize = 14.sp
            )
            Spacer(modifier = Modifier.height(8.dp))

            // Title
            OutlinedTextField(
                value = title,
                onValueChange = { title = it },
                label = { Text("Title / Name") },
                modifier = Modifier.fillMaxWidth().testTag("upload_title_input"),
                colors = OutlinedTextFieldDefaults.colors(
                    focusedBorderColor = TigerOrange,
                    unfocusedBorderColor = TigerCarbonSurfaceBorder,
                    focusedTextColor = TigerTextPrimary,
                    unfocusedTextColor = TigerTextPrimary
                )
            )

            Spacer(modifier = Modifier.height(10.dp))

            // Description / Caption
            OutlinedTextField(
                value = description,
                onValueChange = { description = it },
                label = { Text(if (selectedType == UploadType.REEL) "Video Caption" else "Description") },
                modifier = Modifier.fillMaxWidth().testTag("upload_desc_input"),
                minLines = 3,
                colors = OutlinedTextFieldDefaults.colors(
                    focusedBorderColor = TigerOrange,
                    unfocusedBorderColor = TigerCarbonSurfaceBorder,
                    focusedTextColor = TigerTextPrimary,
                    unfocusedTextColor = TigerTextPrimary
                )
            )

            Spacer(modifier = Modifier.height(10.dp))

            when (selectedType) {
                UploadType.APK -> {
                    OutlinedTextField(
                        value = packageName,
                        onValueChange = { packageName = it },
                        label = { Text("Android Package Name (e.g. com.my.app)") },
                        modifier = Modifier.fillMaxWidth(),
                        colors = OutlinedTextFieldDefaults.colors(
                            focusedBorderColor = TigerOrange,
                            unfocusedBorderColor = TigerCarbonSurfaceBorder,
                            focusedTextColor = TigerTextPrimary,
                            unfocusedTextColor = TigerTextPrimary
                        )
                    )
                    Spacer(modifier = Modifier.height(10.dp))
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.spacedBy(8.dp)
                    ) {
                        OutlinedTextField(
                            value = version,
                            onValueChange = { version = it },
                            label = { Text("Version") },
                            modifier = Modifier.weight(1f),
                            colors = OutlinedTextFieldDefaults.colors(
                                focusedBorderColor = TigerOrange,
                                unfocusedBorderColor = TigerCarbonSurfaceBorder,
                                focusedTextColor = TigerTextPrimary,
                                unfocusedTextColor = TigerTextPrimary
                            )
                        )
                        OutlinedTextField(
                            value = sizeText,
                            onValueChange = { sizeText = it },
                            label = { Text("Size (MB)") },
                            modifier = Modifier.weight(1f),
                            colors = OutlinedTextFieldDefaults.colors(
                                focusedBorderColor = TigerOrange,
                                unfocusedBorderColor = TigerCarbonSurfaceBorder,
                                focusedTextColor = TigerTextPrimary,
                                unfocusedTextColor = TigerTextPrimary
                            )
                        )
                    }
                    Spacer(modifier = Modifier.height(10.dp))
                    OutlinedTextField(
                        value = priceText,
                        onValueChange = { priceText = it },
                        label = { Text("Price in USD (0.0 for Free)") },
                        modifier = Modifier.fillMaxWidth(),
                        colors = OutlinedTextFieldDefaults.colors(
                            focusedBorderColor = TigerOrange,
                            unfocusedBorderColor = TigerCarbonSurfaceBorder,
                            focusedTextColor = TigerTextPrimary,
                            unfocusedTextColor = TigerTextPrimary
                        )
                    )
                }

                UploadType.REEL -> {
                    OutlinedTextField(
                        value = audioTitle,
                        onValueChange = { audioTitle = it },
                        label = { Text("Audio Track / Sound Title") },
                        modifier = Modifier.fillMaxWidth(),
                        colors = OutlinedTextFieldDefaults.colors(
                            focusedBorderColor = TigerOrange,
                            unfocusedBorderColor = TigerCarbonSurfaceBorder,
                            focusedTextColor = TigerTextPrimary,
                            unfocusedTextColor = TigerTextPrimary
                        )
                    )
                    Spacer(modifier = Modifier.height(10.dp))
                    OutlinedTextField(
                        value = tagsText,
                        onValueChange = { tagsText = it },
                        label = { Text("Hashtags (comma separated)") },
                        modifier = Modifier.fillMaxWidth(),
                        colors = OutlinedTextFieldDefaults.colors(
                            focusedBorderColor = TigerOrange,
                            unfocusedBorderColor = TigerCarbonSurfaceBorder,
                            focusedTextColor = TigerTextPrimary,
                            unfocusedTextColor = TigerTextPrimary
                        )
                    )
                }

                UploadType.PRODUCT -> {
                    OutlinedTextField(
                        value = priceText,
                        onValueChange = { priceText = it },
                        label = { Text("Price in USD ($)") },
                        modifier = Modifier.fillMaxWidth(),
                        colors = OutlinedTextFieldDefaults.colors(
                            focusedBorderColor = TigerOrange,
                            unfocusedBorderColor = TigerCarbonSurfaceBorder,
                            focusedTextColor = TigerTextPrimary,
                            unfocusedTextColor = TigerTextPrimary
                        )
                    )
                    Spacer(modifier = Modifier.height(10.dp))
                    OutlinedTextField(
                        value = fileType,
                        onValueChange = { fileType = it },
                        label = { Text("File Format (e.g. ZIP, FBX, WAV)") },
                        modifier = Modifier.fillMaxWidth(),
                        colors = OutlinedTextFieldDefaults.colors(
                            focusedBorderColor = TigerOrange,
                            unfocusedBorderColor = TigerCarbonSurfaceBorder,
                            focusedTextColor = TigerTextPrimary,
                            unfocusedTextColor = TigerTextPrimary
                        )
                    )
                }
            }

            Spacer(modifier = Modifier.height(16.dp))

            // Validation Error
            if (validationError != null) {
                Text(
                    text = validationError!!,
                    color = TigerError,
                    fontSize = 12.sp,
                    fontWeight = FontWeight.Bold
                )
                Spacer(modifier = Modifier.height(8.dp))
            }

            // Upload Progress Bar
            if (isUploading) {
                Column(modifier = Modifier.fillMaxWidth()) {
                    LinearProgressIndicator(
                        progress = { uploadProgress },
                        modifier = Modifier
                            .fillMaxWidth()
                            .height(8.dp)
                            .clip(RoundedCornerShape(4.dp)),
                        color = TigerOrange,
                        trackColor = TigerCarbonSurfaceElevated
                    )
                    Spacer(modifier = Modifier.height(6.dp))
                    Text(
                        text = "Uploading to Cloud Storage (${(uploadProgress * 100).toInt()}%)...",
                        color = TigerOrangeLight,
                        fontSize = 12.sp
                    )
                }
                Spacer(modifier = Modifier.height(12.dp))
            }

            // Submit Button
            Button(
                onClick = {
                    if (currentUser == null) {
                        onNeedAuth()
                        return@Button
                    }
                    if (title.isBlank()) {
                        validationError = "Title is required"
                        return@Button
                    }
                    if (description.isBlank()) {
                        validationError = "Description/Caption is required"
                        return@Button
                    }

                    // Start upload progress simulation
                    isUploading = true
                    uploadProgress = 0f
                    coroutineScope.launch {
                        for (i in 1..10) {
                            delay(120)
                            uploadProgress = i / 10f
                        }
                        isUploading = false

                        when (selectedType) {
                            UploadType.APK -> {
                                val price = priceText.toDoubleOrNull() ?: 0.0
                                val size = sizeText.toDoubleOrNull() ?: 20.0
                                onUploadApp(title, packageName, category, version, size, price, description) {
                                    title = ""
                                    description = ""
                                }
                            }
                            UploadType.REEL -> {
                                val tags = tagsText.split(",").map { it.trim() }
                                onUploadReel(title, description, audioTitle, tags) {
                                    title = ""
                                    description = ""
                                }
                            }
                            UploadType.PRODUCT -> {
                                val price = priceText.toDoubleOrNull() ?: 9.99
                                onUploadProduct(title, description, category, price, fileType, 45.0) {
                                    title = ""
                                    description = ""
                                }
                            }
                        }
                    }
                },
                enabled = !isUploading,
                shape = RoundedCornerShape(14.dp),
                colors = ButtonDefaults.buttonColors(
                    containerColor = TigerOrange,
                    contentColor = Color.Black
                ),
                modifier = Modifier
                    .fillMaxWidth()
                    .height(48.dp)
                    .testTag("submit_upload_button")
            ) {
                Text(
                    text = if (isUploading) "Uploading..." else "Publish to Jakhmi Tiger Store",
                    fontWeight = FontWeight.Bold,
                    fontSize = 15.sp
                )
            }
        }
    }
}
