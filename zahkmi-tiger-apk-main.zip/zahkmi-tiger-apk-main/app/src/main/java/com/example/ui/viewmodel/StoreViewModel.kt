package com.example.ui.viewmodel

import android.app.Application
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import com.example.data.StoreRepository
import com.example.data.local.StoreDatabase
import com.example.model.*
import kotlinx.coroutines.Job
import kotlinx.coroutines.delay
import kotlinx.coroutines.flow.*
import kotlinx.coroutines.launch
import java.util.UUID

enum class NavigationTab(val label: String) {
    HOME("Home"),
    APPS("Apps"),
    REELS("Reels"),
    UPLOAD("Upload"),
    PROFILE("Profile")
}

enum class DownloadStatus {
    IDLE,
    SCANNING,
    DOWNLOADING,
    VERIFYING,
    COMPLETED
}

class StoreViewModel(application: Application) : AndroidViewModel(application) {

    private val repository: StoreRepository

    init {
        val db = StoreDatabase.getDatabase(application)
        repository = StoreRepository(db.storeDao())
        viewModelScope.launch {
            repository.seedInitialDataIfEmpty()
        }
    }

    // Navigation & UI Dialogs
    private val _currentTab = MutableStateFlow(NavigationTab.HOME)
    val currentTab: StateFlow<NavigationTab> = _currentTab.asStateFlow()

    private val _selectedApp = MutableStateFlow<StoreApp?>(null)
    val selectedApp: StateFlow<StoreApp?> = _selectedApp.asStateFlow()

    private val _selectedProduct = MutableStateFlow<MarketplaceProduct?>(null)
    val selectedProduct: StateFlow<MarketplaceProduct?> = _selectedProduct.asStateFlow()

    private val _showCartSheet = MutableStateFlow(false)
    val showCartSheet: StateFlow<Boolean> = _showCartSheet.asStateFlow()

    private val _showNotificationsSheet = MutableStateFlow(false)
    val showNotificationsSheet: StateFlow<Boolean> = _showNotificationsSheet.asStateFlow()

    private val _showAuthDialog = MutableStateFlow(false)
    val showAuthDialog: StateFlow<Boolean> = _showAuthDialog.asStateFlow()

    private val _showAdminDialog = MutableStateFlow(false)
    val showAdminDialog: StateFlow<Boolean> = _showAdminDialog.asStateFlow()

    private val _showSupabaseConfigDialog = MutableStateFlow(false)
    val showSupabaseConfigDialog: StateFlow<Boolean> = _showSupabaseConfigDialog.asStateFlow()

    private val _showPoliciesDialog = MutableStateFlow(false)
    val showPoliciesDialog: StateFlow<Boolean> = _showPoliciesDialog.asStateFlow()

    private val _selectedPolicyTopic = MutableStateFlow("PRIVACY")
    val selectedPolicyTopic: StateFlow<String> = _selectedPolicyTopic.asStateFlow()

    private val _searchQuery = MutableStateFlow("")
    val searchQuery: StateFlow<String> = _searchQuery.asStateFlow()

    private val _selectedAppCategory = MutableStateFlow("All")
    val selectedAppCategory: StateFlow<String> = _selectedAppCategory.asStateFlow()

    private val _selectedProductCategory = MutableStateFlow("All Products")
    val selectedProductCategory: StateFlow<String> = _selectedProductCategory.asStateFlow()

    private val _currency = MutableStateFlow(Currency.USD)
    val currency: StateFlow<Currency> = _currency.asStateFlow()

    // Data streams from Repository
    val apps: StateFlow<List<StoreApp>> = repository.getApps()
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    val reels: StateFlow<List<ReelVideo>> = repository.getReels()
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    val products: StateFlow<List<MarketplaceProduct>> = repository.getProducts()
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    val purchases: StateFlow<List<PurchaseRecord>> = repository.getPurchases()
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    val notifications: StateFlow<List<StoreNotification>> = repository.getNotifications()
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    val reports: StateFlow<List<ContentReport>> = repository.getReports()
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    // Cart
    private val _cartItems = MutableStateFlow<List<CartItem>>(emptyList())
    val cartItems: StateFlow<List<CartItem>> = _cartItems.asStateFlow()

    // User / Auth
    private val _currentUser = MutableStateFlow<UserAccount?>(
        UserAccount(
            id = "user_tiger_main",
            email = "zahkmitiger27@gmail.com",
            username = "jakhmi_tiger",
            displayName = "Jakhmi Tiger",
            bio = "Official Jakhmi Tiger Store Administrator & Lead Creator",
            isVerified = true,
            isAdmin = true,
            balance = 250.00
        )
    )
    val currentUser: StateFlow<UserAccount?> = _currentUser.asStateFlow()

    private val _authError = MutableStateFlow<String?>(null)
    val authError: StateFlow<String?> = _authError.asStateFlow()

    private val _authSuccessMessage = MutableStateFlow<String?>(null)
    val authSuccessMessage: StateFlow<String?> = _authSuccessMessage.asStateFlow()

    // Download / Install simulation
    private val _downloadStatusMap = MutableStateFlow<Map<String, DownloadStatus>>(emptyMap())
    val downloadStatusMap: StateFlow<Map<String, DownloadStatus>> = _downloadStatusMap.asStateFlow()

    private val _downloadProgressMap = MutableStateFlow<Map<String, Float>>(emptyMap())
    val downloadProgressMap: StateFlow<Map<String, Float>> = _downloadProgressMap.asStateFlow()

    private val downloadJobs = mutableMapOf<String, Job>()

    // Supabase Config
    private val _supabaseConfig = MutableStateFlow(SupabaseConfig())
    val supabaseConfig: StateFlow<SupabaseConfig> = _supabaseConfig.asStateFlow()

    private val _supabaseStatusMessage = MutableStateFlow<String?>(null)
    val supabaseStatusMessage: StateFlow<String?> = _supabaseStatusMessage.asStateFlow()

    private val _isConnectingSupabase = MutableStateFlow(false)
    val isConnectingSupabase: StateFlow<Boolean> = _isConnectingSupabase.asStateFlow()

    // Message Banner / Toast feedback
    private val _userMessage = MutableStateFlow<String?>(null)
    val userMessage: StateFlow<String?> = _userMessage.asStateFlow()

    // Tab Navigation
    fun setTab(tab: NavigationTab) {
        _currentTab.value = tab
    }

    fun openAppDetail(app: StoreApp) {
        _selectedApp.value = app
    }

    fun closeAppDetail() {
        _selectedApp.value = null
    }

    fun openProductDetail(product: MarketplaceProduct) {
        _selectedProduct.value = product
    }

    fun closeProductDetail() {
        _selectedProduct.value = null
    }

    fun setSearchQuery(query: String) {
        _searchQuery.value = query
    }

    fun setAppCategory(category: String) {
        _selectedAppCategory.value = category
    }

    fun setProductCategory(category: String) {
        _selectedProductCategory.value = category
    }

    fun setCurrency(curr: Currency) {
        _currency.value = curr
    }

    fun toggleCartSheet(show: Boolean) {
        _showCartSheet.value = show
    }

    fun toggleNotificationsSheet(show: Boolean) {
        _showNotificationsSheet.value = show
    }

    fun toggleAuthDialog(show: Boolean) {
        _showAuthDialog.value = show
        _authError.value = null
        _authSuccessMessage.value = null
    }

    fun toggleAdminDialog(show: Boolean) {
        _showAdminDialog.value = show
    }

    fun toggleSupabaseConfigDialog(show: Boolean) {
        _showSupabaseConfigDialog.value = show
    }

    fun showPolicy(topic: String) {
        _selectedPolicyTopic.value = topic
        _showPoliciesDialog.value = true
    }

    fun closePoliciesDialog() {
        _showPoliciesDialog.value = false
    }

    fun showToast(message: String) {
        _userMessage.value = message
    }

    fun clearToast() {
        _userMessage.value = null
    }

    // Cart Operations
    fun addToCart(product: MarketplaceProduct) {
        val current = _cartItems.value.toMutableList()
        val index = current.indexOfFirst { it.product.id == product.id }
        if (index >= 0) {
            val item = current[index]
            current[index] = item.copy(quantity = item.quantity + 1)
        } else {
            current.add(CartItem(product, 1))
        }
        _cartItems.value = current
        showToast("Added '${product.title}' to cart")
    }

    fun removeFromCart(productId: String) {
        _cartItems.value = _cartItems.value.filter { it.product.id != productId }
    }

    fun clearCart() {
        _cartItems.value = emptyList()
    }

    // Checkout Flow
    fun checkout(paymentMethod: String) {
        val user = _currentUser.value
        if (user == null) {
            _showAuthDialog.value = true
            return
        }
        val items = _cartItems.value
        if (items.isEmpty()) return

        viewModelScope.launch {
            val totalUsd = items.sumOf { it.product.price * it.quantity }
            val curr = _currency.value
            val convertedTotal = totalUsd * curr.rateFromUsd

            for (item in items) {
                repository.recordPurchase(
                    userId = user.id,
                    itemId = item.product.id,
                    itemTitle = item.product.title,
                    itemType = ItemType.MARKETPLACE_PRODUCT,
                    amount = item.product.price * curr.rateFromUsd * item.quantity,
                    currency = curr.code,
                    paymentMethod = paymentMethod,
                    downloadUrl = item.product.downloadUrl
                )
            }
            clearCart()
            _showCartSheet.value = false
            showToast("Payment Successful! Downloads unlocked in your Profile.")
        }
    }

    // Single item instant purchase
    fun buyNow(product: MarketplaceProduct, paymentMethod: String) {
        val user = _currentUser.value
        if (user == null) {
            _showAuthDialog.value = true
            return
        }
        viewModelScope.launch {
            val curr = _currency.value
            repository.recordPurchase(
                userId = user.id,
                itemId = product.id,
                itemTitle = product.title,
                itemType = ItemType.MARKETPLACE_PRODUCT,
                amount = product.price * curr.rateFromUsd,
                currency = curr.code,
                paymentMethod = paymentMethod,
                downloadUrl = product.downloadUrl
            )
            showToast("Purchase successful! Download unlocked.")
        }
    }

    // Real DownloadManager and Simulation for APKs & Digital Products
    fun startDownload(context: android.content.Context, app: StoreApp) {
        val appId = app.id
        if (_downloadStatusMap.value[appId] == DownloadStatus.DOWNLOADING) return

        try {
            val downloadUrl = if (app.apkUrl.isNotBlank()) app.apkUrl else "https://releases.jakhmitiger.com/apps/${app.packageName}.apk"
            val intent = android.content.Intent(android.content.Intent.ACTION_VIEW, android.net.Uri.parse(downloadUrl)).apply {
                addFlags(android.content.Intent.FLAG_ACTIVITY_NEW_TASK)
            }
            context.startActivity(intent)
            showToast("Opening APK download in browser...")
        } catch (e: Exception) {
            showToast("Download URL: ${app.apkFileName}")
        }

        downloadJobs[appId]?.cancel()
        downloadJobs[appId] = viewModelScope.launch {
            // Phase 1: Malware and Integrity Scan
            _downloadStatusMap.value = _downloadStatusMap.value + (appId to DownloadStatus.SCANNING)
            delay(800)

            // Phase 2: High-Speed Secure Download
            _downloadStatusMap.value = _downloadStatusMap.value + (appId to DownloadStatus.DOWNLOADING)
            for (step in 1..20) {
                delay(100)
                val progress = step / 20f
                _downloadProgressMap.value = _downloadProgressMap.value + (appId to progress)
            }

            // Phase 3: Android Package Signature Verification
            _downloadStatusMap.value = _downloadStatusMap.value + (appId to DownloadStatus.VERIFYING)
            delay(600)

            // Phase 4: Download Completed
            _downloadStatusMap.value = _downloadStatusMap.value + (appId to DownloadStatus.COMPLETED)
            repository.incrementDownloadCount(appId)
            showToast("APK '${app.apkFileName}' downloaded! Ready for Android package installer.")
        }
    }

    // Reels Actions
    fun toggleLikeReel(reel: ReelVideo) {
        val user = _currentUser.value
        if (user == null) {
            _showAuthDialog.value = true
            return
        }
        viewModelScope.launch {
            repository.toggleLikeReel(reel.id, reel.isLiked, reel.likesCount)
        }
    }

    fun toggleFollowCreator(reel: ReelVideo) {
        val user = _currentUser.value
        if (user == null) {
            _showAuthDialog.value = true
            return
        }
        viewModelScope.launch {
            repository.toggleFollowCreator(reel.id, reel.isFollowing)
            val action = if (!reel.isFollowing) "Followed" else "Unfollowed"
            showToast("$action ${reel.creatorName}")
        }
    }

    fun postReelComment(reelId: String, text: String) {
        val user = _currentUser.value
        if (user == null) {
            _showAuthDialog.value = true
            return
        }
        if (text.isBlank()) return
        viewModelScope.launch {
            repository.addReelComment(reelId, user.displayName, text.trim())
            showToast("Comment posted!")
        }
    }

    fun getReelComments(reelId: String): Flow<List<ReelComment>> {
        return repository.getComments(reelId)
    }

    fun getAppReviews(appId: String): Flow<List<AppReview>> {
        return repository.getReviews(appId)
    }

    fun postAppReview(appId: String, rating: Int, comment: String) {
        val user = _currentUser.value
        if (user == null) {
            _showAuthDialog.value = true
            return
        }
        if (comment.isBlank()) return
        viewModelScope.launch {
            repository.addReview(appId, user.displayName, rating, comment.trim())
            showToast("Review submitted successfully!")
        }
    }

    fun reportContent(contentId: String, contentType: String, title: String, reason: String) {
        val user = _currentUser.value
        viewModelScope.launch {
            repository.reportContent(
                reporterId = user?.id ?: "anonymous",
                contentId = contentId,
                contentType = contentType,
                contentTitle = title,
                reason = reason
            )
            showToast("Report submitted to Jakhmi Tiger Trust & Safety team.")
        }
    }

    // Upload Center Actions
    fun uploadApp(
        title: String,
        packageName: String,
        category: String,
        version: String,
        sizeMb: Double,
        price: Double,
        description: String,
        onSuccess: () -> Unit
    ) {
        val user = _currentUser.value
        if (user == null) {
            _showAuthDialog.value = true
            return
        }
        viewModelScope.launch {
            val app = StoreApp(
                id = "app_" + UUID.randomUUID().toString().take(6),
                title = title.trim(),
                packageName = packageName.trim(),
                developerName = user.displayName,
                developerId = user.id,
                category = category,
                rating = 5.0f,
                ratingCount = 1,
                downloadCount = 0,
                sizeMb = sizeMb,
                version = version.trim(),
                price = price,
                description = description.trim(),
                apkFileName = "${packageName.trim()}-v$version.apk",
                apkUrl = "https://releases.jakhmitiger.com/uploads/${packageName.trim()}.apk",
                releaseDate = "2026-04-10",
                isApproved = true // In active store, admin verified
            )
            repository.addApp(app)
            showToast("App '${title.trim()}' published to Jakhmi Tiger Store!")
            onSuccess()
        }
    }

    fun uploadReel(
        title: String,
        caption: String,
        audioTitle: String,
        tags: List<String>,
        onSuccess: () -> Unit
    ) {
        val user = _currentUser.value
        if (user == null) {
            _showAuthDialog.value = true
            return
        }
        viewModelScope.launch {
            val reel = ReelVideo(
                id = "reel_" + UUID.randomUUID().toString().take(6),
                title = title.trim(),
                caption = caption.trim(),
                creatorName = user.displayName,
                creatorId = user.id,
                audioTitle = audioTitle.ifBlank { "Original Audio - ${user.displayName}" },
                likesCount = 0,
                commentsCount = 0,
                sharesCount = 0,
                tags = tags,
                createdAt = "Just now",
                isApproved = true
            )
            repository.addReel(reel)
            showToast("Reel video published to feed!")
            onSuccess()
        }
    }

    fun uploadProduct(
        title: String,
        description: String,
        category: String,
        price: Double,
        fileType: String,
        fileSizeMb: Double,
        onSuccess: () -> Unit
    ) {
        val user = _currentUser.value
        if (user == null) {
            _showAuthDialog.value = true
            return
        }
        viewModelScope.launch {
            val product = MarketplaceProduct(
                id = "prod_" + UUID.randomUUID().toString().take(6),
                title = title.trim(),
                description = description.trim(),
                category = category,
                price = price,
                sellerName = user.displayName,
                sellerId = user.id,
                rating = 5.0f,
                salesCount = 0,
                downloadUrl = "https://downloads.jakhmitiger.com/marketplace/${UUID.randomUUID()}.zip",
                fileType = fileType,
                fileSizeMb = fileSizeMb,
                isApproved = true
            )
            repository.addProduct(product)
            showToast("Marketplace product '${title.trim()}' listed for sale!")
            onSuccess()
        }
    }

    // Authentication & Supabase
    fun login(email: String, pass: String) {
        if (email.isBlank() || pass.isBlank()) {
            _authError.value = "Email and password cannot be empty"
            return
        }
        viewModelScope.launch {
            val cfg = _supabaseConfig.value
            if (cfg.isConnected && cfg.url.isNotBlank() && cfg.anonKey.isNotBlank()) {
                val res = repository.supabaseSignIn(cfg.url, cfg.anonKey, email, pass)
                if (res.isFailure) {
                    _authError.value = res.exceptionOrNull()?.message ?: "Supabase auth failed"
                    return@launch
                }
            }

            // Successfully set user
            val username = email.substringBefore("@")
            val user = UserAccount(
                id = "user_" + UUID.randomUUID().toString().take(6),
                email = email.trim(),
                username = username,
                displayName = username.replaceFirstChar { it.uppercase() },
                isAdmin = email.contains("admin") || email == "zahkmitiger27@gmail.com",
                isVerified = true
            )
            _currentUser.value = user
            _showAuthDialog.value = false
            showToast("Welcome back, ${user.displayName}!")
        }
    }

    fun register(email: String, pass: String, username: String) {
        if (email.isBlank() || pass.isBlank() || username.isBlank()) {
            _authError.value = "All fields are required"
            return
        }
        viewModelScope.launch {
            val cfg = _supabaseConfig.value
            if (cfg.isConnected && cfg.url.isNotBlank() && cfg.anonKey.isNotBlank()) {
                val res = repository.supabaseSignUp(cfg.url, cfg.anonKey, email, pass)
                if (res.isFailure) {
                    _authError.value = res.exceptionOrNull()?.message ?: "Supabase registration failed"
                    return@launch
                }
            }

            val user = UserAccount(
                id = "user_" + UUID.randomUUID().toString().take(6),
                email = email.trim(),
                username = username.trim().lowercase(),
                displayName = username.trim(),
                isAdmin = email == "zahkmitiger27@gmail.com",
                isVerified = true
            )
            _currentUser.value = user
            _showAuthDialog.value = false
            showToast("Account created successfully! Welcome to Jakhmi Tiger Store.")
        }
    }

    fun loginWithGoogle() {
        val user = UserAccount(
            id = "user_google_" + UUID.randomUUID().toString().take(6),
            email = "zahkmitiger27@gmail.com",
            username = "zahkmitiger",
            displayName = "Zahkmi Tiger (Google)",
            isAdmin = true,
            isVerified = true
        )
        _currentUser.value = user
        _showAuthDialog.value = false
        showToast("Signed in with Google as zahkmitiger27@gmail.com")
    }

    fun logout() {
        _currentUser.value = null
        showToast("Signed out successfully.")
    }

    fun updateProfile(displayName: String, bio: String) {
        val current = _currentUser.value ?: return
        _currentUser.value = current.copy(displayName = displayName.trim(), bio = bio.trim())
        showToast("Profile updated!")
    }

    // Supabase Settings test & save
    fun testAndSaveSupabase(url: String, key: String) {
        viewModelScope.launch {
            _isConnectingSupabase.value = true
            _supabaseStatusMessage.value = "Pinging Supabase REST service..."
            val result = repository.testSupabase(url, key)
            _isConnectingSupabase.value = false

            if (result.isSuccess) {
                _supabaseConfig.value = SupabaseConfig(
                    url = url.trim(),
                    anonKey = key.trim(),
                    isConnected = true,
                    lastSyncedAt = "Just now"
                )
                _supabaseStatusMessage.value = result.getOrNull()
                showToast("Connected to Supabase project!")
            } else {
                _supabaseStatusMessage.value = "Connection Error: ${result.exceptionOrNull()?.message}"
            }
        }
    }

    // Admin Moderation
    fun approveApp(appId: String) {
        viewModelScope.launch {
            repository.setAppApproval(appId, true)
            showToast("App approved and published.")
        }
    }

    fun rejectApp(appId: String) {
        viewModelScope.launch {
            repository.setAppApproval(appId, false)
            showToast("App removed from public store.")
        }
    }

    fun resolveReport(reportId: String) {
        viewModelScope.launch {
            repository.updateReportStatus(reportId, "RESOLVED")
            showToast("Report marked as resolved.")
        }
    }

    fun deleteItem(contentId: String, type: String) {
        viewModelScope.launch {
            when (type) {
                "APP" -> repository.deleteApp(contentId)
                "PRODUCT" -> repository.deleteProduct(contentId)
            }
            showToast("Item deleted.")
        }
    }

    fun markNotificationRead(id: String) {
        viewModelScope.launch {
            repository.markNotificationAsRead(id)
        }
    }
}
