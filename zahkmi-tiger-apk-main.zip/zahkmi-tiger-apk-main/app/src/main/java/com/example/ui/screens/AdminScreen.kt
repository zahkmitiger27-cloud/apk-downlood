package com.example.ui.screens

import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.model.ContentReport
import com.example.model.StoreApp
import com.example.ui.theme.*

@Composable
fun AdminDialog(
    isOpen: Boolean,
    apps: List<StoreApp>,
    reports: List<ContentReport>,
    onApproveApp: (String) -> Unit,
    onRejectApp: (String) -> Unit,
    onDeleteApp: (String) -> Unit,
    onResolveReport: (String) -> Unit,
    onDismiss: () -> Unit
) {
    if (!isOpen) return

    var selectedTab by remember { mutableStateOf(0) } // 0: Apps Moderation, 1: Safety Reports, 2: Analytics

    AlertDialog(
        onDismissRequest = onDismiss,
        title = {
            Row(verticalAlignment = Alignment.CenterVertically) {
                Icon(
                    imageVector = Icons.Default.AdminPanelSettings,
                    contentDescription = "Admin",
                    tint = TigerYellow,
                    modifier = Modifier.size(24.dp)
                )
                Spacer(modifier = Modifier.width(8.dp))
                Text("Admin Moderation Console", color = TigerTextPrimary, fontSize = 17.sp, fontWeight = FontWeight.Bold)
            }
        },
        text = {
            Column(modifier = Modifier.fillMaxWidth().height(400.dp).testTag("admin_dialog_content")) {
                TabRow(
                    selectedTabIndex = selectedTab,
                    containerColor = TigerCarbonSurface,
                    contentColor = TigerOrangeLight
                ) {
                    Tab(
                        selected = selectedTab == 0,
                        onClick = { selectedTab = 0 },
                        text = { Text("Apps (${apps.size})", fontSize = 11.sp) }
                    )
                    Tab(
                        selected = selectedTab == 1,
                        onClick = { selectedTab = 1 },
                        text = { Text("Reports (${reports.size})", fontSize = 11.sp) }
                    )
                    Tab(
                        selected = selectedTab == 2,
                        onClick = { selectedTab = 2 },
                        text = { Text("Analytics", fontSize = 11.sp) }
                    )
                }

                Spacer(modifier = Modifier.height(10.dp))

                when (selectedTab) {
                    0 -> {
                        // Apps Moderation
                        LazyColumn(modifier = Modifier.fillMaxSize()) {
                            items(apps) { app ->
                                Card(
                                    modifier = Modifier.fillMaxWidth().padding(vertical = 4.dp),
                                    colors = CardDefaults.cardColors(containerColor = TigerCarbonSurface),
                                    shape = RoundedCornerShape(10.dp)
                                ) {
                                    Column(modifier = Modifier.padding(10.dp)) {
                                        Row(
                                            modifier = Modifier.fillMaxWidth(),
                                            horizontalArrangement = Arrangement.SpaceBetween,
                                            verticalAlignment = Alignment.CenterVertically
                                        ) {
                                            Text(
                                                text = app.title,
                                                color = TigerTextPrimary,
                                                fontWeight = FontWeight.Bold,
                                                fontSize = 13.sp
                                            )
                                            Surface(
                                                shape = RoundedCornerShape(4.dp),
                                                color = if (app.isApproved) TigerSuccess.copy(alpha = 0.2f) else TigerError.copy(alpha = 0.2f)
                                            ) {
                                                Text(
                                                    text = if (app.isApproved) "APPROVED" else "REJECTED",
                                                    color = if (app.isApproved) TigerSuccess else TigerError,
                                                    fontSize = 9.sp,
                                                    fontWeight = FontWeight.Bold,
                                                    modifier = Modifier.padding(horizontal = 4.dp, vertical = 2.dp)
                                                )
                                            }
                                        }
                                        Text(
                                            text = "${app.packageName} • By ${app.developerName}",
                                            color = TigerTextSecondary,
                                            fontSize = 11.sp
                                        )
                                        Spacer(modifier = Modifier.height(6.dp))
                                        Row(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                                            if (!app.isApproved) {
                                                Button(
                                                    onClick = { onApproveApp(app.id) },
                                                    colors = ButtonDefaults.buttonColors(containerColor = TigerSuccess),
                                                    contentPadding = PaddingValues(horizontal = 8.dp, vertical = 2.dp),
                                                    modifier = Modifier.height(28.dp)
                                                ) {
                                                    Text("Approve", fontSize = 10.sp, color = Color.Black)
                                                }
                                            } else {
                                                Button(
                                                    onClick = { onRejectApp(app.id) },
                                                    colors = ButtonDefaults.buttonColors(containerColor = TigerWarning),
                                                    contentPadding = PaddingValues(horizontal = 8.dp, vertical = 2.dp),
                                                    modifier = Modifier.height(28.dp)
                                                ) {
                                                    Text("Suspend", fontSize = 10.sp, color = Color.Black)
                                                }
                                            }
                                            Button(
                                                onClick = { onDeleteApp(app.id) },
                                                colors = ButtonDefaults.buttonColors(containerColor = TigerError),
                                                contentPadding = PaddingValues(horizontal = 8.dp, vertical = 2.dp),
                                                modifier = Modifier.height(28.dp)
                                            ) {
                                                Text("Delete", fontSize = 10.sp, color = Color.White)
                                            }
                                        }
                                    }
                                }
                            }
                        }
                    }

                    1 -> {
                        // User Safety Reports
                        if (reports.isEmpty()) {
                            Box(modifier = Modifier.fillMaxSize(), contentAlignment = Alignment.Center) {
                                Text("No pending safety reports", color = TigerTextSecondary)
                            }
                        } else {
                            LazyColumn(modifier = Modifier.fillMaxSize()) {
                                items(reports) { rep ->
                                    Card(
                                        modifier = Modifier.fillMaxWidth().padding(vertical = 4.dp),
                                        colors = CardDefaults.cardColors(containerColor = TigerCarbonSurface),
                                        shape = RoundedCornerShape(10.dp)
                                    ) {
                                        Column(modifier = Modifier.padding(10.dp)) {
                                            Text(
                                                text = "Report on: ${rep.contentTitle} (${rep.contentType})",
                                                color = TigerOrangeLight,
                                                fontWeight = FontWeight.Bold,
                                                fontSize = 12.sp
                                            )
                                            Text(
                                                text = "Reason: ${rep.reason}",
                                                color = TigerTextPrimary,
                                                fontSize = 12.sp
                                            )
                                            Text(
                                                text = "Date: ${rep.timestamp} • Status: ${rep.status}",
                                                color = TigerTextMuted,
                                                fontSize = 10.sp
                                            )
                                            Spacer(modifier = Modifier.height(6.dp))
                                            if (rep.status != "RESOLVED") {
                                                Button(
                                                    onClick = { onResolveReport(rep.id) },
                                                    colors = ButtonDefaults.buttonColors(containerColor = TigerSuccess),
                                                    contentPadding = PaddingValues(horizontal = 8.dp, vertical = 2.dp),
                                                    modifier = Modifier.height(28.dp)
                                                ) {
                                                    Text("Mark Resolved", fontSize = 10.sp, color = Color.Black)
                                                }
                                            }
                                        }
                                    }
                                }
                            }
                        }
                    }

                    2 -> {
                        // Analytics
                        Column(modifier = Modifier.fillMaxSize()) {
                            Card(
                                modifier = Modifier.fillMaxWidth().padding(vertical = 4.dp),
                                colors = CardDefaults.cardColors(containerColor = TigerCarbonSurface)
                            ) {
                                Column(modifier = Modifier.padding(12.dp)) {
                                    Text("Platform Overview", color = TigerOrangeLight, fontWeight = FontWeight.Bold, fontSize = 13.sp)
                                    Spacer(modifier = Modifier.height(6.dp))
                                    Text("Total APK Downloads: 4,810,000+", color = TigerTextPrimary, fontSize = 12.sp)
                                    Text("Total Active Listings: ${apps.size} Applications", color = TigerTextPrimary, fontSize = 12.sp)
                                    Text("Total Safety Scans: 100% Passed Clean", color = TigerSuccess, fontSize = 12.sp)
                                    Text("Malware Detection Rate: 0.00%", color = TigerSuccess, fontSize = 12.sp)
                                }
                            }
                        }
                    }
                }
            }
        },
        confirmButton = {
            Button(
                onClick = onDismiss,
                colors = ButtonDefaults.buttonColors(containerColor = TigerOrange, contentColor = Color.Black)
            ) {
                Text("Close Console")
            }
        },
        containerColor = TigerCarbonSurfaceElevated
    )
}
