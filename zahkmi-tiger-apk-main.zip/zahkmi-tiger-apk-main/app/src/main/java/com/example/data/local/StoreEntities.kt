package com.example.data.local

import androidx.room.Entity
import androidx.room.PrimaryKey
import androidx.room.TypeConverter

class StringListConverter {
    @TypeConverter
    fun fromString(value: String): List<String> {
        if (value.isBlank()) return emptyList()
        return value.split("|||")
    }

    @TypeConverter
    fun toString(list: List<String>): String {
        return list.joinToString("|||")
    }
}

@Entity(tableName = "apps")
data class AppEntity(
    @PrimaryKey val id: String,
    val title: String,
    val packageName: String,
    val developerName: String,
    val developerId: String,
    val category: String,
    val rating: Float,
    val ratingCount: Int,
    val downloadCount: Int,
    val sizeMb: Double,
    val version: String,
    val price: Double,
    val iconUrl: String,
    val bannerUrl: String,
    val screenshots: List<String>,
    val description: String,
    val apkFileName: String,
    val apkUrl: String,
    val releaseDate: String,
    val isApproved: Boolean,
    val isEditorChoice: Boolean,
    val isTrending: Boolean
)

@Entity(tableName = "reels")
data class ReelEntity(
    @PrimaryKey val id: String,
    val title: String,
    val caption: String,
    val creatorName: String,
    val creatorAvatar: String,
    val creatorId: String,
    val videoUrl: String,
    val thumbnailUrl: String,
    val audioTitle: String,
    val likesCount: Int,
    val commentsCount: Int,
    val sharesCount: Int,
    val isLiked: Boolean,
    val isFollowing: Boolean,
    val tags: List<String>,
    val createdAt: String,
    val isApproved: Boolean
)

@Entity(tableName = "products")
data class ProductEntity(
    @PrimaryKey val id: String,
    val title: String,
    val description: String,
    val category: String,
    val price: Double,
    val sellerName: String,
    val sellerId: String,
    val rating: Float,
    val salesCount: Int,
    val previewImages: List<String>,
    val downloadUrl: String,
    val fileType: String,
    val fileSizeMb: Double,
    val isApproved: Boolean
)

@Entity(tableName = "reviews")
data class ReviewEntity(
    @PrimaryKey val id: String,
    val appId: String,
    val userName: String,
    val userAvatar: String,
    val rating: Int,
    val comment: String,
    val date: String,
    val helpfulCount: Int
)

@Entity(tableName = "comments")
data class CommentEntity(
    @PrimaryKey val id: String,
    val reelId: String,
    val userName: String,
    val userAvatar: String,
    val content: String,
    val timestamp: String,
    val likesCount: Int
)

@Entity(tableName = "purchases")
data class PurchaseEntity(
    @PrimaryKey val id: String,
    val userId: String,
    val itemId: String,
    val itemTitle: String,
    val itemType: String,
    val amount: Double,
    val currency: String,
    val timestamp: String,
    val paymentMethod: String,
    val transactionRef: String,
    val downloadUrl: String
)

@Entity(tableName = "reports")
data class ReportEntity(
    @PrimaryKey val id: String,
    val reporterId: String,
    val contentId: String,
    val contentType: String,
    val contentTitle: String,
    val reason: String,
    val timestamp: String,
    val status: String
)

@Entity(tableName = "notifications")
data class NotificationEntity(
    @PrimaryKey val id: String,
    val title: String,
    val message: String,
    val type: String,
    val timestamp: String,
    val isRead: Boolean
)
