package com.example.ui.theme

import android.app.Activity
import androidx.compose.foundation.isSystemInDarkTheme
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.darkColorScheme
import androidx.compose.material3.lightColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.runtime.SideEffect
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.toArgb
import androidx.compose.ui.platform.LocalView
import androidx.core.view.WindowCompat

private val HackerDarkColorScheme = darkColorScheme(
    primary = HackerGreenPrimary,
    onPrimary = HackerBackground,
    primaryContainer = HackerGreenDark,
    onPrimaryContainer = HackerNeonGold,
    secondary = HackerGreenAccent,
    onSecondary = HackerBackground,
    secondaryContainer = HackerSurfaceElevated,
    onSecondaryContainer = HackerGreenLight,
    tertiary = HackerNeonGold,
    onTertiary = HackerBackground,
    background = HackerBackground,
    onBackground = HackerTextPrimary,
    surface = HackerSurface,
    onSurface = HackerTextPrimary,
    surfaceVariant = HackerSurfaceElevated,
    onSurfaceVariant = HackerTextSecondary,
    outline = HackerSurfaceBorder,
    error = HackerError,
    onError = HackerBackground
)

private val HackerLightColorScheme = lightColorScheme(
    primary = HackerGreenDark,
    onPrimary = Color.White,
    primaryContainer = HackerGreenLight,
    onPrimaryContainer = HackerBackground,
    secondary = HackerGreenPrimary,
    onSecondary = HackerBackground,
    background = Color(0xFFE8F5E9),
    onBackground = Color(0xFF0A1C12),
    surface = Color.White,
    onSurface = Color(0xFF0A1C12),
    surfaceVariant = Color(0xFFC8E6C9),
    onSurfaceVariant = Color(0xFF1B5E20),
    outline = Color(0xFFA5D6A7)
)

@Composable
fun MyApplicationTheme(
    darkTheme: Boolean = true, // Default to Dark Green Hacker theme
    content: @Composable () -> Unit
) {
    val colorScheme = if (darkTheme) HackerDarkColorScheme else HackerLightColorScheme

    val view = LocalView.current
    if (!view.isInEditMode) {
        SideEffect {
            val window = (view.context as? Activity)?.window
            if (window != null) {
                window.statusBarColor = colorScheme.background.toArgb()
                window.navigationBarColor = colorScheme.background.toArgb()
                WindowCompat.getInsetsController(window, view).isAppearanceLightStatusBars = !darkTheme
                WindowCompat.getInsetsController(window, view).isAppearanceLightNavigationBars = !darkTheme
            }
        }
    }

    MaterialTheme(
        colorScheme = colorScheme,
        typography = Typography,
        content = content
    )
}
