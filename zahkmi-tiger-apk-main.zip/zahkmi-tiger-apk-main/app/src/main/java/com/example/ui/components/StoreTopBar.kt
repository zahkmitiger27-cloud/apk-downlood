package com.example.ui.components

import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material.icons.outlined.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.R
import com.example.model.Currency
import com.example.model.UserAccount
import com.example.ui.theme.*

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun StoreTopBar(
    searchQuery: String,
    onSearchQueryChange: (String) -> Unit,
    cartItemCount: Int,
    onCartClick: () -> Unit,
    unreadNotificationCount: Int,
    onNotificationClick: () -> Unit,
    currency: Currency,
    onCurrencyChange: (Currency) -> Unit,
    currentUser: UserAccount?,
    onProfileClick: () -> Unit,
    modifier: Modifier = Modifier
) {
    var isSearchExpanded by remember { mutableStateOf(false) }

    Surface(
        modifier = modifier.fillMaxWidth(),
        color = TigerCarbonBackground,
        tonalElevation = 4.dp
    ) {
        Column(
            modifier = Modifier
                .fillMaxWidth()
                .padding(horizontal = 16.dp, vertical = 8.dp)
        ) {
            Row(
                modifier = Modifier.fillMaxWidth(),
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.SpaceBetween
            ) {
                // Brand Header: Tiger Logo + Name
                Row(
                    verticalAlignment = Alignment.CenterVertically,
                    modifier = Modifier.clickable { onProfileClick() }
                ) {
                    Box(
                        modifier = Modifier
                            .size(38.dp)
                            .clip(CircleShape)
                            .border(1.5.dp, TigerOrange, CircleShape)
                    ) {
                        Image(
                            painter = painterResource(id = R.drawable.img_tiger_logo),
                            contentDescription = "Jakhmi Tiger Logo",
                            modifier = Modifier.fillMaxSize()
                        )
                    }
                    Spacer(modifier = Modifier.width(10.dp))
                    Column {
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Text(
                                text = "JAKHMI TIGER",
                                color = TigerOrangeLight,
                                fontWeight = FontWeight.Black,
                                fontSize = 16.sp,
                                letterSpacing = 0.5.sp
                            )
                            Spacer(modifier = Modifier.width(4.dp))
                            Surface(
                                shape = RoundedCornerShape(4.dp),
                                color = TigerOrangeDark
                            ) {
                                Text(
                                    text = "STORE",
                                    color = TigerYellow,
                                    fontSize = 9.sp,
                                    fontWeight = FontWeight.Bold,
                                    modifier = Modifier.padding(horizontal = 4.dp, vertical = 1.dp)
                                )
                            }
                        }
                        Text(
                            text = "Apps • Reels • Marketplace",
                            color = TigerTextSecondary,
                            fontSize = 10.sp
                        )
                    }
                }

                // Actions: Currency Chip + Cart + Notification + Profile
                Row(
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    // Currency Selector Pill
                    var showCurrencyMenu by remember { mutableStateOf(false) }
                    Box {
                        Surface(
                            modifier = Modifier
                                .clip(RoundedCornerShape(12.dp))
                                .clickable { showCurrencyMenu = true },
                            color = TigerCarbonSurfaceElevated,
                            border = androidx.compose.foundation.BorderStroke(1.dp, TigerCarbonSurfaceBorder)
                        ) {
                            Row(
                                modifier = Modifier.padding(horizontal = 8.dp, vertical = 4.dp),
                                verticalAlignment = Alignment.CenterVertically
                            ) {
                                Text(
                                    text = "${currency.symbol} ${currency.code}",
                                    color = TigerOrangeLight,
                                    fontSize = 11.sp,
                                    fontWeight = FontWeight.Bold
                                )
                                Icon(
                                    imageVector = Icons.Default.ArrowDropDown,
                                    contentDescription = "Currency",
                                    tint = TigerTextSecondary,
                                    modifier = Modifier.size(16.dp)
                                )
                            }
                        }
                        DropdownMenu(
                            expanded = showCurrencyMenu,
                            onDismissRequest = { showCurrencyMenu = false },
                            modifier = Modifier.background(TigerCarbonSurfaceElevated)
                        ) {
                            Currency.values().forEach { curr ->
                                DropdownMenuItem(
                                    text = {
                                        Text("${curr.symbol} ${curr.code}", color = TigerTextPrimary)
                                    },
                                    onClick = {
                                        onCurrencyChange(curr)
                                        showCurrencyMenu = false
                                    }
                                )
                            }
                        }
                    }

                    Spacer(modifier = Modifier.width(6.dp))

                    // Cart Icon with Badge
                    IconButton(
                        onClick = onCartClick,
                        modifier = Modifier.size(38.dp).testTag("top_bar_cart_button")
                    ) {
                        BadgedBox(
                            badge = {
                                if (cartItemCount > 0) {
                                    Badge(
                                        containerColor = TigerOrange,
                                        contentColor = Color.Black
                                    ) {
                                        Text("$cartItemCount", fontWeight = FontWeight.Bold)
                                    }
                                }
                            }
                        ) {
                            Icon(
                                imageVector = Icons.Outlined.ShoppingCart,
                                contentDescription = "Shopping Cart",
                                tint = TigerTextPrimary
                            )
                        }
                    }

                    // Notification Icon with Badge
                    IconButton(
                        onClick = onNotificationClick,
                        modifier = Modifier.size(38.dp).testTag("top_bar_notifications_button")
                    ) {
                        BadgedBox(
                            badge = {
                                if (unreadNotificationCount > 0) {
                                    Badge(
                                        containerColor = TigerAccent,
                                        contentColor = Color.White
                                    ) {
                                        Text("$unreadNotificationCount", fontWeight = FontWeight.Bold)
                                    }
                                }
                            }
                        ) {
                            Icon(
                                imageVector = Icons.Outlined.Notifications,
                                contentDescription = "Notifications",
                                tint = TigerTextPrimary
                            )
                        }
                    }
                }
            }

            Spacer(modifier = Modifier.height(8.dp))

            // Search Bar inspired by Play Store
            OutlinedTextField(
                value = searchQuery,
                onValueChange = onSearchQueryChange,
                modifier = Modifier
                    .fillMaxWidth()
                    .testTag("store_search_input"),
                placeholder = {
                    Text(
                        text = "Search apps, games, reels & products...",
                        color = TigerTextMuted,
                        fontSize = 13.sp
                    )
                },
                leadingIcon = {
                    Icon(
                        imageVector = Icons.Default.Search,
                        contentDescription = "Search",
                        tint = TigerOrange
                    )
                },
                trailingIcon = {
                    if (searchQuery.isNotEmpty()) {
                        IconButton(onClick = { onSearchQueryChange("") }) {
                            Icon(
                                imageVector = Icons.Default.Close,
                                contentDescription = "Clear",
                                tint = TigerTextSecondary
                            )
                        }
                    }
                },
                shape = RoundedCornerShape(24.dp),
                colors = OutlinedTextFieldDefaults.colors(
                    focusedBorderColor = TigerOrange,
                    unfocusedBorderColor = TigerCarbonSurfaceBorder,
                    focusedContainerColor = TigerCarbonSurface,
                    unfocusedContainerColor = TigerCarbonSurface,
                    focusedTextColor = TigerTextPrimary,
                    unfocusedTextColor = TigerTextPrimary
                ),
                singleLine = true
            )
        }
    }
}
