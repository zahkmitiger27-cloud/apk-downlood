package com.example.ui.screens

import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.*
import androidx.compose.runtime.Composable
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.ui.theme.*

@Composable
fun PoliciesDialog(
    isOpen: Boolean,
    topic: String,
    onDismiss: () -> Unit
) {
    if (!isOpen) return

    val title = when (topic) {
        "PRIVACY" -> "Privacy Policy"
        "TERMS" -> "Terms of Service"
        "COMMUNITY" -> "Community Guidelines"
        "REFUND" -> "Refund & Dispute Policy"
        else -> "Copyright & DMCA Reporting"
    }

    val content = when (topic) {
        "PRIVACY" -> """
1. Information Collected: Jakhmi Tiger Store collects minimal personal information necessary to deliver application downloads, account sessions, and creator payouts.
2. Data Security: All passwords and credentials are cryptographically hashed. We never sell or rent user data to third-party ad networks.
3. Row Level Security: Storage buckets and PostgreSQL records strictly enforce user-specific isolation.
4. Contact: For privacy requests or data deletion, reach out to zahkmitiger27@gmail.com.
        """.trimIndent()

        "TERMS" -> """
1. Acceptance of Terms: By installing or browsing Jakhmi Tiger Store, you agree to these Terms of Service.
2. Digital Deliverables: APKs and digital marketplace assets are provided with verified developer licenses.
3. User Conduct: Users must not upload malicious APKs, malware, spyware, unauthorized clones, or harmful content.
4. Account Termination: Accounts violating platform integrity or spreading malware will be permanently terminated.
        """.trimIndent()

        "COMMUNITY" -> """
1. Respect & Safety: Jakhmi Tiger Store is a premier developer community. Harassment, hate speech, or defamatory reviews are strictly prohibited.
2. Authentic Reviews: Fake ratings, automated bots, and incentivized spam reviews are filtered by automated algorithms.
3. Creator Content: Short video reels must adhere to copyright standards and respectful public discourse.
        """.trimIndent()

        "REFUND" -> """
1. 14-Day Defective Guarantee: If a paid digital product or APK fails to execute or is fundamentally defective, users may request a refund within 14 days of purchase.
2. Dispute Resolution: Our Trust & Safety team verifies the integrity of the release package before issuing a credit to your balance.
        """.trimIndent()

        else -> """
1. DMCA Compliance: Jakhmi Tiger Store promptly removes infringing materials upon receipt of a valid DMCA takedown notice.
2. How to File: Provide the package name or listing URL, evidence of original copyright ownership, and send to zahkmitiger27@gmail.com.
        """.trimIndent()
    }

    AlertDialog(
        onDismissRequest = onDismiss,
        title = {
            Text(title, color = TigerTextPrimary, fontWeight = FontWeight.Bold, fontSize = 17.sp)
        },
        text = {
            Column(
                modifier = Modifier
                    .fillMaxWidth()
                    .verticalScroll(rememberScrollState())
                    .testTag("policy_dialog_content")
            ) {
                Text(
                    text = content,
                    color = TigerTextSecondary,
                    fontSize = 13.sp,
                    lineHeight = 20.sp
                )
            }
        },
        confirmButton = {
            Button(
                onClick = onDismiss,
                colors = ButtonDefaults.buttonColors(containerColor = TigerOrange, contentColor = Color.Black)
            ) {
                Text("Got It", fontWeight = FontWeight.Bold)
            }
        },
        containerColor = TigerCarbonSurfaceElevated
    )
}
