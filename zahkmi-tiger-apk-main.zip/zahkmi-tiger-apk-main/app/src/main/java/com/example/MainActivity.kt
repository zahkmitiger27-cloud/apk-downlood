package com.example

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.BackHandler
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.compose.animation.AnimatedContent
import androidx.compose.animation.fadeIn
import androidx.compose.animation.fadeOut
import androidx.compose.animation.togetherWith
import androidx.compose.foundation.layout.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import androidx.lifecycle.viewmodel.compose.viewModel
import com.example.ui.components.StoreBottomNav
import com.example.ui.components.StoreTopBar
import com.example.ui.screens.*
import com.example.ui.theme.MyApplicationTheme
import com.example.ui.theme.TigerCarbonBackground
import com.example.ui.viewmodel.NavigationTab
import com.example.ui.viewmodel.StoreViewModel
import kotlinx.coroutines.launch

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()
        setContent {
            MyApplicationTheme {
                MainAppContent()
            }
        }
    }
}

@Composable
fun MainAppContent(
    viewModel: StoreViewModel = viewModel()
) {
    val currentTab by viewModel.currentTab.collectAsStateWithLifecycle()
    val selectedApp by viewModel.selectedApp.collectAsStateWithLifecycle()
    val selectedProduct by viewModel.selectedProduct.collectAsStateWithLifecycle()

    val apps by viewModel.apps.collectAsStateWithLifecycle()
    val reels by viewModel.reels.collectAsStateWithLifecycle()
    val products by viewModel.products.collectAsStateWithLifecycle()
    val purchases by viewModel.purchases.collectAsStateWithLifecycle()
    val notifications by viewModel.notifications.collectAsStateWithLifecycle()
    val reports by viewModel.reports.collectAsStateWithLifecycle()
    val cartItems by viewModel.cartItems.collectAsStateWithLifecycle()
    val currentUser by viewModel.currentUser.collectAsStateWithLifecycle()

    val currency by viewModel.currency.collectAsStateWithLifecycle()
    val searchQuery by viewModel.searchQuery.collectAsStateWithLifecycle()
    val selectedAppCategory by viewModel.selectedAppCategory.collectAsStateWithLifecycle()
    val downloadStatusMap by viewModel.downloadStatusMap.collectAsStateWithLifecycle()
    val downloadProgressMap by viewModel.downloadProgressMap.collectAsStateWithLifecycle()

    // Dialog states
    val showCartSheet by viewModel.showCartSheet.collectAsStateWithLifecycle()
    val showNotificationsSheet by viewModel.showNotificationsSheet.collectAsStateWithLifecycle()
    val showAuthDialog by viewModel.showAuthDialog.collectAsStateWithLifecycle()
    val showAdminDialog by viewModel.showAdminDialog.collectAsStateWithLifecycle()
    val showSupabaseConfigDialog by viewModel.showSupabaseConfigDialog.collectAsStateWithLifecycle()
    val showPoliciesDialog by viewModel.showPoliciesDialog.collectAsStateWithLifecycle()
    val selectedPolicyTopic by viewModel.selectedPolicyTopic.collectAsStateWithLifecycle()

    val authError by viewModel.authError.collectAsStateWithLifecycle()
    val authSuccessMessage by viewModel.authSuccessMessage.collectAsStateWithLifecycle()
    val supabaseConfig by viewModel.supabaseConfig.collectAsStateWithLifecycle()
    val supabaseStatusMessage by viewModel.supabaseStatusMessage.collectAsStateWithLifecycle()
    val isConnectingSupabase by viewModel.isConnectingSupabase.collectAsStateWithLifecycle()

    val userMessage by viewModel.userMessage.collectAsStateWithLifecycle()
    val snackbarHostState = remember { SnackbarHostState() }
    val scope = rememberCoroutineScope()

    LaunchedEffect(userMessage) {
        userMessage?.let {
            scope.launch {
                snackbarHostState.showSnackbar(it)
                viewModel.clearToast()
            }
        }
    }

    // Handle back button when navigating secondary views
    BackHandler(enabled = selectedApp != null || selectedProduct != null || currentTab != NavigationTab.HOME) {
        when {
            selectedApp != null -> viewModel.closeAppDetail()
            selectedProduct != null -> viewModel.closeProductDetail()
            currentTab != NavigationTab.HOME -> viewModel.setTab(NavigationTab.HOME)
        }
    }

    Scaffold(
        topBar = {
            if (selectedApp == null && selectedProduct == null) {
                StoreTopBar(
                    searchQuery = searchQuery,
                    onSearchQueryChange = { viewModel.setSearchQuery(it) },
                    cartItemCount = cartItems.size,
                    onCartClick = { viewModel.toggleCartSheet(true) },
                    unreadNotificationCount = notifications.count { !it.isRead },
                    onNotificationClick = { viewModel.toggleNotificationsSheet(true) },
                    currency = currency,
                    onCurrencyChange = { viewModel.setCurrency(it) },
                    currentUser = currentUser,
                    onProfileClick = { viewModel.setTab(NavigationTab.PROFILE) },
                    modifier = Modifier.statusBarsPadding()
                )
            }
        },
        bottomBar = {
            if (selectedApp == null && selectedProduct == null) {
                StoreBottomNav(
                    currentTab = currentTab,
                    onTabSelected = { viewModel.setTab(it) }
                )
            }
        },
        snackbarHost = { SnackbarHost(snackbarHostState) },
        containerColor = TigerCarbonBackground
    ) { innerPadding ->
        val context = LocalContext.current
        Box(
            modifier = Modifier
                .fillMaxSize()
                .padding(innerPadding)
        ) {
            when {
                selectedApp != null -> {
                    val app = selectedApp!!
                    AppDetailScreen(
                        app = app,
                        currency = currency,
                        downloadStatus = downloadStatusMap[app.id] ?: com.example.ui.viewmodel.DownloadStatus.IDLE,
                        downloadProgress = downloadProgressMap[app.id] ?: 0f,
                        reviewsFlow = viewModel.getAppReviews(app.id),
                        onBack = { viewModel.closeAppDetail() },
                        onDownload = { viewModel.startDownload(context, app) },
                        onSubmitReview = { rating, comment -> viewModel.postAppReview(app.id, rating, comment) },
                        onReportApp = { reason -> viewModel.reportContent(app.id, "APP", app.title, reason) }
                    )
                }

                selectedProduct != null -> {
                    val product = selectedProduct!!
                    ProductDetailScreen(
                        product = product,
                        currency = currency,
                        onBack = { viewModel.closeProductDetail() },
                        onAddToCart = { viewModel.addToCart(it) },
                        onBuyNow = { viewModel.buyNow(it, "Google Pay") }
                    )
                }

                else -> {
                    AnimatedContent(
                        targetState = currentTab,
                        transitionSpec = { fadeIn() togetherWith fadeOut() },
                        label = "tab_transition"
                    ) { tab ->
                        when (tab) {
                            NavigationTab.HOME -> {
                                HomeScreen(
                                    apps = apps,
                                    reels = reels,
                                    products = products,
                                    currency = currency,
                                    downloadStatusMap = downloadStatusMap,
                                    downloadProgressMap = downloadProgressMap,
                                    onAppClick = { viewModel.openAppDetail(it) },
                                    onDownloadApp = { viewModel.startDownload(context, it) },
                                    onProductClick = { viewModel.openProductDetail(it) },
                                    onNavigateTab = { viewModel.setTab(it) }
                                )
                            }

                            NavigationTab.APPS -> {
                                AppsScreen(
                                    apps = apps,
                                    searchQuery = searchQuery,
                                    selectedCategory = selectedAppCategory,
                                    onCategorySelected = { viewModel.setAppCategory(it) },
                                    currency = currency,
                                    downloadStatusMap = downloadStatusMap,
                                    downloadProgressMap = downloadProgressMap,
                                    onAppClick = { viewModel.openAppDetail(it) },
                                    onDownloadApp = { viewModel.startDownload(context, it) }
                                )
                            }

                            NavigationTab.REELS -> {
                                ReelsScreen(
                                    reels = reels,
                                    onLikeClick = { viewModel.toggleLikeReel(it) },
                                    onFollowClick = { viewModel.toggleFollowCreator(it) },
                                    onCommentSubmit = { reelId, text -> viewModel.postReelComment(reelId, text) },
                                    getCommentsFlow = { viewModel.getReelComments(it) },
                                    onReportReel = { reel, reason -> viewModel.reportContent(reel.id, "REEL", reel.title, reason) }
                                )
                            }

                            NavigationTab.UPLOAD -> {
                                UploadCenterScreen(
                                    currentUser = currentUser,
                                    onUploadApp = { title, pkg, cat, ver, size, price, desc, onOk ->
                                        viewModel.uploadApp(title, pkg, cat, ver, size, price, desc, onOk)
                                    },
                                    onUploadReel = { title, cap, audio, tags, onOk ->
                                        viewModel.uploadReel(title, cap, audio, tags, onOk)
                                    },
                                    onUploadProduct = { title, desc, cat, price, type, size, onOk ->
                                        viewModel.uploadProduct(title, desc, cat, price, type, size, onOk)
                                    },
                                    onNeedAuth = { viewModel.toggleAuthDialog(true) }
                                )
                            }

                            NavigationTab.PROFILE -> {
                                ProfileScreen(
                                    currentUser = currentUser,
                                    purchases = purchases,
                                    userApps = apps.filter { it.developerId == currentUser?.id },
                                    currency = currency,
                                    onLoginClick = { viewModel.toggleAuthDialog(true) },
                                    onLogoutClick = { viewModel.logout() },
                                    onEditProfile = { name, bio -> viewModel.updateProfile(name, bio) },
                                    onOpenAdmin = { viewModel.toggleAdminDialog(true) },
                                    onOpenSupabaseConfig = { viewModel.toggleSupabaseConfigDialog(true) },
                                    onOpenPolicy = { viewModel.showPolicy(it) }
                                )
                            }
                        }
                    }
                }
            }
        }
    }

    // Dialogs & Sheets
    CartCheckoutDialog(
        isOpen = showCartSheet,
        cartItems = cartItems,
        currency = currency,
        onCurrencyChange = { viewModel.setCurrency(it) },
        onRemoveItem = { viewModel.removeFromCart(it) },
        onCheckout = { viewModel.checkout(it) },
        onDismiss = { viewModel.toggleCartSheet(false) }
    )

    NotificationsSheet(
        isOpen = showNotificationsSheet,
        notifications = notifications,
        onMarkRead = { viewModel.markNotificationRead(it) },
        onDismiss = { viewModel.toggleNotificationsSheet(false) }
    )

    AuthDialog(
        isOpen = showAuthDialog,
        onDismiss = { viewModel.toggleAuthDialog(false) },
        onLogin = { email, pass -> viewModel.login(email, pass) },
        onRegister = { email, pass, username -> viewModel.register(email, pass, username) },
        onGoogleSignIn = { viewModel.loginWithGoogle() },
        errorMessage = authError,
        successMessage = authSuccessMessage,
        isSupabaseConnected = supabaseConfig.isConnected
    )

    AdminDialog(
        isOpen = showAdminDialog,
        apps = apps,
        reports = reports,
        onApproveApp = { viewModel.approveApp(it) },
        onRejectApp = { viewModel.rejectApp(it) },
        onDeleteApp = { viewModel.deleteItem(it, "APP") },
        onResolveReport = { viewModel.resolveReport(it) },
        onDismiss = { viewModel.toggleAdminDialog(false) }
    )

    SupabaseConfigDialog(
        isOpen = showSupabaseConfigDialog,
        currentConfig = supabaseConfig,
        statusMessage = supabaseStatusMessage,
        isConnecting = isConnectingSupabase,
        onTestAndSave = { url, key -> viewModel.testAndSaveSupabase(url, key) },
        onDismiss = { viewModel.toggleSupabaseConfigDialog(false) }
    )

    PoliciesDialog(
        isOpen = showPoliciesDialog,
        topic = selectedPolicyTopic,
        onDismiss = { viewModel.closePoliciesDialog() }
    )
}
