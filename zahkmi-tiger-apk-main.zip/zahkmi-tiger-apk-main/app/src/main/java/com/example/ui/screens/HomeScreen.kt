package com.example.ui.screens

import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.R
import com.example.model.Currency
import com.example.model.MarketplaceProduct
import com.example.model.ReelVideo
import com.example.model.StoreApp
import com.example.ui.components.SecurityShieldBadge
import com.example.ui.components.TigerAppCard
import com.example.ui.theme.*
import com.example.ui.viewmodel.DownloadStatus
import com.example.ui.viewmodel.NavigationTab

@Composable
fun HomeScreen(
    apps: List<StoreApp>,
    reels: List<ReelVideo>,
    products: List<MarketplaceProduct>,
    currency: Currency,
    downloadStatusMap: Map<String, DownloadStatus>,
    downloadProgressMap: Map<String, Float>,
    onAppClick: (StoreApp) -> Unit,
    onDownloadApp: (StoreApp) -> Unit,
    onProductClick: (MarketplaceProduct) -> Unit,
    onNavigateTab: (NavigationTab) -> Unit,
    modifier: Modifier = Modifier
) {
    var selectedCategoryChip by remember { mutableStateOf("All") }
    val categories = listOf("All", "Top Games", "Tools", "Reels", "Marketplace", "Productivity")

    val filteredApps = remember(apps, selectedCategoryChip) {
        when (selectedCategoryChip) {
            "Top Games" -> apps.filter { it.category == "Games" }
            "Tools" -> apps.filter { it.category == "Tools" }
            "Productivity" -> apps.filter { it.category == "Productivity" }
            else -> apps
        }
    }

    LazyColumn(
        modifier = modifier
            .fillMaxSize()
            .testTag("home_screen_lazy_column"),
        contentPadding = PaddingValues(bottom = 24.dp)
    ) {
        // 1. Featured Store Banner
        item {
            Card(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(horizontal = 16.dp, vertical = 8.dp)
                    .clip(RoundedCornerShape(20.dp))
                    .clickable { onNavigateTab(NavigationTab.APPS) },
                colors = CardDefaults.cardColors(containerColor = TigerCarbonSurface)
            ) {
                Box(
                    modifier = Modifier
                        .fillMaxWidth()
                        .height(180.dp)
                ) {
                    Image(
                        painter = painterResource(id = R.drawable.img_store_banner),
                        contentDescription = "Store Banner",
                        modifier = Modifier.fillMaxSize(),
                        contentScale = ContentScale.Crop
                    )
                    // Gradient overlay
                    Box(
                        modifier = Modifier
                            .fillMaxSize()
                            .background(
                                Brush.verticalGradient(
                                    listOf(
                                        Color.Transparent,
                                        Color.Black.copy(alpha = 0.85f)
                                    )
                                )
                            )
                    )
                    // Banner caption
                    Column(
                        modifier = Modifier
                            .align(Alignment.BottomStart)
                            .padding(16.dp)
                    ) {
                        Surface(
                            shape = RoundedCornerShape(6.dp),
                            color = TigerOrange
                        ) {
                            Text(
                                text = "FEATURED LAUNCH",
                                color = Color.Black,
                                fontSize = 10.sp,
                                fontWeight = FontWeight.Black,
                                modifier = Modifier.padding(horizontal = 6.dp, vertical = 2.dp)
                            )
                        }
                        Spacer(modifier = Modifier.height(4.dp))
                        Text(
                            text = "Next-Gen Mobile APKs & Digital Marketplace",
                            color = Color.White,
                            fontSize = 17.sp,
                            fontWeight = FontWeight.ExtraBold
                        )
                        Text(
                            text = "Verified developer releases • Creator short videos • Instant downloads",
                            color = TigerTextSecondary,
                            fontSize = 11.sp
                        )
                    }
                }
            }
        }

        // 2. Category Filter Chips
        item {
            LazyRow(
                modifier = Modifier.fillMaxWidth(),
                contentPadding = PaddingValues(horizontal = 16.dp, vertical = 6.dp),
                horizontalArrangement = Arrangement.spacedBy(8.dp)
            ) {
                items(categories) { cat ->
                    val isSelected = selectedCategoryChip == cat
                    FilterChip(
                        selected = isSelected,
                        onClick = { selectedCategoryChip = cat },
                        label = {
                            Text(
                                text = cat,
                                fontSize = 12.sp,
                                fontWeight = if (isSelected) FontWeight.Bold else FontWeight.Medium
                            )
                        },
                        colors = FilterChipDefaults.filterChipColors(
                            selectedContainerColor = TigerOrange,
                            selectedLabelColor = Color.Black,
                            containerColor = TigerCarbonSurfaceElevated,
                            labelColor = TigerTextPrimary
                        ),
                        border = FilterChipDefaults.filterChipBorder(
                            enabled = true,
                            selected = isSelected,
                            borderColor = if (isSelected) TigerOrange else TigerCarbonSurfaceBorder
                        )
                    )
                }
            }
        }

        // 3. Security badge
        item {
            Box(modifier = Modifier.padding(horizontal = 16.dp, vertical = 6.dp)) {
                SecurityShieldBadge()
            }
        }

        // 4. Trending Apps Carousel (Play Store style horizontal cards)
        item {
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(horizontal = 16.dp, vertical = 10.dp),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Text(
                    text = "Trending Apps & Games",
                    color = TigerTextPrimary,
                    fontSize = 18.sp,
                    fontWeight = FontWeight.Bold
                )
                Text(
                    text = "See all →",
                    color = TigerOrangeLight,
                    fontSize = 13.sp,
                    fontWeight = FontWeight.SemiBold,
                    modifier = Modifier.clickable { onNavigateTab(NavigationTab.APPS) }
                )
            }

            LazyRow(
                modifier = Modifier.fillMaxWidth(),
                contentPadding = PaddingValues(horizontal = 16.dp),
                horizontalArrangement = Arrangement.spacedBy(12.dp)
            ) {
                items(apps.take(4)) { app ->
                    Card(
                        modifier = Modifier
                            .width(160.dp)
                            .clip(RoundedCornerShape(16.dp))
                            .clickable { onAppClick(app) },
                        colors = CardDefaults.cardColors(containerColor = TigerCarbonSurface),
                        border = androidx.compose.foundation.BorderStroke(1.dp, TigerCarbonSurfaceBorder)
                    ) {
                        Column(
                            modifier = Modifier.padding(12.dp)
                        ) {
                            Box(
                                modifier = Modifier
                                    .size(60.dp)
                                    .clip(RoundedCornerShape(14.dp))
                                    .background(TigerOrangeDark),
                                contentAlignment = Alignment.Center
                            ) {
                                if (app.id == "app_1" || app.id == "app_5") {
                                    Image(
                                        painter = painterResource(id = R.drawable.img_tiger_logo),
                                        contentDescription = app.title,
                                        modifier = Modifier.fillMaxSize().clip(RoundedCornerShape(14.dp))
                                    )
                                } else {
                                    Icon(
                                        imageVector = Icons.Default.SportsEsports,
                                        contentDescription = app.title,
                                        tint = Color.White,
                                        modifier = Modifier.size(32.dp)
                                    )
                                }
                            }
                            Spacer(modifier = Modifier.height(10.dp))
                            Text(
                                text = app.title,
                                color = TigerTextPrimary,
                                fontSize = 13.sp,
                                fontWeight = FontWeight.Bold,
                                maxLines = 1,
                                overflow = TextOverflow.Ellipsis
                            )
                            Text(
                                text = app.category,
                                color = TigerTextSecondary,
                                fontSize = 11.sp
                            )
                            Spacer(modifier = Modifier.height(4.dp))
                            Row(verticalAlignment = Alignment.CenterVertically) {
                                Text(
                                    text = "${app.rating} ★",
                                    color = TigerGold,
                                    fontSize = 11.sp,
                                    fontWeight = FontWeight.Bold
                                )
                                Spacer(modifier = Modifier.width(4.dp))
                                Text(
                                    text = "${app.sizeMb}MB",
                                    color = TigerTextMuted,
                                    fontSize = 11.sp
                                )
                            }
                            Spacer(modifier = Modifier.height(8.dp))
                            Button(
                                onClick = { onDownloadApp(app) },
                                shape = RoundedCornerShape(12.dp),
                                colors = ButtonDefaults.buttonColors(
                                    containerColor = TigerOrange,
                                    contentColor = Color.Black
                                ),
                                contentPadding = PaddingValues(vertical = 4.dp),
                                modifier = Modifier.fillMaxWidth().height(32.dp)
                            ) {
                                Text(
                                    text = if (app.price == 0.0) "Download" else "${currency.symbol}${String.format("%.2f", app.price * currency.rateFromUsd)}",
                                    fontSize = 11.sp,
                                    fontWeight = FontWeight.Bold
                                )
                            }
                        }
                    }
                }
            }
        }

        // 5. TikTok-Style Creator Reels Strip
        item {
            Spacer(modifier = Modifier.height(16.dp))
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(horizontal = 16.dp, vertical = 8.dp),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Icon(
                        imageVector = Icons.Default.PlayCircle,
                        contentDescription = "Reels",
                        tint = TigerOrange,
                        modifier = Modifier.size(22.dp)
                    )
                    Spacer(modifier = Modifier.width(6.dp))
                    Text(
                        text = "Viral Creator Reels",
                        color = TigerTextPrimary,
                        fontSize = 18.sp,
                        fontWeight = FontWeight.Bold
                    )
                }
                Text(
                    text = "Watch Feed →",
                    color = TigerOrangeLight,
                    fontSize = 13.sp,
                    fontWeight = FontWeight.SemiBold,
                    modifier = Modifier.clickable { onNavigateTab(NavigationTab.REELS) }
                )
            }

            LazyRow(
                modifier = Modifier.fillMaxWidth(),
                contentPadding = PaddingValues(horizontal = 16.dp),
                horizontalArrangement = Arrangement.spacedBy(12.dp)
            ) {
                items(reels) { reel ->
                    Card(
                        modifier = Modifier
                            .width(130.dp)
                            .height(190.dp)
                            .clip(RoundedCornerShape(16.dp))
                            .clickable { onNavigateTab(NavigationTab.REELS) },
                        colors = CardDefaults.cardColors(containerColor = TigerCarbonSurfaceElevated),
                        border = androidx.compose.foundation.BorderStroke(1.dp, TigerCarbonSurfaceBorder)
                    ) {
                        Box(modifier = Modifier.fillMaxSize()) {
                            // Video backdrop simulation gradient
                            Box(
                                modifier = Modifier
                                    .fillMaxSize()
                                    .background(
                                        Brush.verticalGradient(
                                            listOf(
                                                TigerOrangeDark.copy(alpha = 0.5f),
                                                TigerCarbonBackground
                                            )
                                        )
                                    )
                            )

                            // Play button center
                            Icon(
                                imageVector = Icons.Default.PlayArrow,
                                contentDescription = "Play",
                                tint = Color.White.copy(alpha = 0.8f),
                                modifier = Modifier
                                    .size(36.dp)
                                    .align(Alignment.Center)
                            )

                            // Reel overlay info
                            Column(
                                modifier = Modifier
                                    .align(Alignment.BottomStart)
                                    .padding(8.dp)
                            ) {
                                Text(
                                    text = reel.title,
                                    color = Color.White,
                                    fontSize = 11.sp,
                                    fontWeight = FontWeight.Bold,
                                    maxLines = 2,
                                    overflow = TextOverflow.Ellipsis
                                )
                                Spacer(modifier = Modifier.height(2.dp))
                                Row(verticalAlignment = Alignment.CenterVertically) {
                                    Icon(
                                        imageVector = Icons.Default.Favorite,
                                        contentDescription = "Likes",
                                        tint = TigerAccent,
                                        modifier = Modifier.size(12.dp)
                                    )
                                    Spacer(modifier = Modifier.width(3.dp))
                                    Text(
                                        text = "${reel.likesCount}",
                                        color = TigerTextSecondary,
                                        fontSize = 10.sp
                                    )
                                }
                            }
                        }
                    }
                }
            }
        }

        // 6. Digital Marketplace Picks
        item {
            Spacer(modifier = Modifier.height(16.dp))
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(horizontal = 16.dp, vertical = 8.dp),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Text(
                    text = "Digital Marketplace",
                    color = TigerTextPrimary,
                    fontSize = 18.sp,
                    fontWeight = FontWeight.Bold
                )
                Text(
                    text = "Browse Kits →",
                    color = TigerOrangeLight,
                    fontSize = 13.sp,
                    fontWeight = FontWeight.SemiBold,
                    modifier = Modifier.clickable { onNavigateTab(NavigationTab.UPLOAD) }
                )
            }

            LazyRow(
                modifier = Modifier.fillMaxWidth(),
                contentPadding = PaddingValues(horizontal = 16.dp),
                horizontalArrangement = Arrangement.spacedBy(12.dp)
            ) {
                items(products) { prod ->
                    Card(
                        modifier = Modifier
                            .width(200.dp)
                            .clip(RoundedCornerShape(16.dp))
                            .clickable { onProductClick(prod) },
                        colors = CardDefaults.cardColors(containerColor = TigerCarbonSurface),
                        border = androidx.compose.foundation.BorderStroke(1.dp, TigerCarbonSurfaceBorder)
                    ) {
                        Column(modifier = Modifier.padding(12.dp)) {
                            Box(
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .height(90.dp)
                                    .clip(RoundedCornerShape(10.dp))
                                    .background(
                                        Brush.linearGradient(
                                            listOf(TigerCarbonSurfaceBorder, TigerCarbonSurfaceElevated)
                                        )
                                    ),
                                contentAlignment = Alignment.Center
                            ) {
                                Icon(
                                    imageVector = Icons.Default.ShoppingCart,
                                    contentDescription = prod.title,
                                    tint = TigerGold,
                                    modifier = Modifier.size(32.dp)
                                )
                            }
                            Spacer(modifier = Modifier.height(8.dp))
                            Text(
                                text = prod.title,
                                color = TigerTextPrimary,
                                fontSize = 13.sp,
                                fontWeight = FontWeight.Bold,
                                maxLines = 1,
                                overflow = TextOverflow.Ellipsis
                            )
                            Text(
                                text = prod.category,
                                color = TigerTextSecondary,
                                fontSize = 11.sp
                            )
                            Spacer(modifier = Modifier.height(4.dp))
                            Row(
                                modifier = Modifier.fillMaxWidth(),
                                horizontalArrangement = Arrangement.SpaceBetween,
                                verticalAlignment = Alignment.CenterVertically
                            ) {
                                Text(
                                    text = "${currency.symbol}${String.format("%.2f", prod.price * currency.rateFromUsd)}",
                                    color = TigerOrangeLight,
                                    fontWeight = FontWeight.ExtraBold,
                                    fontSize = 14.sp
                                )
                                Text(
                                    text = "${prod.salesCount} sold",
                                    color = TigerTextMuted,
                                    fontSize = 10.sp
                                )
                            }
                        }
                    }
                }
            }
        }

        // 7. All Recommended APKs List
        item {
            Spacer(modifier = Modifier.height(20.dp))
            Text(
                text = "Top Verified Releases",
                color = TigerTextPrimary,
                fontSize = 18.sp,
                fontWeight = FontWeight.Bold,
                modifier = Modifier.padding(horizontal = 16.dp, vertical = 6.dp)
            )
        }

        items(filteredApps) { app ->
            Box(modifier = Modifier.padding(horizontal = 16.dp, vertical = 4.dp)) {
                TigerAppCard(
                    app = app,
                    currency = currency,
                    downloadStatus = downloadStatusMap[app.id] ?: DownloadStatus.IDLE,
                    downloadProgress = downloadProgressMap[app.id] ?: 0f,
                    onClick = { onAppClick(app) },
                    onDownloadClick = { onDownloadApp(app) }
                )
            }
        }
    }
}
