package com.example.ui.screens

import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.data.remote.SupabaseService
import com.example.model.SupabaseConfig
import com.example.ui.theme.*

@Composable
fun SupabaseConfigDialog(
    isOpen: Boolean,
    currentConfig: SupabaseConfig,
    statusMessage: String?,
    isConnecting: Boolean,
    onTestAndSave: (String, String) -> Unit,
    onDismiss: () -> Unit
) {
    if (!isOpen) return

    var url by remember { mutableStateOf(currentConfig.url) }
    var anonKey by remember { mutableStateOf(currentConfig.anonKey) }
    var showSqlSchema by remember { mutableStateOf(false) }

    AlertDialog(
        onDismissRequest = onDismiss,
        title = {
            Row(verticalAlignment = Alignment.CenterVertically) {
                Icon(
                    imageVector = Icons.Default.CloudSync,
                    contentDescription = "Supabase",
                    tint = TigerSuccess,
                    modifier = Modifier.size(24.dp)
                )
                Spacer(modifier = Modifier.width(8.dp))
                Text("Supabase Backend Settings", color = TigerTextPrimary, fontSize = 17.sp, fontWeight = FontWeight.Bold)
            }
        },
        text = {
            Column(
                modifier = Modifier
                    .fillMaxWidth()
                    .verticalScroll(rememberScrollState())
                    .testTag("supabase_config_content")
            ) {
                Text(
                    text = "Connect your real Supabase project to enable cloud authentication, PostgreSQL database sync, and storage buckets for APKs, videos, and screenshots.",
                    color = TigerTextSecondary,
                    fontSize = 12.sp,
                    lineHeight = 16.sp
                )

                Spacer(modifier = Modifier.height(12.dp))

                OutlinedTextField(
                    value = url,
                    onValueChange = { url = it },
                    label = { Text("Supabase Project URL") },
                    placeholder = { Text("https://xyzcompany.supabase.co") },
                    modifier = Modifier.fillMaxWidth().testTag("supabase_url_input"),
                    colors = OutlinedTextFieldDefaults.colors(
                        focusedBorderColor = TigerOrange,
                        unfocusedBorderColor = TigerCarbonSurfaceBorder,
                        focusedTextColor = TigerTextPrimary,
                        unfocusedTextColor = TigerTextPrimary
                    )
                )

                Spacer(modifier = Modifier.height(8.dp))

                OutlinedTextField(
                    value = anonKey,
                    onValueChange = { anonKey = it },
                    label = { Text("Supabase Public Anon Key") },
                    placeholder = { Text("eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9...") },
                    modifier = Modifier.fillMaxWidth().testTag("supabase_key_input"),
                    colors = OutlinedTextFieldDefaults.colors(
                        focusedBorderColor = TigerOrange,
                        unfocusedBorderColor = TigerCarbonSurfaceBorder,
                        focusedTextColor = TigerTextPrimary,
                        unfocusedTextColor = TigerTextPrimary
                    )
                )

                Spacer(modifier = Modifier.height(10.dp))

                if (statusMessage != null) {
                    Surface(
                        shape = RoundedCornerShape(8.dp),
                        color = if (currentConfig.isConnected) TigerSuccess.copy(alpha = 0.15f) else TigerCarbonSurface,
                        border = androidx.compose.foundation.BorderStroke(1.dp, if (currentConfig.isConnected) TigerSuccess else TigerCarbonSurfaceBorder),
                        modifier = Modifier.fillMaxWidth()
                    ) {
                        Text(
                            text = statusMessage,
                            color = if (currentConfig.isConnected) TigerSuccess else TigerOrangeLight,
                            fontSize = 11.sp,
                            modifier = Modifier.padding(8.dp)
                        )
                    }
                    Spacer(modifier = Modifier.height(10.dp))
                }

                // Show SQL Schema Accordion
                Button(
                    onClick = { showSqlSchema = !showSqlSchema },
                    colors = ButtonDefaults.buttonColors(containerColor = TigerCarbonSurfaceElevated),
                    shape = RoundedCornerShape(8.dp),
                    modifier = Modifier.fillMaxWidth()
                ) {
                    Text(
                        text = if (showSqlSchema) "Hide SQL Setup Script" else "View SQL Schema & RLS Setup Script",
                        color = TigerOrangeLight,
                        fontSize = 11.sp
                    )
                }

                if (showSqlSchema) {
                    Spacer(modifier = Modifier.height(8.dp))
                    Surface(
                        shape = RoundedCornerShape(8.dp),
                        color = Color.Black,
                        modifier = Modifier.fillMaxWidth()
                    ) {
                        Text(
                            text = SupabaseService.SQL_MIGRATION_SCRIPT,
                            color = Color.Green,
                            fontSize = 9.sp,
                            fontFamily = FontFamily.Monospace,
                            modifier = Modifier.padding(10.dp)
                        )
                    }
                }
            }
        },
        confirmButton = {
            Button(
                onClick = { onTestAndSave(url, anonKey) },
                enabled = !isConnecting,
                colors = ButtonDefaults.buttonColors(containerColor = TigerOrange, contentColor = Color.Black),
                modifier = Modifier.testTag("save_supabase_button")
            ) {
                Text(if (isConnecting) "Testing..." else "Test & Connect", fontWeight = FontWeight.Bold)
            }
        },
        dismissButton = {
            TextButton(onClick = onDismiss) {
                Text("Close", color = TigerTextSecondary)
            }
        },
        containerColor = TigerCarbonSurfaceElevated
    )
}
