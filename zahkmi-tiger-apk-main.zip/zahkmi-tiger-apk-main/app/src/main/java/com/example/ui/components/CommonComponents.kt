package com.example.ui.components

import androidx.compose.animation.core.*
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material.icons.outlined.*
import androidx.compose.material3.*
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.R
import com.example.model.Currency
import com.example.model.StoreApp
import com.example.ui.theme.*
import com.example.ui.viewmodel.DownloadStatus

@Composable
fun TigerAppCard(
    app: StoreApp,
    currency: Currency,
    downloadStatus: DownloadStatus,
    downloadProgress: Float,
    onClick: () -> Unit,
    onDownloadClick: () -> Unit,
    modifier: Modifier = Modifier
) {
    Surface(
        modifier = modifier
            .fillMaxWidth()
            .clip(RoundedCornerShape(16.dp))
            .clickable(onClick = onClick)
            .testTag("app_card_${app.id}"),
        color = TigerCarbonSurface,
        tonalElevation = 2.dp,
        border = androidx.compose.foundation.BorderStroke(1.dp, TigerCarbonSurfaceBorder.copy(alpha = 0.5f))
    ) {
        Row(
            modifier = Modifier
                .padding(14.dp)
                .fillMaxWidth(),
            verticalAlignment = Alignment.CenterVertically
        ) {
            // App Icon
            Box(
                modifier = Modifier
                    .size(56.dp)
                    .clip(RoundedCornerShape(14.dp))
                    .background(
                        Brush.linearGradient(
                            listOf(TigerOrangeDark, TigerOrange)
                        )
                    ),
                contentAlignment = Alignment.Center
            ) {
                // If it's the first app or has the tiger asset, render the real generated tiger logo!
                if (app.id == "app_1" || app.id == "app_5") {
                    Image(
                        painter = painterResource(id = R.drawable.img_tiger_logo),
                        contentDescription = app.title,
                        modifier = Modifier.fillMaxSize().clip(RoundedCornerShape(14.dp))
                    )
                } else {
                    Icon(
                        imageVector = when (app.category) {
                            "Games" -> Icons.Default.SportsEsports
                            "Tools" -> Icons.Default.Build
                            "Social" -> Icons.Default.Chat
                            "Entertainment" -> Icons.Default.Movie
                            "Productivity" -> Icons.Default.Laptop
                            "Finance" -> Icons.Default.AccountBalanceWallet
                            else -> Icons.Default.Apps
                        },
                        contentDescription = app.title,
                        tint = Color.White,
                        modifier = Modifier.size(28.dp)
                    )
                }
            }

            Spacer(modifier = Modifier.width(14.dp))

            // App details
            Column(
                modifier = Modifier.weight(1f)
            ) {
                Text(
                    text = app.title,
                    color = TigerTextPrimary,
                    fontSize = 15.sp,
                    fontWeight = FontWeight.Bold,
                    maxLines = 1,
                    overflow = TextOverflow.Ellipsis
                )
                Text(
                    text = app.developerName,
                    color = TigerTextSecondary,
                    fontSize = 12.sp,
                    maxLines = 1,
                    overflow = TextOverflow.Ellipsis
                )
                Spacer(modifier = Modifier.height(4.dp))
                Row(
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Text(
                        text = "${app.rating} ★",
                        color = TigerGold,
                        fontSize = 12.sp,
                        fontWeight = FontWeight.SemiBold
                    )
                    Spacer(modifier = Modifier.width(6.dp))
                    Text(
                        text = "•  ${app.sizeMb} MB",
                        color = TigerTextMuted,
                        fontSize = 12.sp
                    )
                    if (app.price > 0.0) {
                        Spacer(modifier = Modifier.width(6.dp))
                        Text(
                            text = "•  ${currency.symbol}${String.format("%.2f", app.price * currency.rateFromUsd)}",
                            color = TigerOrangeLight,
                            fontSize = 12.sp,
                            fontWeight = FontWeight.Bold
                        )
                    }
                }
            }

            Spacer(modifier = Modifier.width(8.dp))

            // Action / Download button
            Box(contentAlignment = Alignment.Center) {
                when (downloadStatus) {
                    DownloadStatus.DOWNLOADING -> {
                        CircularProgressIndicator(
                            progress = { downloadProgress },
                            modifier = Modifier.size(36.dp),
                            color = TigerOrange,
                            strokeWidth = 3.dp
                        )
                    }
                    DownloadStatus.SCANNING -> {
                        CircularProgressIndicator(
                            modifier = Modifier.size(32.dp),
                            color = TigerInfo,
                            strokeWidth = 2.5.dp
                        )
                    }
                    DownloadStatus.COMPLETED -> {
                        Surface(
                            shape = RoundedCornerShape(20.dp),
                            color = TigerSuccess.copy(alpha = 0.2f),
                            border = androidx.compose.foundation.BorderStroke(1.dp, TigerSuccess)
                        ) {
                            Text(
                                text = "Installed",
                                color = TigerSuccess,
                                fontSize = 12.sp,
                                fontWeight = FontWeight.Bold,
                                modifier = Modifier.padding(horizontal = 12.dp, vertical = 6.dp)
                            )
                        }
                    }
                    else -> {
                        Button(
                            onClick = onDownloadClick,
                            shape = RoundedCornerShape(20.dp),
                            colors = ButtonDefaults.buttonColors(
                                containerColor = if (app.price == 0.0) TigerCarbonSurfaceElevated else TigerOrange,
                                contentColor = if (app.price == 0.0) TigerOrangeLight else Color.Black
                            ),
                            contentPadding = PaddingValues(horizontal = 14.dp, vertical = 6.dp),
                            modifier = Modifier.testTag("download_btn_${app.id}")
                        ) {
                            Text(
                                text = if (app.price == 0.0) "Get" else "${currency.symbol}${String.format("%.2f", app.price * currency.rateFromUsd)}",
                                fontSize = 13.sp,
                                fontWeight = FontWeight.Bold
                            )
                        }
                    }
                }
            }
        }
    }
}

@Composable
fun SecurityShieldBadge(
    modifier: Modifier = Modifier
) {
    Surface(
        modifier = modifier.fillMaxWidth(),
        shape = RoundedCornerShape(12.dp),
        color = TigerSuccess.copy(alpha = 0.12f),
        border = androidx.compose.foundation.BorderStroke(1.dp, TigerSuccess.copy(alpha = 0.4f))
    ) {
        Row(
            modifier = Modifier.padding(10.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            Icon(
                imageVector = Icons.Default.VerifiedUser,
                contentDescription = "Security Verified",
                tint = TigerSuccess,
                modifier = Modifier.size(20.dp)
            )
            Spacer(modifier = Modifier.width(8.dp))
            Column {
                Text(
                    text = "Verified by Jakhmi Tiger Protect",
                    color = TigerSuccess,
                    fontSize = 12.sp,
                    fontWeight = FontWeight.Bold
                )
                Text(
                    text = "Malware scanned • Zero security threats • Safe APK package",
                    color = TigerTextSecondary,
                    fontSize = 11.sp
                )
            }
        }
    }
}

@Composable
fun InteractiveStarRating(
    rating: Int,
    onRatingChanged: (Int) -> Unit,
    modifier: Modifier = Modifier
) {
    Row(
        modifier = modifier,
        horizontalArrangement = Arrangement.Center
    ) {
        for (i in 1..5) {
            IconButton(
                onClick = { onRatingChanged(i) },
                modifier = Modifier.size(36.dp)
            ) {
                Icon(
                    imageVector = if (i <= rating) Icons.Filled.Star else Icons.Outlined.StarOutline,
                    contentDescription = "$i stars",
                    tint = if (i <= rating) TigerGold else TigerTextMuted,
                    modifier = Modifier.size(28.dp)
                )
            }
        }
    }
}
