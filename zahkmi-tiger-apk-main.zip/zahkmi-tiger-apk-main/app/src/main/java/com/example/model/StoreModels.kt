package com.example.model

enum class AppCategory(val displayName: String, val icon: String) {
    ALL("All", "Apps"),
    GAMES("Games", "SportsEsports"),
    TOOLS("Tools", "Build"),
    SOCIAL("Social", "Chat"),
    ENTERTAINMENT("Entertainment", "Movie"),
    PRODUCTIVITY("Productivity", "Work"),
    FINANCE("Finance", "AttachMoney")
}

enum class ProductCategory(val displayName: String) {
    ALL("All Products"),
    APKS("APKs & Apps"),
    UI_KITS("UI & Graphics"),
    TEMPLATES("Video Templates"),
    SCRIPTS("Code & Scripts"),
    THREE_D("3D Assets"),
    AUDIO("Music & SFX")
}

enum class ItemType {
    APP,
    MARKETPLACE_PRODUCT
}

enum class Currency(val symbol: String, val code: String, val rateFromUsd: Double) {
    USD("$", "USD", 1.0),
    INR("₹", "INR", 83.5),
    EUR("€", "EUR", 0.92)
}

data class UserAccount(
    val id: String,
    val email: String,
    val username: String,
    val displayName: String,
    val avatarUrl: String = "",
    val bio: String = "Jakhmi Tiger creator & enthusiast",
    val isVerified: Boolean = true,
    val isAdmin: Boolean = false,
    val joinedDate: String = "2026-03-15",
    val balance: Double = 150.00
)

data class StoreApp(
    val id: String,
    val title: String,
    val packageName: String,
    val developerName: String,
    val developerId: String,
    val category: String,
    val rating: Float,
    val ratingCount: Int,
    val downloadCount: Int,
    val sizeMb: Double,
    val version: String,
    val price: Double = 0.0, // 0.0 is Free
    val iconUrl: String = "",
    val bannerUrl: String = "",
    val screenshots: List<String> = emptyList(),
    val description: String,
    val apkFileName: String,
    val apkUrl: String,
    val releaseDate: String,
    val isApproved: Boolean = true,
    val isEditorChoice: Boolean = false,
    val isTrending: Boolean = false
)

data class ReelVideo(
    val id: String,
    val title: String,
    val caption: String,
    val creatorName: String,
    val creatorAvatar: String = "",
    val creatorId: String,
    val videoUrl: String = "",
    val thumbnailUrl: String = "",
    val audioTitle: String = "Original Tiger Beat - High Octane",
    val likesCount: Int = 1200,
    val commentsCount: Int = 84,
    val sharesCount: Int = 320,
    val isLiked: Boolean = false,
    val isFollowing: Boolean = false,
    val tags: List<String> = listOf("JakhmiTiger", "Android", "Gaming", "Tech"),
    val createdAt: String = "Just now",
    val isApproved: Boolean = true
)

data class ReelComment(
    val id: String,
    val reelId: String,
    val userName: String,
    val userAvatar: String = "",
    val content: String,
    val timestamp: String = "Just now",
    val likesCount: Int = 0
)

data class MarketplaceProduct(
    val id: String,
    val title: String,
    val description: String,
    val category: String,
    val price: Double,
    val sellerName: String,
    val sellerId: String,
    val rating: Float = 4.8f,
    val salesCount: Int = 142,
    val previewImages: List<String> = emptyList(),
    val downloadUrl: String = "",
    val fileType: String = "ZIP / APK",
    val fileSizeMb: Double = 45.0,
    val isApproved: Boolean = true
)

data class AppReview(
    val id: String,
    val appId: String,
    val userName: String,
    val userAvatar: String = "",
    val rating: Int,
    val comment: String,
    val date: String,
    val helpfulCount: Int = 0
)

data class CartItem(
    val product: MarketplaceProduct,
    val quantity: Int = 1
)

data class PurchaseRecord(
    val id: String,
    val userId: String,
    val itemId: String,
    val itemTitle: String,
    val itemType: ItemType,
    val amount: Double,
    val currency: String,
    val timestamp: String,
    val paymentMethod: String,
    val transactionRef: String,
    val downloadUrl: String
)

data class StoreNotification(
    val id: String,
    val title: String,
    val message: String,
    val type: String, // LIKE, COMMENT, PURCHASE, UPLOAD, SYSTEM
    val timestamp: String,
    val isRead: Boolean = false
)

data class ContentReport(
    val id: String,
    val reporterId: String,
    val contentId: String,
    val contentType: String, // APP, REEL, PRODUCT
    val contentTitle: String,
    val reason: String,
    val timestamp: String,
    val status: String = "PENDING" // PENDING, RESOLVED, DISMISSED
)

data class SupabaseConfig(
    val url: String = "",
    val anonKey: String = "",
    val isConnected: Boolean = false,
    val lastSyncedAt: String = ""
)
