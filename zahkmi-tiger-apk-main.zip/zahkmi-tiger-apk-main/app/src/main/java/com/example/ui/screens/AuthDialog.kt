package com.example.ui.screens

import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.PasswordVisualTransformation
import androidx.compose.ui.text.input.VisualTransformation
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.ui.theme.*

@Composable
fun AuthDialog(
    isOpen: Boolean,
    onDismiss: () -> Unit,
    onLogin: (String, String) -> Unit,
    onRegister: (String, String, String) -> Unit,
    onGoogleSignIn: () -> Unit,
    errorMessage: String?,
    successMessage: String?,
    isSupabaseConnected: Boolean
) {
    if (!isOpen) return

    var isRegisterTab by remember { mutableStateOf(false) }
    var email by remember { mutableStateOf("") }
    var password by remember { mutableStateOf("") }
    var username by remember { mutableStateOf("") }
    var showPassword by remember { mutableStateOf(false) }
    var isForgotPassword by remember { mutableStateOf(false) }
    var resetEmailSent by remember { mutableStateOf(false) }

    AlertDialog(
        onDismissRequest = onDismiss,
        title = {
            Column {
                Text(
                    text = if (isForgotPassword) "Reset Password" else if (isRegisterTab) "Create Account" else "Sign In",
                    color = TigerTextPrimary,
                    fontWeight = FontWeight.Bold,
                    fontSize = 18.sp
                )
                Text(
                    text = if (isSupabaseConnected) "Protected by Supabase Auth" else "Jakhmi Tiger Auth Session",
                    color = if (isSupabaseConnected) TigerSuccess else TigerTextMuted,
                    fontSize = 11.sp
                )
            }
        },
        text = {
            Column(modifier = Modifier.fillMaxWidth().testTag("auth_dialog_content")) {
                if (isForgotPassword) {
                    Text(
                        text = "Enter your registered email address to receive password reset instructions:",
                        color = TigerTextSecondary,
                        fontSize = 13.sp
                    )
                    Spacer(modifier = Modifier.height(10.dp))
                    OutlinedTextField(
                        value = email,
                        onValueChange = { email = it },
                        label = { Text("Email Address") },
                        modifier = Modifier.fillMaxWidth(),
                        colors = OutlinedTextFieldDefaults.colors(
                            focusedBorderColor = TigerOrange,
                            unfocusedBorderColor = TigerCarbonSurfaceBorder,
                            focusedTextColor = TigerTextPrimary,
                            unfocusedTextColor = TigerTextPrimary
                        )
                    )
                    if (resetEmailSent) {
                        Spacer(modifier = Modifier.height(8.dp))
                        Text(
                            text = "Password reset instructions sent to $email",
                            color = TigerSuccess,
                            fontSize = 12.sp,
                            fontWeight = FontWeight.Bold
                        )
                    }
                } else {
                    // Google Sign-In Button
                    Button(
                        onClick = onGoogleSignIn,
                        shape = RoundedCornerShape(12.dp),
                        colors = ButtonDefaults.buttonColors(
                            containerColor = Color.White,
                            contentColor = Color.Black
                        ),
                        modifier = Modifier.fillMaxWidth().testTag("google_signin_button")
                    ) {
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Icon(
                                imageVector = Icons.Default.AccountCircle,
                                contentDescription = "Google",
                                tint = TigerOrangeDark,
                                modifier = Modifier.size(20.dp)
                            )
                            Spacer(modifier = Modifier.width(8.dp))
                            Text("Continue with Google", fontWeight = FontWeight.Bold, fontSize = 13.sp)
                        }
                    }

                    Spacer(modifier = Modifier.height(14.dp))
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Divider(modifier = Modifier.weight(1f), color = TigerCarbonSurfaceBorder)
                        Text(
                            text = "  OR  ",
                            color = TigerTextMuted,
                            fontSize = 11.sp
                        )
                        Divider(modifier = Modifier.weight(1f), color = TigerCarbonSurfaceBorder)
                    }
                    Spacer(modifier = Modifier.height(12.dp))

                    // Tab selector between Sign in & Register
                    TabRow(
                        selectedTabIndex = if (isRegisterTab) 1 else 0,
                        containerColor = TigerCarbonSurface,
                        contentColor = TigerOrangeLight
                    ) {
                        Tab(
                            selected = !isRegisterTab,
                            onClick = { isRegisterTab = false },
                            text = { Text("Sign In") }
                        )
                        Tab(
                            selected = isRegisterTab,
                            onClick = { isRegisterTab = true },
                            text = { Text("Register") }
                        )
                    }

                    Spacer(modifier = Modifier.height(12.dp))

                    if (isRegisterTab) {
                        OutlinedTextField(
                            value = username,
                            onValueChange = { username = it },
                            label = { Text("Username") },
                            modifier = Modifier.fillMaxWidth().testTag("auth_username_input"),
                            colors = OutlinedTextFieldDefaults.colors(
                                focusedBorderColor = TigerOrange,
                                unfocusedBorderColor = TigerCarbonSurfaceBorder,
                                focusedTextColor = TigerTextPrimary,
                                unfocusedTextColor = TigerTextPrimary
                            )
                        )
                        Spacer(modifier = Modifier.height(8.dp))
                    }

                    OutlinedTextField(
                        value = email,
                        onValueChange = { email = it },
                        label = { Text("Email Address") },
                        modifier = Modifier.fillMaxWidth().testTag("auth_email_input"),
                        colors = OutlinedTextFieldDefaults.colors(
                            focusedBorderColor = TigerOrange,
                            unfocusedBorderColor = TigerCarbonSurfaceBorder,
                            focusedTextColor = TigerTextPrimary,
                            unfocusedTextColor = TigerTextPrimary
                        )
                    )

                    Spacer(modifier = Modifier.height(8.dp))

                    OutlinedTextField(
                        value = password,
                        onValueChange = { password = it },
                        label = { Text("Password") },
                        visualTransformation = if (showPassword) VisualTransformation.None else PasswordVisualTransformation(),
                        trailingIcon = {
                            IconButton(onClick = { showPassword = !showPassword }) {
                                Icon(
                                    imageVector = if (showPassword) Icons.Default.Visibility else Icons.Default.VisibilityOff,
                                    contentDescription = "Toggle password",
                                    tint = TigerTextSecondary
                                )
                            }
                        },
                        modifier = Modifier.fillMaxWidth().testTag("auth_password_input"),
                        colors = OutlinedTextFieldDefaults.colors(
                            focusedBorderColor = TigerOrange,
                            unfocusedBorderColor = TigerCarbonSurfaceBorder,
                            focusedTextColor = TigerTextPrimary,
                            unfocusedTextColor = TigerTextPrimary
                        )
                    )

                    if (!isRegisterTab) {
                        Spacer(modifier = Modifier.height(4.dp))
                        Text(
                            text = "Forgot password?",
                            color = TigerOrangeLight,
                            fontSize = 11.sp,
                            modifier = Modifier
                                .align(Alignment.End)
                                .clickable { isForgotPassword = true }
                        )
                    }

                    if (errorMessage != null) {
                        Spacer(modifier = Modifier.height(8.dp))
                        Text(
                            text = errorMessage,
                            color = TigerError,
                            fontSize = 12.sp,
                            fontWeight = FontWeight.Bold
                        )
                    }

                    if (successMessage != null) {
                        Spacer(modifier = Modifier.height(8.dp))
                        Text(
                            text = successMessage,
                            color = TigerSuccess,
                            fontSize = 12.sp,
                            fontWeight = FontWeight.Bold
                        )
                    }
                }
            }
        },
        confirmButton = {
            Button(
                onClick = {
                    if (isForgotPassword) {
                        resetEmailSent = true
                    } else if (isRegisterTab) {
                        onRegister(email, password, username)
                    } else {
                        onLogin(email, password)
                    }
                },
                colors = ButtonDefaults.buttonColors(
                    containerColor = TigerOrange,
                    contentColor = Color.Black
                ),
                shape = RoundedCornerShape(10.dp),
                modifier = Modifier.testTag("auth_submit_button")
            ) {
                Text(
                    text = if (isForgotPassword) "Send Reset Link" else if (isRegisterTab) "Create Account" else "Sign In",
                    fontWeight = FontWeight.Bold
                )
            }
        },
        dismissButton = {
            TextButton(
                onClick = {
                    if (isForgotPassword) {
                        isForgotPassword = false
                    } else {
                        onDismiss()
                    }
                }
            ) {
                Text(if (isForgotPassword) "Back" else "Cancel", color = TigerTextSecondary)
            }
        },
        containerColor = TigerCarbonSurfaceElevated
    )
}
